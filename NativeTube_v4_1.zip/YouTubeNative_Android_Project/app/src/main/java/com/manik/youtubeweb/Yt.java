package com.manik.youtubeweb;

import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.InfoItem;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.StreamingService;
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler;
import org.schabi.newpipe.extractor.localization.ContentCountry;
import org.schabi.newpipe.extractor.localization.Localization;
import org.schabi.newpipe.extractor.search.SearchInfo;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.Description;
import org.schabi.newpipe.extractor.stream.Stream;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.StreamInfoItem;
import org.schabi.newpipe.extractor.stream.StreamType;
import org.schabi.newpipe.extractor.stream.VideoStream;
import okhttp3.Request;
import okhttp3.Response;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * YouTube access that runs entirely on the phone (NewPipeExtractor). There is no middle-man server any more,
 * so public Piped/Invidious outages can no longer break search or playback.
 */
final class Yt {
    private static final StreamingService YT = ServiceList.YouTube;
    private static String initRegion = null;

    private Yt() {}

    /** Result page: items in the app's JSON card format + an opaque token for the next page. */
    static final class Page {
        final JSONArray items;
        final org.schabi.newpipe.extractor.Page next;
        Page(JSONArray items, org.schabi.newpipe.extractor.Page next) {
            this.items = items == null ? new JSONArray() : items;
            this.next = next;
        }
    }

    static final class VS { String url, suffix = "", codec = ""; int height; }
    static final class AS { String url, suffix = ""; int bitrate; }

    static final class Info {
        String subsText = "", likesText = "";
        String id, title = "", uploader = "", uploaderUrl = "", channelId = "", avatar = "", desc = "", uploadDate = "";
        String hls = "", dash = "";
        boolean live, descHtml;
        long views = -1, likes = -1, subs = -1, duration = 0;
        final List<VS> muxed = new ArrayList<>(), videoOnly = new ArrayList<>();
        final List<AS> audio = new ArrayList<>();
        final List<JSONObject> related = new ArrayList<>();
    }

    static synchronized void init(String region) {
        String r = region == null || region.isEmpty() ? "US" : region;
        if (r.equals(initRegion)) return;
        NewPipe.init(Net.Dl.INSTANCE, new Localization("en", "US"), new ContentCountry(r));
        initRegion = r;
    }

    // ------------------------------------------------------------------ helpers

    static String bestImage(List<Image> imgs) {
        if (imgs == null || imgs.isEmpty()) return "";
        Image best = null;
        for (Image i : imgs) {
            if (i == null || i.getUrl() == null || i.getUrl().isEmpty()) continue;
            if (best == null || i.getHeight() > best.getHeight()) best = i;
        }
        return best == null ? "" : best.getUrl();
    }

    static String videoId(String url) {
        if (url == null) return "";
        if (url.matches("[A-Za-z0-9_-]{11}")) return url;
        int v = url.indexOf("v=");
        if (v >= 0) {
            String id = url.substring(v + 2);
            int amp = id.indexOf('&');
            return amp >= 0 ? id.substring(0, amp) : id;
        }
        int q = url.indexOf('?');
        if (q >= 0) url = url.substring(0, q);
        int last = url.lastIndexOf('/');
        return last >= 0 ? url.substring(last + 1) : url;
    }

    static String channelId(String url) {
        if (url == null) return "";
        int i = url.indexOf("/channel/");
        if (i < 0) return "";
        String id = url.substring(i + 9);
        int e = id.indexOf('/');
        if (e >= 0) id = id.substring(0, e);
        e = id.indexOf('?');
        if (e >= 0) id = id.substring(0, e);
        return id;
    }

    private static JSONObject card(StreamInfoItem s) {
        try {
            JSONObject o = new JSONObject();
            String id = videoId(s.getUrl());
            if (id.isEmpty()) return null;
            o.put("url", "/watch?v=" + id);
            o.put("title", s.getName() == null ? "" : s.getName());
            o.put("uploaderName", s.getUploaderName() == null ? "" : s.getUploaderName());
            o.put("uploaderUrl", s.getUploaderUrl() == null ? "" : s.getUploaderUrl());
            o.put("thumbnail", bestImage(s.getThumbnails()));
            o.put("uploaderAvatar", bestImage(s.getUploaderAvatars()));
            o.put("views", s.getViewCount());
            String when = s.getTextualUploadDate();
            o.put("uploadedDate", when == null ? "" : when);
            StreamType t = s.getStreamType();
            boolean live = t == StreamType.LIVE_STREAM || t == StreamType.AUDIO_LIVE_STREAM;
            o.put("duration", live ? -1 : s.getDuration());
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    private static JSONArray cards(List<? extends InfoItem> items) {
        JSONArray out = new JSONArray();
        if (items == null) return out;
        for (InfoItem it : items) {
            if (!(it instanceof StreamInfoItem)) continue;
            StreamInfoItem s = (StreamInfoItem) it;
            if (s.isShortFormContent()) continue;
            JSONObject o = card(s);
            if (o != null) out.put(o);
        }
        return out;
    }

    /** Keeps only regular watchable videos and removes duplicates. */
    static List<JSONObject> playable(JSONArray arr, Set<String> seen) {
        List<JSONObject> out = new ArrayList<>();
        if (arr == null) return out;
        Set<String> local = seen == null ? new HashSet<String>() : seen;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String url = o.optString("url", "");
            if (!url.startsWith("/watch")) continue;
            String id = videoId(url);
            if (id.isEmpty() || !local.add(id)) continue;
            out.add(o);
        }
        return out;
    }

    // ------------------------------------------------------------------ search

    static Page search(String query, Object token) throws Exception {
        init(initRegion);
        SearchQueryHandler h = YT.getSearchQHFactory().fromQuery(query, Collections.singletonList("videos"), "");
        if (token == null) {
            SearchInfo si = SearchInfo.getInfo(YT, h);
            return new Page(cards(si.getRelatedItems()), si.getNextPage());
        }
        ListExtractor.InfoItemsPage<InfoItem> p =
            SearchInfo.getMoreItems(YT, h, (org.schabi.newpipe.extractor.Page) token);
        return new Page(cards(p.getItems()), p.getNextPage());
    }

    static Page searchMore(String query, Object token) throws Exception { return search(query, token); }

    // ------------------------------------------------------------------ video info + streams

    static Info info(String id) throws Exception {
        init(initRegion);
        Exception last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                return build(id, StreamInfo.getInfo(YT, "https://www.youtube.com/watch?v=" + id));
            } catch (Exception e) {
                last = e;
                try { Thread.sleep(500L * (attempt + 1)); }
                catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
            }
        }
        throw last == null ? new Exception("Unknown error") : last;
    }

    private static boolean usable(Stream s) {
        return s != null && s.isUrl() && s.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
            && s.getContent() != null && !s.getContent().isEmpty();
    }

    private static int heightOf(VideoStream v) {
        String r = v.getResolution() == null ? "" : v.getResolution().replaceAll("[^0-9].*$", "");
        try { return r.isEmpty() ? 0 : Integer.parseInt(r); } catch (Exception e) { return 0; }
    }

    private static VS vs(VideoStream v) {
        VS o = new VS();
        o.url = v.getContent();
        o.height = heightOf(v);
        o.suffix = v.getFormat() == null ? "" : v.getFormat().getSuffix();
        o.codec = v.getCodec() == null ? "" : v.getCodec();
        return o;
    }

    private static Info build(String id, StreamInfo si) {
        Info i = new Info();
        i.id = id;
        i.title = nz(si.getName());
        i.uploader = nz(si.getUploaderName());
        i.uploaderUrl = nz(si.getUploaderUrl());
        i.channelId = channelId(i.uploaderUrl);
        i.avatar = bestImage(si.getUploaderAvatars());
        i.views = si.getViewCount();
        i.likes = si.getLikeCount();
        i.subs = si.getUploaderSubscriberCount();
        i.duration = si.getDuration();
        i.uploadDate = nz(si.getTextualUploadDate());
        Description d = si.getDescription();
        if (d != null) { i.desc = nz(d.getContent()); i.descHtml = d.getType() == Description.HTML; }
        i.hls = nz(si.getHlsUrl());
        i.dash = nz(si.getDashMpdUrl());
        StreamType t = si.getStreamType();
        i.live = t == StreamType.LIVE_STREAM || t == StreamType.AUDIO_LIVE_STREAM;
        if (si.getVideoStreams() != null)
            for (VideoStream v : si.getVideoStreams()) if (usable(v) && !v.isVideoOnly()) i.muxed.add(vs(v));
        if (si.getVideoOnlyStreams() != null)
            for (VideoStream v : si.getVideoOnlyStreams()) if (usable(v)) i.videoOnly.add(vs(v));
        if (si.getAudioStreams() != null) {
            for (AudioStream a : si.getAudioStreams()) {
                if (!usable(a)) continue;
                if (a.getContent().contains("dubbed")) continue; // skip auto-dubbed language tracks
                AS o = new AS();
                o.url = a.getContent();
                o.bitrate = a.getAverageBitrate();
                o.suffix = a.getFormat() == null ? "" : a.getFormat().getSuffix();
                i.audio.add(o);
            }
        }
        if (si.getRelatedItems() != null) {
            for (InfoItem it : si.getRelatedItems()) {
                if (!(it instanceof StreamInfoItem)) continue;
                StreamInfoItem s = (StreamInfoItem) it;
                if (s.isShortFormContent()) continue;
                JSONObject o = card(s);
                if (o != null) i.related.add(o);
            }
        }
        return i;
    }

    // ---- parsing YouTube's "next" response (used when direct stream extraction is blocked)

    private static JSONObject findObj(Object node, String key) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject hit = o.optJSONObject(key);
            if (hit != null) return hit;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                JSONObject r = findObj(o.opt(it.next()), key);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                JSONObject r = findObj(a.opt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static void collect(Object node, String key, List<JSONObject> out) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                Object v = o.opt(k);
                if (k.equals(key) && v instanceof JSONObject) out.add((JSONObject) v);
                else collect(v, key, out);
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) collect(a.opt(i), key, out);
        }
    }

    private static String firstString(Object node, String key) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            Object v = o.opt(key);
            if (v instanceof String && !((String) v).isEmpty()) return (String) v;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String r = firstString(o.opt(it.next()), key);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String r = firstString(a.opt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static String lastThumb(JSONObject holder) {
        if (holder == null) return "";
        JSONArray th = holder.optJSONArray("thumbnails");
        if (th == null || th.length() == 0) return "";
        String u = th.optJSONObject(th.length() - 1).optString("url", "");
        return u.startsWith("//") ? "https:" + u : u;
    }

    private static long parseClock(String s) {
        if (s == null || s.isEmpty()) return 0;
        long t = 0;
        try { for (String p : s.split(":")) t = t * 60 + Long.parseLong(p.trim()); } catch (Exception e) { return 0; }
        return t;
    }

    static Info webInfo(String id, JSONObject r) {
        Info i = new Info();
        i.id = id;
        JSONObject owner = findObj(r, "videoOwnerRenderer");
        if (owner != null) {
            i.uploader = Auth.textOf(owner.opt("title"));
            i.avatar = lastThumb(owner.optJSONObject("thumbnail"));
            i.subsText = Auth.textOf(owner.opt("subscriberCountText"));
            JSONObject nav = owner.optJSONObject("navigationEndpoint");
            JSONObject be = nav == null ? null : nav.optJSONObject("browseEndpoint");
            if (be != null) i.channelId = be.optString("browseId", "");
        }
        JSONObject primary = findObj(r, "videoPrimaryInfoRenderer");
        if (primary != null) {
            JSONObject t = primary.optJSONObject("title");
            JSONArray runs = t == null ? null : t.optJSONArray("runs");
            if (runs != null) {
                StringBuilder sb = new StringBuilder();
                for (int k = 0; k < runs.length(); k++) sb.append(runs.optJSONObject(k).optString("text", ""));
                i.title = sb.toString();
            }
        }
        JSONObject seg = findObj(r, "segmentedLikeDislikeButtonViewModel");
        if (seg != null) {
            String t = firstString(seg.optJSONObject("likeButtonViewModel"), "title");
            if (t != null) i.likesText = t;
        }
        List<JSONObject> comps = new ArrayList<>();
        collect(r, "compactVideoRenderer", comps);
        for (JSONObject c : comps) {
            try {
                String vid = c.optString("videoId", "");
                if (vid.isEmpty()) continue;
                JSONObject o = new JSONObject();
                o.put("url", "/watch?v=" + vid);
                o.put("title", Auth.textOf(c.opt("title")));
                String by = Auth.textOf(c.opt("longBylineText"));
                if (by.isEmpty()) by = Auth.textOf(c.opt("shortBylineText"));
                o.put("uploaderName", by);
                o.put("thumbnail", "https://i.ytimg.com/vi/" + vid + "/mqdefault.jpg");
                JSONObject ct = c.optJSONObject("channelThumbnail");
                o.put("uploaderAvatar", lastThumb(ct));
                o.put("views", -1);
                String vt = Auth.textOf(c.opt("viewCountText"));
                String pt = Auth.textOf(c.opt("publishedTimeText"));
                o.put("uploadedDate", vt.isEmpty() ? pt : (pt.isEmpty() ? vt : vt + "  ·  " + pt));
                o.put("duration", parseClock(Auth.textOf(c.opt("lengthText"))));
                i.related.add(o);
            } catch (Exception ignored) { }
        }
        return i;
    }

    private static String nz(String s) { return s == null || s.equals("null") ? "" : s; }

    // ------------------------------------------------------------------ extras

    /** SponsorBlock segments [start,end] in seconds that should be skipped. */
    static List<double[]> sponsorSegments(String id) {
        List<double[]> out = new ArrayList<>();
        try {
            String cats = java.net.URLEncoder.encode("[\"sponsor\",\"selfpromo\",\"interaction\"]", "UTF-8");
            Request r = new Request.Builder()
                .url("https://sponsor.ajay.app/api/skipSegments?videoID=" + id + "&categories=" + cats).build();
            try (Response resp = Net.HTTP.newBuilder().callTimeout(8, TimeUnit.SECONDS).build().newCall(r).execute()) {
                if (!resp.isSuccessful() || resp.body() == null) return out;
                JSONArray a = new JSONArray(resp.body().string());
                for (int k = 0; k < a.length(); k++) {
                    JSONObject o = a.optJSONObject(k);
                    if (o == null) continue;
                    String type = o.optString("actionType", "skip");
                    if (!type.equals("skip")) continue;
                    JSONArray seg = o.optJSONArray("segment");
                    if (seg == null || seg.length() < 2) continue;
                    double s = seg.optDouble(0, -1), e = seg.optDouble(1, -1);
                    if (s >= 0 && e > s) out.add(new double[]{s, e});
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Latest uploads of one channel from YouTube's public RSS feed (fast, no login needed). */
    static Page rss(String channelId) throws Exception {
        Request r = new Request.Builder().url("https://www.youtube.com/feeds/videos.xml?channel_id=" + channelId)
            .header("User-Agent", Net.UA_WEB).build();
        String xml;
        try (Response resp = Net.HTTP.newCall(r).execute()) {
            if (!resp.isSuccessful() || resp.body() == null) throw new Exception("Feed HTTP " + resp.code());
            xml = resp.body().string();
        }
        JSONArray out = new JSONArray();
        String author = unescape(first(xml, "<author>\\s*<name>(.*?)</name>"));
        Matcher m = Pattern.compile("<entry>(.*?)</entry>", Pattern.DOTALL).matcher(xml);
        while (m.find()) {
            String e = m.group(1);
            if (e.contains("/shorts/")) continue;
            String id = first(e, "<yt:videoId>(.*?)</yt:videoId>");
            if (id.isEmpty()) continue;
            JSONObject o = new JSONObject();
            o.put("url", "/watch?v=" + id);
            o.put("title", unescape(first(e, "<title>(.*?)</title>")));
            o.put("uploaderName", author);
            o.put("thumbnail", "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg");
            String views = first(e, "<media:statistics views=\"(\\d+)\"");
            o.put("views", views.isEmpty() ? -1 : Long.parseLong(views));
            long when = 0;
            try { when = java.time.OffsetDateTime.parse(first(e, "<published>(.*?)</published>")).toInstant().toEpochMilli(); }
            catch (Exception ignored) { }
            o.put("uploaded", when);
            o.put("uploadedDate", when > 0 ? Ui.ago(when) : "");
            o.put("duration", 0);
            out.put(o);
        }
        return new Page(out, null);
    }

    private static String first(String s, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.DOTALL).matcher(s);
        return m.find() ? m.group(1).trim() : "";
    }

    private static String unescape(String s) {
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'");
    }
}
