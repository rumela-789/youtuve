package com.manik.youtubeweb;

import android.content.Context;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.ResolvingDataSource;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/** Shared HTTP clients: one for API calls, one for the media player, plus the extractor's Downloader. */
final class Net {
    static final String UA_WEB = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
        + "Chrome/131.0.0.0 Mobile Safari/537.36";
    private static final String UA_ANDROID = "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip";
    private static final String UA_ANDROID_VR = "com.google.android.apps.youtube.vr.oculus/1.62.27 "
        + "(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip";
    private static final String UA_IOS = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)";

    static final OkHttpClient HTTP = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS).build();

    private static final OkHttpClient PLAYER_HTTP = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true).build();

    private static DataSource.Factory dsf;
    private static volatile String sessionCookie = "";

    static void setCookie(String c) { sessionCookie = c == null ? "" : c; }

    private Net() {}

    /** Data source for ExoPlayer. Picks the User-Agent that matches the YouTube client the stream URL was made for. */
    static synchronized DataSource.Factory dataSourceFactory(Context c) {
        if (dsf == null) {
            OkHttpDataSource.Factory ok = new OkHttpDataSource.Factory(PLAYER_HTTP);
            DefaultDataSource.Factory def = new DefaultDataSource.Factory(c.getApplicationContext(), ok);
            dsf = new ResolvingDataSource.Factory(def, new ResolvingDataSource.Resolver() {
                @Override public DataSpec resolveDataSpec(DataSpec spec) throws IOException {
                    String u = spec.uri.toString();
                    if (!u.contains("googlevideo.com") && !u.contains("youtube.com")) return spec;
                    Map<String, String> h = new HashMap<>(spec.httpRequestHeaders);
                    if (u.contains("c=ANDROID_VR")) h.put("User-Agent", UA_ANDROID_VR);
                    else if (u.contains("c=ANDROID")) h.put("User-Agent", UA_ANDROID);
                    else if (u.contains("c=IOS")) h.put("User-Agent", UA_IOS);
                    else {
                        h.put("User-Agent", UA_WEB);
                        h.put("Origin", "https://www.youtube.com");
                        h.put("Referer", "https://www.youtube.com/");
                    }
                    return spec.withRequestHeaders(h);
                }
            });
        }
        return dsf;
    }

    private static boolean isYoutubeHost(String url) {
        try {
            String h = java.net.URI.create(url).getHost();
            return h != null && (h.equals("youtube.com") || h.endsWith(".youtube.com"));
        } catch (Exception e) { return false; }
    }

    private static boolean isWebClientBody(byte[] body) {
        String s = new String(body, java.nio.charset.StandardCharsets.UTF_8);
        return java.util.regex.Pattern.compile("\"clientName\"\\s*:\\s*\"(WEB|MWEB|TVHTML5)[A-Z_0-9]*\"")
            .matcher(s).find();
    }

    /** HTTP layer used by NewPipeExtractor. */
    static final class Dl extends Downloader {
        static final Dl INSTANCE = new Dl();

        @Override public Response execute(Request request) throws IOException, ReCaptchaException {
            String method = request.httpMethod();
            String url = request.url();
            byte[] data = request.dataToSend();
            RequestBody body = null;
            if (data != null) body = RequestBody.create(data, (MediaType) null);
            else if (method.equals("POST") || method.equals("PUT") || method.equals("PATCH"))
                body = RequestBody.create(new byte[0], (MediaType) null);
            okhttp3.Request.Builder rb = new okhttp3.Request.Builder().url(url).method(method, body)
                .header("User-Agent", UA_WEB);
            String existingCookie = "";
            for (Map.Entry<String, List<String>> e : request.headers().entrySet()) {
                String name = e.getKey();
                // Let OkHttp negotiate and transparently decode gzip itself.
                if (name == null || name.equalsIgnoreCase("Accept-Encoding")) continue;
                if (name.equalsIgnoreCase("Cookie")) { existingCookie = String.join("; ", e.getValue()); continue; }
                rb.removeHeader(name);
                for (String v : e.getValue()) rb.addHeader(name, v);
            }
            String cookie = existingCookie;
            String session = sessionCookie;
            if (!session.isEmpty() && isYoutubeHost(url)) {
                // Signed-in requests are not subject to the anonymous "confirm you're not a bot" block.
                cookie = existingCookie.isEmpty() ? session : existingCookie + "; " + session;
                if (url.contains("/youtubei/v1/") && data != null && isWebClientBody(data)) {
                    try {
                        rb.header("Authorization", Auth.authHeader(session));
                        rb.header("X-Goog-AuthUser", "0");
                        rb.header("X-Origin", "https://www.youtube.com");
                        rb.header("Origin", "https://www.youtube.com");
                    } catch (Exception ignored) { }
                }
            }
            if (!cookie.isEmpty()) rb.header("Cookie", cookie);
            try (okhttp3.Response r = HTTP.newCall(rb.build()).execute()) {
                if (r.code() == 429) throw new ReCaptchaException("Rate limited / captcha requested", url);
                ResponseBody rbody = r.body();
                String text = rbody == null ? null : rbody.string();
                return new Response(r.code(), r.message(), r.headers().toMultimap(), text, r.request().url().toString());
            }
        }
    }
}
