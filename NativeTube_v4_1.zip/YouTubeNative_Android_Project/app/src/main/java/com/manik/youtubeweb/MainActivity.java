package com.manik.youtubeweb;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** YouTubee home: Home / Trending / Subscriptions / History / You (profile) + the mini player. */
public class MainActivity extends Activity implements VideoCardView.Listener {
    private static final int RC_LOGIN = 9001;
    private static final int RC_VOICE = 9002;

    private static final String[] TOPICS = {"music", "bangla natok", "gaming", "news today", "movie trailers",
        "comedy", "bangla song", "sports highlights", "technology", "podcast", "cooking", "travel vlog",
        "live now", "science", "cartoon"};
    private static final String[] TOPIC_SUFFIX = {"", " latest", " best", " 2026"};
    private static final String[] CHIPS = {"All", "Music", "Gaming", "News", "Live", "Movies", "Comedy",
        "Sports", "Tech", "Bangla"};
    private static final String[] TABS = {"home", "trending", "subs", "history", "profile"};
    private static final String[] TAB_LABELS = {"Home", "Trending", "Subs", "History", "You"};
    private static final int[] TAB_ICONS = {R.drawable.ic_home, R.drawable.ic_trending, R.drawable.ic_subs,
        R.drawable.ic_history, R.drawable.ic_profile};
    private static final String[][] REGIONS = {{"US", "United States"}, {"GB", "United Kingdom"},
        {"BD", "Bangladesh"}, {"IN", "India"}, {"PK", "Pakistan"}, {"CA", "Canada"}, {"AU", "Australia"},
        {"DE", "Germany"}, {"FR", "France"}, {"BR", "Brazil"}, {"JP", "Japan"}, {"SA", "Saudi Arabia"},
        {"AE", "United Arab Emirates"}, {"MY", "Malaysia"}};
    private static final String[][] QUALITIES = {{"auto", "Auto (up to 720p)"}, {"1080", "1080p"}, {"720", "720p"},
        {"480", "480p"}, {"360", "360p"}};

    private interface BoolCb { void on(boolean v); }

    private SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(6);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root, nav, searchRow, chipRow, emptyView;
    private HorizontalScrollView chipScroll;
    private EditText searchBox;
    private TextView status;
    private ScrollView profileScroll;
    private RecyclerView recycler;
    private SwipeRefreshLayout swipe;
    private boolean manualRefresh = false;
    private LinearLayoutManager lm;
    private FeedAdapter adapter;
    private final LinearLayout[] navItems = new LinearLayout[5];

    // mini player (the small bar at the bottom, like YouTube's)
    private FrameLayout miniBar;
    private PlayerView miniVideo;
    private ImageView miniThumb, miniPlay;
    private TextView miniTitle, miniBy;
    private ProgressBar miniProg;
    private Player.Listener miniListener;
    private boolean miniAttached = false;

    private String tab = "", searchQuery = null, chip = "All";
    private Object nextTok = null, lastTok = null;
    private String lastError = null;
    private final Set<String> seen = new HashSet<>();
    private int gen = 0, pending = 0, topicIndex = 0;
    private boolean loadingMore = false, showingCache = false, prefetch = false;
    private long lastBack = 0;

    private String region() { return prefs.getString("region", "US"); }

    /** Whether background play is switched on for this particular video (per-video setting). */
    private boolean bgOn(String id) { return id != null && prefs.getBoolean("bg_" + id, false); }

    private static String regionName(String code) {
        for (String[] r : REGIONS) if (r[0].equals(code)) return r[1];
        return "";
    }

    // ------------------------------------------------------------------ lifecycle

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = Ui.prefs(this);
        Ui.load(this);
        PoTokens.install(this);
        Yt.init(region());
        Net.setCookie(Auth.cookie(this));
        PoTokens.warmUp();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 701);
        }
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        if (!Ui.dark) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        build();
        String restore = prefs.getString("restore_tab", "home");
        prefs.edit().remove("restore_tab").apply();
        switchTab(restore);
        refreshAccountInBackground();
    }

    @Override protected void onDestroy() {
        // the mini player's video belongs to us now: stop it unless this video may play in the background.
        // (skip when the activity is just being recreated, e.g. theme change)
        if (!isChangingConfigurations() && PlaybackService.miniActive && !bgOn(PlaybackService.curId)
            && PlaybackService.exo != null) {
            PlaybackService.exo.stop();
            PlaybackService.miniActive = false;
        }
        pool.shutdownNow();
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (!tab.equals("home") || searchQuery != null) {
            searchBox.setText("");
            chip = "All";
            updateChips();
            tab = "";
            switchTab("home");
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { finish(); return; }
        lastBack = now;
        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ layout

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        // ---- top bar: YouTube logo + "Youtube Premium" wordmark (like the app header)
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(14), Ui.dp(6));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_yt_logo);
        top.addView(logo, new LinearLayout.LayoutParams(Ui.dp(30), Ui.dp(30)));
        TextView brand = Ui.text(this, "Youtube", 20, true, Ui.fg);
        brand.setPadding(Ui.dp(9), 0, 0, 0);
        top.addView(brand);
        TextView brand2 = Ui.text(this, "Premium", 20, false, Ui.fg);
        top.addView(brand2);
        root.addView(top);

        // ---- YouTube-style search bar: rounded pill with the search icon inside + voice search mic
        searchRow = new LinearLayout(this);
        searchRow.setPadding(Ui.dp(12), Ui.dp(4), Ui.dp(12), Ui.dp(8));
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.rect(Ui.surface, 22));
        ImageView si = Ui.icon(this, R.drawable.ic_search, Ui.muted, 19);
        si.setPadding(Ui.dp(14), 0, Ui.dp(10), 0);
        bar.addView(si, new LinearLayout.LayoutParams(Ui.dp(43), Ui.dp(46)));
        si.setOnClickListener(v -> doSearch());
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setTextColor(Ui.fg);
        searchBox.setHintTextColor(Ui.muted);
        searchBox.setHint("Search YouTube");
        searchBox.setTextSize(15);
        searchBox.setBackground(null);
        searchBox.setOnEditorActionListener((v, action, event) -> { doSearch(); return true; });
        bar.addView(searchBox, new LinearLayout.LayoutParams(0, Ui.dp(46), 1));
        ImageView mic = Ui.icon(this, R.drawable.ic_mic, Ui.fg, 20);
        mic.setPadding(Ui.dp(12), 0, Ui.dp(14), 0);
        mic.setOnClickListener(v -> voiceSearch());
        bar.addView(mic, new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(46)));
        searchRow.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(46)));
        root.addView(searchRow);

        chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setPadding(Ui.dp(14), Ui.dp(2), Ui.dp(14), Ui.dp(8));
        chipScroll.addView(chipRow);
        root.addView(chipScroll);
        updateChips();

        status = Ui.text(this, "", 12, false, Ui.muted);
        status.setPadding(Ui.dp(18), Ui.dp(2), Ui.dp(18), Ui.dp(4));
        root.addView(status);

        FrameLayout content = new FrameLayout(this);
        recycler = new RecyclerView(this);
        lm = new LinearLayoutManager(this);
        recycler.setLayoutManager(lm);
        adapter = new FeedAdapter();
        recycler.setAdapter(adapter);
        recycler.setItemAnimator(null);
        recycler.setItemViewCacheSize(8);
        recycler.setClipToPadding(false);
        recycler.setPadding(0, 0, 0, Ui.dp(8));
        recycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy <= 0 || adapter.skeleton) return;
                if (lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 6) loadMore();
            }
        });
        swipe = new SwipeRefreshLayout(this);
        swipe.setColorSchemeColors(Ui.accent);
        swipe.setProgressBackgroundColorSchemeColor(Ui.surface);
        swipe.addView(recycler, new ViewGroup.LayoutParams(-1, -1));
        swipe.setOnRefreshListener(() -> {
            manualRefresh = true;
            reloadCurrent();
            swipe.postDelayed(() -> swipe.setRefreshing(false), 900);
        });
        content.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
        emptyView = new LinearLayout(this);
        emptyView.setOrientation(LinearLayout.VERTICAL);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(Ui.dp(28), Ui.dp(20), Ui.dp(28), Ui.dp(60));
        emptyView.setVisibility(View.GONE);
        content.addView(emptyView, new FrameLayout.LayoutParams(-1, -1));
        profileScroll = new ScrollView(this);
        profileScroll.setVisibility(View.GONE);
        content.addView(profileScroll, new FrameLayout.LayoutParams(-1, -1));
        buildMiniBar(content);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        View divider = new View(this);
        divider.setBackgroundColor(Ui.line);
        root.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        nav = new LinearLayout(this);
        nav.setBackgroundColor(Ui.bg);
        nav.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(4), Ui.dp(6));
        for (int i = 0; i < TABS.length; i++) {
            final String id = TABS[i];
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setOnClickListener(v -> switchTab(id));
            navItems[i] = item;
            nav.addView(item, new LinearLayout.LayoutParams(0, Ui.dp(52), 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    // ------------------------------------------------------------------ mini player

    /** The small floating player at the bottom of the feed, shown after backing out of a video (like YouTube). */
    private void buildMiniBar(FrameLayout content) {
        miniBar = new FrameLayout(this);
        miniBar.setBackground(Ui.rect(Ui.surface, 14));
        miniBar.setElevation(Ui.dp(10));
        miniBar.setVisibility(View.GONE);
        miniBar.setClipToOutline(true);
        miniBar.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(14));
            }
        });

        miniProg = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        miniProg.setMax(1000);
        miniProg.getProgressDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
        miniBar.addView(miniProg, new FrameLayout.LayoutParams(-1, Ui.dp(3), Gravity.TOP));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-1, Ui.dp(59), Gravity.BOTTOM);
        miniBar.addView(row, rp);

        miniVideo = new PlayerView(this);
        miniVideo.setUseController(false);
        miniVideo.setBackgroundColor(0xFF000000);
        row.addView(miniVideo, new LinearLayout.LayoutParams(Ui.dp(105), Ui.dp(59)));
        miniThumb = new ImageView(this);
        miniThumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        miniThumb.setBackgroundColor(0xFF000000);
        miniThumb.setVisibility(View.GONE);
        row.addView(miniThumb, new LinearLayout.LayoutParams(Ui.dp(105), Ui.dp(59)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(10), 0, Ui.dp(4), 0);
        miniTitle = Ui.text(this, "", 13, true, Ui.fg);
        miniTitle.setMaxLines(1);
        miniTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        miniBy = Ui.text(this, "", 11.5f, false, Ui.muted);
        miniBy.setMaxLines(1);
        miniBy.setEllipsize(android.text.TextUtils.TruncateAt.END);
        miniBy.setPadding(0, Ui.dp(2), 0, 0);
        col.addView(miniTitle);
        col.addView(miniBy);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        miniPlay = Ui.icon(this, R.drawable.ic_pause, Ui.fg, 22);
        miniPlay.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        miniPlay.setOnClickListener(v -> {
            ExoPlayer exo = PlaybackService.exo;
            if (exo != null) exo.setPlayWhenReady(!exo.getPlayWhenReady());
            updateMiniProgress();
        });
        row.addView(miniPlay, new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38)));
        ImageView close = Ui.icon(this, R.drawable.ic_close, Ui.muted, 18);
        close.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(10), Ui.dp(8));
        close.setOnClickListener(v -> closeMini());
        row.addView(close, new LinearLayout.LayoutParams(Ui.dp(36), Ui.dp(36)));

        miniBar.setOnClickListener(v -> {
            if (PlaybackService.curId == null || PlaybackService.curId.isEmpty()) return;
            Intent in = new Intent(this, PlayerActivity.class);
            in.putExtra("video_id", PlaybackService.curId);
            in.putExtra("title", PlaybackService.curTitle);
            in.putExtra("uploader", PlaybackService.curUploader);
            in.putExtra("thumbnail", PlaybackService.curThumb);
            in.putExtra("from_mini", true);
            startActivity(in);
        });

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, Ui.dp(62), Gravity.BOTTOM);
        lp.leftMargin = Ui.dp(10);
        lp.rightMargin = Ui.dp(10);
        lp.bottomMargin = Ui.dp(8);
        content.addView(miniBar, lp);
    }

    private void closeMini() {
        if (PlaybackService.exo != null) PlaybackService.exo.stop();
        PlaybackService.miniActive = false;
        updateMini();
    }

    private final Runnable miniTicker = new Runnable() {
        @Override public void run() {
            if (miniBar.getVisibility() != View.VISIBLE) return;
            updateMiniProgress();
            handler.postDelayed(this, 500);
        }
    };

    private void updateMiniProgress() {
        ExoPlayer exo = PlaybackService.exo;
        if (exo == null) return;
        long d = exo.getDuration();
        long p = exo.getCurrentPosition();
        miniProg.setProgress(d <= 0 ? 0 : (int) (1000 * p / d));
        miniPlay.setImageResource(exo.getPlayWhenReady() ? R.drawable.ic_pause : R.drawable.ic_play);
        miniPlay.setColorFilter(Ui.fg, PorterDuff.Mode.SRC_IN);
    }

    private void detachMini() {
        if (!miniAttached) return;
        miniVideo.setPlayer(null);
        if (PlaybackService.exo != null && miniListener != null) PlaybackService.exo.removeListener(miniListener);
        miniListener = null;
        miniAttached = false;
        handler.removeCallbacks(miniTicker);
    }

    /** Shows/hides the mini bar to match the playback service state. */
    private void updateMini() {
        ExoPlayer exo = PlaybackService.exo;
        boolean show = PlaybackService.miniActive && exo != null && PlaybackService.curId != null
            && !PlaybackService.curId.isEmpty()
            && exo.getPlaybackState() != Player.STATE_IDLE && exo.getPlaybackState() != Player.STATE_ENDED;
        miniBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) { detachMini(); return; }
        miniTitle.setText(PlaybackService.curTitle);
        miniBy.setText(PlaybackService.curUploader);
        if (PlaybackService.curAudio) {
            miniVideo.setVisibility(View.GONE);
            miniThumb.setVisibility(View.VISIBLE);
            String th = PlaybackService.curThumb;
            if (th != null && !th.isEmpty())
                Glide.with(this).load(th).override(240, 135).centerCrop().into(miniThumb);
        } else {
            miniThumb.setVisibility(View.GONE);
            miniVideo.setVisibility(View.VISIBLE);
        }
        if (!miniAttached && exo != null) {
            if (!PlaybackService.curAudio) miniVideo.setPlayer(exo);
            miniListener = new Player.Listener() {
                @Override public void onPlaybackStateChanged(int state) {
                    if (state == Player.STATE_ENDED || state == Player.STATE_IDLE) updateMini();
                }
                @Override public void onIsPlayingChanged(boolean playing) { updateMiniProgress(); }
            };
            exo.addListener(miniListener);
            miniAttached = true;
            handler.removeCallbacks(miniTicker);
            handler.postDelayed(miniTicker, 100);
        }
        updateMiniProgress();
    }

    // ------------------------------------------------------------------ voice search

    private void voiceSearch() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Search YouTube");
            startActivityForResult(i, RC_VOICE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Voice search is not available on this phone", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ nav / chips

    private void updateNav() {
        for (int i = 0; i < TABS.length; i++) {
            boolean sel = TABS[i].equals(tab);
            LinearLayout item = navItems[i];
            item.removeAllViews();
            int color = sel ? Ui.fg : Ui.muted;
            ImageView ic = Ui.icon(this, TAB_ICONS[i], color, 25);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(Ui.dp(25), Ui.dp(25));
            ip.gravity = Gravity.CENTER;
            FrameLayout wrap = new FrameLayout(this);
            wrap.addView(ic, ip);
            item.addView(wrap, new LinearLayout.LayoutParams(Ui.dp(60), Ui.dp(40)));
            item.setContentDescription(TAB_LABELS[i]);
        }
    }

    private void updateChips() {
        chipRow.removeAllViews();
        for (final String c : CHIPS) {
            boolean sel = c.equals(chip);
            TextView t = Ui.text(this, c, 13, sel, sel ? Ui.pillOnFg() : Ui.fg);
            t.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
            t.setBackground(Ui.rect(sel ? Ui.pillOn() : Ui.surface, 20));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.rightMargin = Ui.dp(8);
            chipRow.addView(t, p);
            t.setOnClickListener(v -> {
                chip = c;
                updateChips();
                if (c.equals("All")) { searchBox.setText(""); loadHome(); }
                else { searchBox.setText(c); startSearch(queryFor(c)); }
            });
        }
    }

    private String queryFor(String c) {
        switch (c) {
            case "Live": return "live now";
            case "Movies": return "movie trailers";
            case "Tech": return "technology reviews";
            case "Bangla": return "bangla natok";
            case "News": return "news today";
            case "Sports": return "sports highlights";
            default: return c;
        }
    }

    private void switchTab(String t) {
        if (t.equals(tab) && searchQuery == null && adapter.data.size() > 0 && !t.equals("profile")) {
            recycler.smoothScrollToPosition(0);
            return;
        }
        tab = t;
        boolean feed = t.equals("home") || t.equals("trending");
        searchRow.setVisibility(feed ? View.VISIBLE : View.GONE);
        chipScroll.setVisibility(t.equals("home") ? View.VISIBLE : View.GONE);
        updateNav();
        switch (t) {
            case "trending": loadTrending(); break;
            case "subs": loadSubs(); break;
            case "history": loadHistory(); break;
            case "profile": showProfile(); break;
            default: loadHome(); break;
        }
    }

    // ------------------------------------------------------------------ feed adapter

    private final class FeedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        final List<JSONObject> data = new ArrayList<>();
        boolean skeleton = false, footer = false;

        @Override public int getItemCount() { return skeleton ? 4 : data.size() + (footer ? 1 : 0); }

        @Override public int getItemViewType(int p) {
            if (skeleton) return 0;
            return p < data.size() ? 1 : 2;
        }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) {
            View v;
            if (type == 1) v = new VideoCardView(MainActivity.this);
            else if (type == 0) v = skeletonView();
            else v = footerView();
            v.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
            int type = getItemViewType(pos);
            if (type == 1) {
                ((VideoCardView) h.itemView).bind(data.get(pos), MainActivity.this);
            } else if (type == 0) {
                ObjectAnimator a = ObjectAnimator.ofFloat(h.itemView, "alpha", 0.45f, 1f);
                a.setDuration(750);
                a.setRepeatCount(ValueAnimator.INFINITE);
                a.setRepeatMode(ValueAnimator.REVERSE);
                a.start();
                h.itemView.setTag(a);
            }
        }

        @Override public void onViewDetachedFromWindow(RecyclerView.ViewHolder h) {
            Object t = h.itemView.getTag();
            if (t instanceof ObjectAnimator) {
                ((ObjectAnimator) t).cancel();
                h.itemView.setAlpha(1f);
                h.itemView.setTag(null);
            }
        }

        void clear() { data.clear(); skeleton = false; footer = false; notifyDataSetChanged(); }

        void showSkeleton() { data.clear(); footer = false; skeleton = true; notifyDataSetChanged(); }

        void addAll(List<JSONObject> add) {
            if (add.isEmpty()) return;
            if (skeleton) {
                skeleton = false;
                data.addAll(add);
                notifyDataSetChanged();
            } else {
                int start = data.size();
                data.addAll(add);
                notifyItemRangeInserted(start, add.size());
            }
        }

        void setFooter(boolean f) {
            if (skeleton || footer == f) return;
            footer = f;
            if (f) notifyItemInserted(data.size()); else notifyItemRemoved(data.size());
        }
    }

    private View skeletonView() {
        int m = Ui.dp(12);
        int w = Math.min(getResources().getDisplayMetrics().widthPixels, Ui.dp(640)) - 2 * m;
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(m, Ui.dp(8), m, Ui.dp(10));
        View t = new View(this);
        t.setBackground(Ui.rect(Ui.surface2, 14));
        c.addView(t, new LinearLayout.LayoutParams(-1, w * 9 / 16));
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, Ui.dp(12), 0, 0);
        View av = new View(this);
        av.setBackground(Ui.oval(Ui.surface2));
        row.addView(av, new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, 0, 0);
        View l1 = new View(this);
        l1.setBackground(Ui.rect(Ui.surface2, 6));
        col.addView(l1, new LinearLayout.LayoutParams(-1, Ui.dp(14)));
        View l2 = new View(this);
        l2.setBackground(Ui.rect(Ui.surface2, 6));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(w * 6 / 10, Ui.dp(12));
        p2.topMargin = Ui.dp(8);
        col.addView(l2, p2);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(row);
        return c;
    }

    private View footerView() {
        FrameLayout f = new FrameLayout(this);
        f.setPadding(0, Ui.dp(16), 0, Ui.dp(24));
        ProgressBar pb = new ProgressBar(this);
        pb.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
        f.addView(pb, new FrameLayout.LayoutParams(Ui.dp(28), Ui.dp(28), Gravity.CENTER));
        return f;
    }

    // ------------------------------------------------------------------ feed loading

    private void resetFeed() {
        gen++;
        adapter.clear();
        seen.clear();
        nextTok = null;
        lastTok = null;
        lastError = null;
        loadingMore = false;
        showingCache = false;
        prefetch = false;
        pending = 0;
        topicIndex = 0;
        emptyView.setVisibility(View.GONE);
        profileScroll.setVisibility(View.GONE);
        swipe.setVisibility(View.VISIBLE);
        status.setVisibility(View.VISIBLE);
        status.setOnClickListener(null);
        recycler.scrollToPosition(0);
    }

    private String nextTopic() {
        int n = TOPICS.length;
        String t = TOPICS[topicIndex % n] + TOPIC_SUFFIX[(topicIndex / n) % TOPIC_SUFFIX.length];
        topicIndex++;
        return t;
    }

    private void loadHome() {
        tab = "home";
        searchQuery = null;
        resetFeed();
        status.setText("Recommended for you");
        if (manualRefresh) {
            topicIndex = new java.util.Random().nextInt(TOPICS.length);
            manualRefresh = false;
            adapter.showSkeleton();
        } else if (!showCachedHome()) adapter.showSkeleton();
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        final String region = region();
        for (int k = 0; k < 4; k++) {
            final String q = nextTopic();
            jobs.add(() -> Yt.search(q, null));
        }
        runJobs(jobs, -1);
    }

    private void loadTrending() {
        tab = "trending";
        searchQuery = null;
        resetFeed();
        manualRefresh = false;
        status.setText("Trending now · " + region());
        adapter.showSkeleton();
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        final String region = region();
        final String rn = regionName(region);
        jobs.add(() -> Yt.search("trending now " + rn, null));
        jobs.add(() -> Yt.search("viral videos " + rn, null));
        jobs.add(() -> Yt.search("most popular today", null));
        runJobs(jobs, -1);
    }

    private void startSearch(final String q) {
        tab = "home";
        searchQuery = q;
        resetFeed();
        status.setText("Results for “" + q + "”  ·  tap to clear");
        status.setOnClickListener(v -> {
            searchBox.setText("");
            chip = "All";
            updateChips();
            loadHome();
        });
        adapter.showSkeleton();
        prefetch = true;
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        jobs.add(() -> Yt.search(q, null));
        runJobs(jobs, 0);
    }

    private void doSearch() {
        String q = searchBox.getText().toString().trim();
        if (q.isEmpty()) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        chip = "";
        updateChips();
        startSearch(q);
    }

    private void loadMore() {
        if (loadingMore || adapter.skeleton || adapter.data.isEmpty()) return;
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        int tokenJob = -1;
        if (tab.equals("home") && searchQuery == null) {
            for (int k = 0; k < 2; k++) {
                final String q = nextTopic();
                jobs.add(() -> Yt.search(q, null));
            }
        } else if (tab.equals("trending")) {
            for (int k = 0; k < 2; k++) {
                final String q = "trending " + nextTopic();
                jobs.add(() -> Yt.search(q, null));
            }
        } else if (tab.equals("home")) {
            if (nextTok == null || searchQuery == null) return;
            final String q = searchQuery;
            final Object t = nextTok;
            lastTok = t;
            nextTok = null;
            jobs.add(() -> Yt.searchMore(q, t));
            tokenJob = 0;
        } else {
            return;
        }
        loadingMore = true;
        adapter.setFooter(true);
        runJobs(jobs, tokenJob);
    }

    private void runJobs(final List<Callable<Yt.Page>> jobs, final int tokenJob) {
        final int g = gen;
        pending = jobs.size();
        for (int i = 0; i < jobs.size(); i++) {
            final int idx = i;
            final Callable<Yt.Page> job = jobs.get(i);
            pool.execute(() -> {
                Yt.Page p = null;
                String err = null;
                try { p = job.call(); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
                final Yt.Page fp = p;
                final String fe = err;
                runOnUiThread(() -> onJobDone(g, idx == tokenJob, fp, fe));
            });
        }
    }

    private void onJobDone(int g, boolean isTokenJob, Yt.Page p, String err) {
        if (g != gen) return;
        if (p != null) {
            if (showingCache && !Yt.playable(p.items, new HashSet<String>()).isEmpty()) {
                adapter.clear();
                seen.clear();
                showingCache = false;
            }
            adapter.addAll(Yt.playable(p.items, seen));
            if (isTokenJob) nextTok = p.next;
        } else {
            lastError = err;
            if (isTokenJob) nextTok = lastTok;
        }
        pending--;
        if (pending <= 0) jobsFinished();
    }

    private void jobsFinished() {
        loadingMore = false;
        adapter.setFooter(false);
        if (tab.equals("subs")) {
            Collections.sort(adapter.data, (a, b) -> Long.compare(b.optLong("uploaded", 0), a.optLong("uploaded", 0)));
            adapter.notifyDataSetChanged();
        }
        if (adapter.data.isEmpty()) {
            showEmpty("Couldn't load videos",
                (lastError == null ? "Please check your internet connection." : lastError)
                    + "\n\nCheck your connection and try again.",
                "Try again", this::reloadCurrent);
            return;
        }
        if (tab.equals("home") && searchQuery == null && !showingCache) cacheHome();
        if (prefetch) {
            prefetch = false;
            if (nextTok != null) { loadMore(); return; }
        }
        recycler.post(() -> {
            if (!adapter.skeleton && lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 3) loadMore();
        });
    }

    private void reloadCurrent() {
        if (tab.equals("home") && searchQuery != null) startSearch(searchQuery);
        else if (tab.equals("trending")) loadTrending();
        else if (tab.equals("subs")) loadSubs();
        else if (tab.equals("history")) loadHistory();
        else loadHome();
    }

    private void showEmpty(String title, String detail, String button, final Runnable action) {
        adapter.clear();
        emptyView.removeAllViews();
        TextView h = Ui.text(this, title, 18, true, Ui.fg);
        h.setGravity(Gravity.CENTER);
        emptyView.addView(h);
        TextView d = Ui.text(this, detail, 13, false, Ui.muted);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, Ui.dp(10), 0, Ui.dp(18));
        emptyView.addView(d);
        if (button != null && action != null) {
            TextView b = Ui.text(this, button, 14, true, Ui.onAccent);
            b.setGravity(Gravity.CENTER);
            b.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
            b.setBackground(Ui.gradient(24));
            b.setOnClickListener(v -> action.run());
            emptyView.addView(b, new LinearLayout.LayoutParams(-2, -2));
        }
        swipe.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
    }

    private boolean showCachedHome() {
        String s = prefs.getString("home_cache", "");
        if (s.isEmpty()) return false;
        try {
            List<JSONObject> l = Yt.playable(new JSONArray(s), seen);
            if (l.isEmpty()) return false;
            adapter.addAll(l);
            showingCache = true;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void cacheHome() {
        try {
            JSONArray a = new JSONArray();
            for (int i = 0; i < adapter.data.size() && i < 40; i++) a.put(adapter.data.get(i));
            prefs.edit().putString("home_cache", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void loadHistory() {
        tab = "history";
        searchQuery = null;
        resetFeed();
        try {
            JSONArray items = new JSONArray(prefs.getString("watch_history", "[]"));
            status.setText(items.length() + " recently watched");
            if (items.length() == 0) {
                showEmpty("No history yet", "Videos you watch will show up here.", null, null);
                return;
            }
            List<JSONObject> l = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o != null) l.add(o);
            }
            adapter.addAll(l);
        } catch (Exception e) {
            showEmpty("Could not read history", String.valueOf(e.getMessage()), null, null);
        }
    }

    private void loadSubs() {
        tab = "subs";
        searchQuery = null;
        resetFeed();
        status.setText("Latest from your subscriptions");
        if (!Auth.signedIn(this)) {
            showEmpty("Sign in to see subscriptions",
                "Sign in with your Google account to see new videos from the channels you follow.",
                "Sign in with Google", this::signIn);
            return;
        }
        JSONArray subs = readSubs();
        adapter.showSkeleton();
        if (subs.length() == 0) { fetchSubscriptions(true); return; }
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        for (int i = 0; i < subs.length() && i < 40; i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s == null) continue;
            final String id = s.optString("id", "");
            if (id.isEmpty()) continue;
            jobs.add(() -> Yt.rss(id));
        }
        if (jobs.isEmpty()) {
            showEmpty("No subscriptions found", "Subscribe to some channels first.", null, null);
            return;
        }
        status.setText("Latest from " + subs.length() + " subscribed channels");
        runJobs(jobs, -1);
    }

    private JSONArray readSubs() {
        try { return new JSONArray(prefs.getString("subs", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    @Override public void onOpen(String id, String title, String author, String thumb, String avatar, boolean audio) {
        if (id == null || id.isEmpty()) {
            Toast.makeText(this, "Video unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        Ui.saveHistory(this, id, title, author, thumb);
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", title);
        in.putExtra("uploader", author);
        in.putExtra("thumbnail", thumb);
        in.putExtra("avatar", avatar);
        if (audio) {
            // "Play in background" from the card menu: audio mode + background play on for this video
            in.putExtra("start_audio", true);
            in.putExtra("auto_bg", true);
        }
        startActivity(in);
    }

    // ------------------------------------------------------------------ account (WebView login, no Play services)

    private void signIn() {
        startActivityForResult(new Intent(this, LoginActivity.class), RC_LOGIN);
    }

    private void signOut() {
        Auth.signOut(this);
        Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show();
        if (tab.equals("profile")) showProfile();
        else if (tab.equals("subs")) loadSubs();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOGIN && res == RESULT_OK) {
            String n = prefs.getString("acct_name", "");
            Toast.makeText(this, n.isEmpty() ? "Signed in" : "Welcome, " + n, Toast.LENGTH_SHORT).show();
            if (tab.equals("profile")) showProfile();
            else if (tab.equals("subs")) loadSubs();
        } else if (req == RC_VOICE && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> heard = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (heard != null && !heard.isEmpty()) {
                String q = heard.get(0);
                searchBox.setText(q);
                chip = "";
                updateChips();
                startSearch(q);
            }
        }
    }

    /** Keeps the subscription list / profile fresh (at most every 6 hours). */
    private void refreshAccountInBackground() {
        if (!Auth.signedIn(this)) return;
        if (System.currentTimeMillis() - prefs.getLong("subs_time", 0) < 6L * 3600 * 1000) return;
        pool.execute(() -> {
            Auth.refreshAccount(this);
            try { Auth.refreshSubscriptions(this); } catch (Exception ignored) { }
            runOnUiThread(() -> { if (tab.equals("profile")) showProfile(); });
        });
    }

    private void fetchSubscriptions(final boolean thenLoadFeed) {
        if (!Auth.signedIn(this)) return;
        pool.execute(() -> {
            try {
                Auth.refreshSubscriptions(this);
                runOnUiThread(() -> {
                    if (tab.equals("profile")) showProfile();
                    if (thenLoadFeed && tab.equals("subs")) loadSubs();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (tab.equals("subs")) {
                        showEmpty("Couldn't load subscriptions", String.valueOf(e.getMessage()),
                            "Try again", () -> loadSubs());
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------ profile screen

    private AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK
            : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    }

    private View avatar(int size) {
        String name = prefs.getString("acct_name", "");
        String photo = prefs.getString("acct_photo", "");
        boolean in = Auth.signedIn(this);
        FrameLayout ring = new FrameLayout(this);
        ring.setBackground(Ui.gradientOval());
        if (in && !photo.isEmpty()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(size - 4), Ui.dp(size - 4));
            p.gravity = Gravity.CENTER;
            ring.addView(iv, p);
            Glide.with(getApplicationContext()).load(photo).override(Ui.dp(size), Ui.dp(size)).circleCrop().into(iv);
        } else if (in && !name.isEmpty()) {
            TextView tv = Ui.text(this, name.substring(0, 1).toUpperCase(), size / 2.4f, true, Ui.onAccent);
            tv.setGravity(Gravity.CENTER);
            ring.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            ImageView iv = Ui.icon(this, R.drawable.ic_profile, Ui.onAccent, size / 2f);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(size / 2f), Ui.dp(size / 2f));
            p.gravity = Gravity.CENTER;
            ring.addView(iv, p);
        }
        return ring;
    }

    @Override protected void onResume() {
        super.onResume();
        updateMini();
    }

    @Override protected void onPause() {
        detachMini();
        super.onPause();
    }

    @Override protected void onStop() {
        // app went to the background: pause the mini player unless this video is allowed to play in background
        if (PlaybackService.miniActive && !bgOn(PlaybackService.curId) && PlaybackService.exo != null)
            PlaybackService.exo.pause();
        super.onStop();
    }

    private void showProfile() {
        tab = "profile";
        gen++;
        searchQuery = null;
        swipe.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
        status.setVisibility(View.GONE);
        profileScroll.setVisibility(View.VISIBLE);
        profileScroll.removeAllViews();
        profileScroll.addView(buildProfile());
        updateNav();
    }

    private LinearLayout group() {
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(Ui.outline(Ui.surface, Ui.line, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = Ui.dp(18);
        g.setLayoutParams(p);
        return g;
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s.toUpperCase(), 11.5f, true, Ui.fg);
        t.setLetterSpacing(0.1f);
        t.setPadding(Ui.dp(6), Ui.dp(4), 0, Ui.dp(8));
        return t;
    }

    private void addRow(LinearLayout g, String title, String sub, View trailing, View.OnClickListener click) {
        if (g.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(Ui.line);
            g.addView(d, new LinearLayout.LayoutParams(-1, 1));
        }
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.addView(Ui.text(this, title, 15, true, Ui.fg));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 12, false, Ui.muted);
            s.setPadding(0, Ui.dp(2), 0, 0);
            c.addView(s);
        }
        r.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        if (trailing != null) {
            ViewGroup.LayoutParams tl = trailing.getLayoutParams();
            r.addView(trailing, tl != null ? tl : new LinearLayout.LayoutParams(-2, -2));
        }
        if (click != null) r.setOnClickListener(click);
        g.addView(r, new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView valueText(String s) {
        return Ui.text(this, s, 13, true, Ui.fg);
    }

    private View toggle(boolean initial, final BoolCb cb) {
        final FrameLayout track = new FrameLayout(this);
        final View knob = new View(this);
        knob.setBackground(Ui.oval(0xFFFFFFFF));
        final FrameLayout.LayoutParams kp = new FrameLayout.LayoutParams(Ui.dp(20), Ui.dp(20));
        kp.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
        track.addView(knob, kp);
        final boolean[] on = {initial};
        final Runnable[] apply = new Runnable[1];
        apply[0] = () -> {
            track.setBackground(on[0] ? Ui.gradient(14) : Ui.rect(Ui.surface2, 14));
            kp.gravity = Gravity.CENTER_VERTICAL | (on[0] ? Gravity.END : Gravity.START);
            knob.setLayoutParams(kp);
        };
        apply[0].run();
        track.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(26)));
        track.setOnClickListener(v -> { on[0] = !on[0]; apply[0].run(); cb.on(on[0]); });
        return track;
    }

    private View buildProfile() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(28));

        // account card
        boolean signed = Auth.signedIn(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(20), Ui.dp(26), Ui.dp(20), Ui.dp(22));
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.surface, Ui.surface});
        gd.setCornerRadius(Ui.dp(24));
        gd.setStroke(Ui.dp(1), Ui.line);
        card.setBackground(gd);
        card.addView(avatar(88), new LinearLayout.LayoutParams(Ui.dp(88), Ui.dp(88)));
        String an = prefs.getString("acct_name", "");
        String name = signed ? (an.isEmpty() ? "Signed in" : an) : "Guest";
        TextView nm = Ui.text(this, name, 20, true, Ui.fg);
        nm.setPadding(0, Ui.dp(12), 0, 0);
        card.addView(nm);
        String handle = prefs.getString("acct_handle", "");
        String sub = signed ? (handle.isEmpty() ? "Your YouTube account" : handle)
            : "Sign in to sync your YouTube subscriptions";
        TextView em = Ui.text(this, sub, 13, false, Ui.muted);
        em.setGravity(Gravity.CENTER);
        em.setPadding(0, Ui.dp(2), 0, 0);
        card.addView(em);
        if (signed) {
            int n = readSubs().length();
            if (n > 0) {
                TextView f = Ui.text(this, "Following " + n + " channels", 12, true, Ui.accentText());
                f.setPadding(0, Ui.dp(8), 0, 0);
                card.addView(f);
            }
        }
        TextView btn = Ui.text(this, signed ? "Sign out" : "Sign in with Google", 14, true,
            signed ? Ui.fg : Ui.onAccent);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
        btn.setBackground(signed ? Ui.outline(Ui.surface, Ui.line, 24) : Ui.gradient(24));
        btn.setOnClickListener(v -> { if (!Auth.signedIn(this)) signIn(); else signOut(); });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = Ui.dp(16);
        card.addView(btn, bp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = Ui.dp(20);
        col.addView(card, cp);

        // customize
        col.addView(sectionTitle("Customize"));
        LinearLayout cg = group();
        final String[][] themes = {{"midnight", "Dark"}, {"amoled", "AMOLED black"}, {"light", "Light"},
            {"system", "Follow system"}};
        String curTheme = prefs.getString("theme2", "midnight");
        String themeName = themes[0][1];
        int themeIdx = 0;
        for (int i = 0; i < themes.length; i++) if (themes[i][0].equals(curTheme)) { themeName = themes[i][1]; themeIdx = i; }
        final int themeChecked = themeIdx;
        addRow(cg, "Theme", "Choose how the app looks", valueText(themeName), v -> {
            String[] names = new String[themes.length];
            for (int i = 0; i < themes.length; i++) names[i] = themes[i][1];
            dlg().setTitle("Theme").setSingleChoiceItems(names, themeChecked, (d, w) -> {
                prefs.edit().putString("theme2", themes[w][0]).putString("restore_tab", "profile").apply();
                d.dismiss();
                recreate();
            }).show();
        });
        String regionName = region();
        int regionIdx = 0;
        for (int i = 0; i < REGIONS.length; i++) if (REGIONS[i][0].equals(regionName)) { regionName = REGIONS[i][1]; regionIdx = i; }
        final int regionChecked = regionIdx;
        addRow(cg, "Home region", "Used for the Trending feed", valueText(regionName), v -> {
            String[] names = new String[REGIONS.length];
            for (int i = 0; i < REGIONS.length; i++) names[i] = REGIONS[i][1];
            dlg().setTitle("Home region").setSingleChoiceItems(names, regionChecked, (d, w) -> {
                prefs.edit().putString("region", REGIONS[w][0]).apply();
                Yt.init(REGIONS[w][0]);
                d.dismiss();
                showProfile();
            }).show();
        });
        col.addView(cg);

        // settings (Background play now lives under each video in the player)
        col.addView(sectionTitle("Settings"));
        LinearLayout sg = group();
        addRow(sg, "Autoplay next", "Play the first suggested video when one ends",
            toggle(prefs.getBoolean("autoplay", true), v -> prefs.edit().putBoolean("autoplay", v).apply()), null);
        String q = prefs.getString("quality", "auto");
        String qName = QUALITIES[0][1];
        int qIdx = 0;
        for (int i = 0; i < QUALITIES.length; i++) if (QUALITIES[i][0].equals(q)) { qName = QUALITIES[i][1]; qIdx = i; }
        final int qChecked = qIdx;
        addRow(sg, "Video quality", "Preferred playback quality", valueText(qName), v -> {
            String[] names = new String[QUALITIES.length];
            for (int i = 0; i < QUALITIES.length; i++) names[i] = QUALITIES[i][1];
            dlg().setTitle("Video quality").setSingleChoiceItems(names, qChecked, (d, w) -> {
                prefs.edit().putString("quality", QUALITIES[w][0]).apply();
                d.dismiss();
                showProfile();
            }).show();
        });
        addRow(sg, "Ad block", "No video ads · also skips sponsor & self-promo segments inside videos",
            toggle(prefs.getBoolean("adblock", true), v -> prefs.edit().putBoolean("adblock", v).apply()), null);
        addRow(sg, "Clear watch history", "Removes the list stored on this device", null, v ->
            dlg().setTitle("Clear watch history?").setMessage("This only removes history saved on this device.")
                .setNegativeButton("Cancel", null).setPositiveButton("Clear", (d, w) -> {
                    prefs.edit().remove("watch_history").apply();
                    Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
                }).show());
        addRow(sg, "Clear cache", "Forget the saved home feed", null, v -> {
            prefs.edit().remove("home_cache").apply();
            Glide.get(this).clearMemory();
            Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show();
        });
        col.addView(sg);

        // about
        col.addView(sectionTitle("About"));
        LinearLayout ag = group();
        addRow(ag, "YouTubee", "Version 4.6 · native Android", null, null);
        addRow(ag, "How it works", "Videos are read directly on your phone (no middle servers), so they play"
            + " without YouTube's ads. Sign-in uses Google's own login page.", null, null);
        col.addView(ag);
        return col;
    }
}
