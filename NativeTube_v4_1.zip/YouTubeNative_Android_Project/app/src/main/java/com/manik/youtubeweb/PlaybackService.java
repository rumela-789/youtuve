package com.manik.youtubeweb;

import android.content.Intent;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class PlaybackService extends MediaSessionService {
    /** The player lives in this service (so audio keeps playing in background); the UI uses it directly. */
    static volatile ExoPlayer exo;

    // ---- state of the video that is (or was last) playing; shared with the mini player in MainActivity ----
    /** True when the user backed out of the player and the video should keep running in the mini player. */
    static volatile boolean miniActive = false;
    static volatile String curId = "", curTitle = "", curUploader = "", curThumb = "";
    static volatile boolean curAudio = false;

    private ExoPlayer player;
    private MediaSession mediaSession;

    @Override public void onCreate() {
        super.onCreate();
        // Fast start: begin playback after only 0.8s is buffered (was 1.5s), rebuffer after 1.5s (was 3s).
        DefaultLoadControl load = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 800, 1_500)
            .setPrioritizeTimeOverSizeThresholds(true).build();
        player = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(Net.dataSourceFactory(this)))
            .setLoadControl(load)
            .setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build();
        exo = player;
        mediaSession = new MediaSession.Builder(this, player).build();
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }
    @Override public void onTaskRemoved(Intent rootIntent) {
        if (player != null && !player.getPlayWhenReady()) { miniActive = false; stopSelf(); }
    }
    @Override public void onDestroy() {
        exo = null;
        if (mediaSession != null) { mediaSession.release(); mediaSession = null; }
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
