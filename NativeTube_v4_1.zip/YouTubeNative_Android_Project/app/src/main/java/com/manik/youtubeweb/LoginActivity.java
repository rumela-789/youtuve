package com.manik.youtubeweb;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Sign in with a Google account on Google's own login page (no Play services, no microG, no OAuth setup).
 * As soon as YouTube session cookies appear the screen closes and the profile/subscriptions are loaded.
 */
public class LoginActivity extends Activity {
    private static final String LOGIN_URL = "https://accounts.google.com/ServiceLogin?service=youtube&uilel=3"
        + "&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue"
        + "%26app%3Ddesktop%26next%3Dhttps%253A%252F%252Fwww.youtube.com%252F";

    private WebView web;
    private ProgressBar bar;
    private TextView doneBtn, info;
    private boolean finishing = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(14), Ui.dp(6));
        ImageView back = Ui.icon(this, R.drawable.ic_back, Ui.fg, 24);
        back.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        back.setContentDescription("Back");
        back.setOnClickListener(v -> { setResult(RESULT_CANCELED); finish(); });
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        TextView title = Ui.text(this, "Sign in to YouTube", 17, true, Ui.fg);
        title.setPadding(Ui.dp(6), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        doneBtn = Ui.text(this, "Done", 13, true, Ui.onAccent);
        doneBtn.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
        doneBtn.setBackground(Ui.gradient(18));
        doneBtn.setOnClickListener(v -> manualCheck());
        top.addView(doneBtn);
        root.addView(top);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(3)));

        info = Ui.text(this, "", 12, false, Ui.muted);
        info.setPadding(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(4));
        info.setVisibility(View.GONE);
        root.addView(info);

        FrameLayout holder = new FrameLayout(this);
        web = new WebView(this);
        holder.addView(web, new FrameLayout.LayoutParams(-1, -1));
        root.addView(holder, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);
        cm.removeAllCookies(null); // start clean so Google shows the account chooser
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        // Google refuses sign-in inside an obvious "WebView"; present a normal Chrome mobile browser.
        s.setUserAgentString(Net.UA_WEB);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, Bitmap icon) { bar.setProgress(10); }
            @Override public void onPageFinished(WebView v, String url) {
                bar.setProgress(100);
                check(url);
            }
        });
        web.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { bar.setProgress(p); }
        });
        web.loadUrl(LOGIN_URL);
    }

    private String sessionCookie() {
        CookieManager cm = CookieManager.getInstance();
        String c = cm.getCookie("https://www.youtube.com");
        return c == null ? "" : c;
    }

    private void check(String url) {
        if (finishing || url == null) return;
        if (!url.contains("youtube.com")) return;
        String c = sessionCookie();
        if (Auth.hasSession(c)) complete(c);
    }

    private void manualCheck() {
        String c = sessionCookie();
        if (Auth.hasSession(c)) { complete(c); return; }
        Toast.makeText(this, "Not signed in yet — finishing…", Toast.LENGTH_SHORT).show();
        web.loadUrl("https://www.youtube.com/");
    }

    private void complete(final String cookie) {
        if (finishing) return;
        finishing = true;
        CookieManager.getInstance().flush();
        Auth.saveCookie(this, cookie);
        web.setVisibility(View.INVISIBLE);
        doneBtn.setVisibility(View.GONE);
        info.setText("Signed in. Loading your account…");
        info.setVisibility(View.VISIBLE);
        new Thread(() -> {
            Auth.refreshAccount(this);
            try { Auth.refreshSubscriptions(this); } catch (Exception ignored) { }
            runOnUiThread(() -> { setResult(RESULT_OK); finish(); });
        }).start();
    }

    @Override public void onBackPressed() {
        if (!finishing && web.canGoBack()) { web.goBack(); return; }
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.stopLoading(); web.destroy(); }
        super.onDestroy();
    }
}
