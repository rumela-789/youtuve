package com.manik.youtubeweb;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;
import org.json.JSONArray;
import org.json.JSONObject;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * Google login without Google Play services / OAuth client: the user signs in on the real Google page inside a
 * WebView, we keep the resulting YouTube session cookies and talk to YouTube's own web API with them
 * (this is how YouTube's website itself works). Used for subscriptions, like/dislike and subscribe.
 */
final class Auth {
    private static final String ORIGIN = "https://www.youtube.com";
    private static final String KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private Auth() {}

    static String cookie(Context c) { return Ui.prefs(c).getString("yt_cookie", ""); }

    private static String cookieValue(String cookie, String name) {
        for (String part : cookie.split(";")) {
            String p = part.trim();
            if (p.startsWith(name + "=")) return p.substring(name.length() + 1);
        }
        return "";
    }

    static boolean hasSession(String cookie) {
        return cookie != null && (!cookieValue(cookie, "SAPISID").isEmpty()
            || !cookieValue(cookie, "__Secure-3PAPISID").isEmpty());
    }

    static boolean signedIn(Context c) { return hasSession(cookie(c)); }

    static void saveCookie(Context c, String cookie) {
        Ui.prefs(c).edit().putString("yt_cookie", cookie).apply();
        Net.setCookie(cookie);
    }

    static void signOut(Context c) {
        Ui.prefs(c).edit().remove("yt_cookie").remove("acct_name").remove("acct_photo").remove("acct_handle")
            .remove("subs").remove("likes").apply();
        Net.setCookie("");
        try { CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); }
        catch (Throwable ignored) { }
    }

    private static String sha1(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    static String authHeader(String cookie) throws Exception {
        long ts = System.currentTimeMillis() / 1000;
        String sid = cookieValue(cookie, "SAPISID");
        String p1 = cookieValue(cookie, "__Secure-1PAPISID");
        String p3 = cookieValue(cookie, "__Secure-3PAPISID");
        if (sid.isEmpty()) sid = p3;
        StringBuilder h = new StringBuilder("SAPISIDHASH ").append(ts).append('_')
            .append(sha1(ts + " " + sid + " " + ORIGIN));
        if (!p1.isEmpty()) h.append(" SAPISID1PHASH ").append(ts).append('_').append(sha1(ts + " " + p1 + " " + ORIGIN));
        if (!p3.isEmpty()) h.append(" SAPISID3PHASH ").append(ts).append('_').append(sha1(ts + " " + p3 + " " + ORIGIN));
        return h.toString();
    }

    private static String webVersion() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return "2." + f.format(new Date(System.currentTimeMillis() - 6L * 24 * 3600 * 1000)) + ".00.00";
    }

    /** POST to a YouTube InnerTube endpoint as the signed-in user. */
    static JSONObject post(Context c, String endpoint, JSONObject extra) throws Exception {
        return postInternal(c, endpoint, extra, true);
    }

    private static JSONObject postInternal(Context c, String endpoint, JSONObject extra, boolean requireSession)
            throws Exception {
        String cookie = cookie(c);
        boolean session = hasSession(cookie);
        if (requireSession && !session) throw new Exception("Not signed in");
        JSONObject client = new JSONObject().put("clientName", "WEB").put("clientVersion", webVersion())
            .put("hl", "en").put("gl", Ui.prefs(c).getString("region", "US"));
        JSONObject body = extra == null ? new JSONObject() : extra;
        body.put("context", new JSONObject().put("client", client));
        Request.Builder rb = new Request.Builder()
            .url(ORIGIN + "/youtubei/v1/" + endpoint + "?prettyPrint=false&key=" + KEY)
            .header("User-Agent", Net.UA_WEB)
            .header("Origin", ORIGIN).header("X-Origin", ORIGIN).header("Referer", ORIGIN + "/")
            .header("X-Youtube-Client-Name", "1").header("X-Youtube-Client-Version", webVersion())
            .post(RequestBody.create(body.toString(), JSON));
        if (session) {
            rb.header("Cookie", cookie).header("Authorization", authHeader(cookie)).header("X-Goog-AuthUser", "0");
        }
        try (Response r = Net.HTTP.newCall(rb.build()).execute()) {
            String text = r.body() == null ? "" : r.body().string();
            if (r.code() == 401 || r.code() == 403) throw new Exception("Session expired. Please sign in again.");
            if (!r.isSuccessful()) throw new Exception("YouTube error " + r.code());
            return text.isEmpty() ? new JSONObject() : new JSONObject(text);
        }
    }

    /** Video page data (channel, subscribers, likes, suggestions) via YouTube's own "next" call; works signed-out too. */
    static JSONObject nextInfo(Context c, String videoId) throws Exception {
        return postInternal(c, "next", new JSONObject().put("videoId", videoId), false);
    }

    // ------------------------------------------------------------------ actions

    /** action: like | dislike | removelike */
    static void rate(Context c, String videoId, String action) throws Exception {
        post(c, "like/" + action, new JSONObject().put("target", new JSONObject().put("videoId", videoId)));
    }

    /**
     * Posts a comment on a video as the signed-in user (YouTube's own comment/create endpoint).
     * The createCommentParams protobuf matches YouTube.js: { 2: videoId, 5: {}, 10: 7 }.
     */
    static void postComment(Context c, String videoId, String text) throws Exception {
        JSONObject b = new JSONObject();
        b.put("commentText", text);
        b.put("createCommentParams", createCommentParams(videoId));
        try {
            JSONObject res = post(c, "comment/create_comment", b);
            checkCommentResult(res);
        } catch (Exception first) {
            // older YouTube endpoint name — try it before giving up
            JSONObject res = post(c, "comment/create", b);
            checkCommentResult(res);
        }
    }

    private static void checkCommentResult(JSONObject res) throws Exception {
        if (res != null && res.has("error")) {
            JSONObject e = res.optJSONObject("error");
            throw new Exception(e == null ? "YouTube rejected the comment" : e.optString("message", "YouTube rejected the comment"));
        }
    }

    /** base64(protobuf{videoId@2, empty message@5, varint 7@10}), URL-encoded like the website does. */
    private static String createCommentParams(String videoId) throws Exception {
        java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
        byte[] vid = videoId.getBytes("UTF-8");
        b.write(0x12);                       // field 2, length-delimited: video id
        b.write(vid.length);
        b.write(vid, 0, vid.length);
        b.write(0x2A); b.write(0x00);        // field 5, empty message
        b.write(0x50); b.write(0x07);        // field 10, varint 7
        String b64 = android.util.Base64.encodeToString(b.toByteArray(), android.util.Base64.NO_WRAP);
        return java.net.URLEncoder.encode(b64, "UTF-8");
    }

    static void subscribe(Context c, String channelId, boolean on) throws Exception {
        JSONObject b = new JSONObject().put("channelIds", new JSONArray().put(channelId))
            .put("params", on ? "EgIIAhgA" : "CgIIAhgA");
        post(c, on ? "subscription/subscribe" : "subscription/unsubscribe", b);
        // keep the local list in sync so the button state is right immediately
        try {
            SharedPreferences p = Ui.prefs(c);
            JSONArray old = new JSONArray(p.getString("subs", "[]"));
            JSONArray next = new JSONArray();
            boolean found = false;
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.optJSONObject(i);
                if (o == null) continue;
                if (channelId.equals(o.optString("id"))) { found = true; if (!on) continue; }
                next.put(o);
            }
            if (on && !found) next.put(new JSONObject().put("id", channelId).put("title", ""));
            p.edit().putString("subs", next.toString()).apply();
        } catch (Exception ignored) { }
    }

    static boolean isSubscribed(Context c, String channelId) {
        if (channelId == null || channelId.isEmpty()) return false;
        try {
            JSONArray a = new JSONArray(Ui.prefs(c).getString("subs", "[]"));
            for (int i = 0; i < a.length(); i++)
                if (channelId.equals(a.getJSONObject(i).optString("id"))) return true;
        } catch (Exception ignored) { }
        return false;
    }

    static int ratingOf(Context c, String videoId) {
        try { return new JSONObject(Ui.prefs(c).getString("likes", "{}")).optInt(videoId, 0); }
        catch (Exception e) { return 0; }
    }

    static void saveRating(Context c, String videoId, int v) {
        try {
            SharedPreferences p = Ui.prefs(c);
            JSONObject o = new JSONObject(p.getString("likes", "{}"));
            if (v == 0) o.remove(videoId); else o.put(videoId, v);
            if (o.length() > 400) o = new JSONObject();
            p.edit().putString("likes", o.toString()).apply();
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ account data

    /** Collects every subscribed channel (id → title) from the signed-in "Channels" page. */
    static void refreshSubscriptions(Context c) throws Exception {
        Map<String, String> found = new LinkedHashMap<>();
        JSONObject res = post(c, "browse", new JSONObject().put("browseId", "FEchannels"));
        for (int page = 0; page < 6; page++) {
            collectChannels(res, found, true);
            String tok = findContinuation(res);
            if (tok == null) break;
            res = post(c, "browse", new JSONObject().put("continuation", tok));
        }
        if (found.isEmpty()) {
            collectChannels(post(c, "browse", new JSONObject().put("browseId", "FEchannels")), found, false);
        }
        JSONArray out = new JSONArray();
        for (Map.Entry<String, String> e : found.entrySet())
            out.put(new JSONObject().put("id", e.getKey()).put("title", e.getValue()));
        Ui.prefs(c).edit().putString("subs", out.toString()).putLong("subs_time", System.currentTimeMillis()).apply();
    }

    private static boolean isChannelId(String s) { return s != null && s.matches("UC[A-Za-z0-9_-]{22}"); }

    private static void collectChannels(Object node, Map<String, String> out, boolean renderersOnly) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            java.util.Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                Object v = o.opt(k);
                boolean isRenderer = k.equals("channelRenderer") || k.equals("gridChannelRenderer");
                if (isRenderer && v instanceof JSONObject) {
                    JSONObject r = (JSONObject) v;
                    String id = r.optString("channelId", "");
                    if (isChannelId(id)) out.put(id, textOf(r.opt("title")));
                } else if (!renderersOnly && k.equals("browseId") && v instanceof String && isChannelId((String) v)) {
                    if (!out.containsKey(v)) out.put((String) v, "");
                }
                collectChannels(v, out, renderersOnly);
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) collectChannels(a.opt(i), out, renderersOnly);
        }
    }

    static String textOf(Object t) {
        if (t instanceof JSONObject) {
            JSONObject o = (JSONObject) t;
            if (o.has("simpleText")) return o.optString("simpleText", "");
            JSONArray runs = o.optJSONArray("runs");
            if (runs != null && runs.length() > 0) return runs.optJSONObject(0).optString("text", "");
        }
        return "";
    }

    private static String findContinuation(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject c = o.optJSONObject("continuationItemRenderer");
            if (c != null) {
                String t = deepToken(c);
                if (t != null) return t;
            }
            java.util.Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = findContinuation(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = findContinuation(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private static String deepToken(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if (o.has("token") && o.opt("token") instanceof String) return o.optString("token");
            java.util.Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = deepToken(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = deepToken(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    /** Best-effort: stores the account name / photo for the profile screen. */
    static void refreshAccount(Context c) {
        try {
            JSONObject res = post(c, "account/accounts_list", new JSONObject());
            String[] hit = new String[3];
            findAccount(res, hit);
            SharedPreferences.Editor e = Ui.prefs(c).edit();
            if (hit[0] != null && !hit[0].isEmpty()) e.putString("acct_name", hit[0]);
            if (hit[1] != null && !hit[1].isEmpty()) e.putString("acct_photo", hit[1]);
            if (hit[2] != null && !hit[2].isEmpty()) e.putString("acct_handle", hit[2]);
            e.apply();
        } catch (Exception ignored) { }
    }

    private static void findAccount(Object node, String[] hit) {
        if (hit[0] != null && hit[1] != null) return;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if (hit[0] == null && o.has("accountName")) hit[0] = textOf(o.opt("accountName"));
            if (hit[2] == null && o.has("channelHandle")) hit[2] = textOf(o.opt("channelHandle"));
            if (hit[1] == null && o.has("accountPhoto")) {
                JSONObject p = o.optJSONObject("accountPhoto");
                JSONArray th = p == null ? null : p.optJSONArray("thumbnails");
                if (th != null && th.length() > 0) hit[1] = th.optJSONObject(0).optString("url", "");
            }
            java.util.Iterator<String> keys = o.keys();
            while (keys.hasNext()) findAccount(o.opt(keys.next()), hit);
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) findAccount(a.opt(i), hit);
        }
    }
}
