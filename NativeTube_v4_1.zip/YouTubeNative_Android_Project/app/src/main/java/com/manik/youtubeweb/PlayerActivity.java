package com.manik.youtubeweb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;
import java.util.Map;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MergingMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Video / audio player: on-device stream extraction, like/dislike, comments, subscribe, mini player, ad-block. */
public class PlayerActivity extends Activity implements VideoCardView.Listener {
    private static final int RC_LOGIN = 31;
    private static final int T_MERGED = 0, T_PROG = 1, T_HLS = 2, T_AUDIO = 3;

    private static final class Cand {
        final int type; final String v, a; final boolean post;
        Cand(int type, String v, String a) { this(type, v, a, false); }
        Cand(int type, String v, String a, boolean post) { this.type = type; this.v = v; this.a = a; this.post = post; }
    }

    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private MediaController controller;          // only used to start/bind the playback service
    private ListenableFuture<MediaController> controllerFuture;
    private ExoPlayer exo;
    private Player.Listener playerListener;
    private boolean pendingStart = false;

    private LinearLayout root, relatedBox;
    private FrameLayout playerBox;
    private PlayerView playerView;
    private ProgressBar spinner;
    private TextView overlayMsg, titleV, metaV, channelV, subsV, descV, qualityChip, subBtn;
    private LinearLayout likeChip, dislikeChip, audioChip;
    private ImageView avatarV;
    private ScrollView scroll;

    // per-video background play switch (lives right under the video)
    private final Runnable[] bgApply = new Runnable[1];

    // comments section
    private LinearLayout commentsList;
    private TextView commentsHeader, addComment;
    private View commentsMoreBtn;
    private Yt.Comments commentsData;
    private int commentsGen = 0;

    // compatibility player: YouTube's own web player inside a WebView (used when direct extraction is blocked)
    private WebView webPlayer;
    private boolean webMode = false, webAlt = false;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private static final String BG_JS = "(function(){if(window.__bgk)return;window.__bgk=1;"
        + "try{Object.defineProperty(document,'hidden',{get:function(){return false;}});"
        + "Object.defineProperty(document,'visibilityState',{get:function(){return 'visible';}});}catch(e){}"
        + "['visibilitychange','webkitvisibilitychange','pagehide','blur'].forEach(function(t){"
        + "window.addEventListener(t,function(e){e.stopImmediatePropagation();},true);"
        + "document.addEventListener(t,function(e){e.stopImmediatePropagation();},true);});})();";
    private static final String AD_JS = "(function(){if(window.__abk)return;window.__abk=1;setInterval(function(){"
        + "var p=document.querySelector('.html5-video-player');var v=document.querySelector('video');"
        + "if(p&&p.classList.contains('ad-showing')&&v&&isFinite(v.duration)&&v.duration>0){v.muted=true;v.currentTime=v.duration;}"
        + "var b=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern');if(b)b.click();"
        + "var o=document.querySelector('.ytp-ad-overlay-close-button');if(o)o.click();"
        + "},400);})();";

    private String videoId, title, uploader, thumb;
    private Yt.Info info;
    private int loadGen = 0, portraitH;
    private boolean audioMode, full = false, descExpanded = false;
    private String forcedQuality = null;
    private final List<Cand> cands = new ArrayList<>();
    private int candIdx = 0;
    private boolean reExtracted = false, startedOk = false;
    private long resumeMs = 0;

    // like / subscribe state
    private int rating = 0, rating0 = 0;
    private long likesBase = -1, dislikesBase = -1;
    private boolean subscribed = false;
    private String curChannelId = "", likesText = "";

    // ad-block (SponsorBlock)
    private List<double[]> segments = new ArrayList<>();
    private long lastSkipToast = 0;

    private final Runnable watchdog = () -> {
        if (exo != null && !startedOk) advance("timeout");
    };
    private final Runnable skipper = new Runnable() {
        @Override public void run() {
            if (exo != null && exo.isPlaying() && !segments.isEmpty() && prefs.getBoolean("adblock", true)) {
                double pos = exo.getCurrentPosition() / 1000.0;
                for (double[] s : segments) {
                    if (pos >= s[0] && pos < s[1] - 0.6) {
                        exo.seekTo((long) (s[1] * 1000));
                        long now = System.currentTimeMillis();
                        if (now - lastSkipToast > 4000) {
                            lastSkipToast = now;
                            Toast.makeText(PlayerActivity.this, "Ad / sponsor segment skipped", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    }
                }
            }
            handler.postDelayed(this, 500);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Ui.prefs(this);
        Ui.load(this);
        PoTokens.install(this);
        Yt.init(prefs.getString("region", "US"));
        Net.setCookie(Auth.cookie(this));
        videoId = getIntent().getStringExtra("video_id");
        title = getIntent().getStringExtra("title");
        uploader = getIntent().getStringExtra("uploader");
        thumb = getIntent().getStringExtra("thumbnail");
        String av0 = getIntent().getStringExtra("avatar");
        audioMode = getIntent().getBooleanExtra("start_audio", false);
        // "Play in background" from the video menu: switch background play on for this one video
        if (getIntent().getBooleanExtra("auto_bg", false) && videoId != null)
            prefs.edit().putBoolean("bg_" + videoId, true).apply();
        rating = rating0 = Auth.ratingOf(this, videoId);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        build();
        if (av0 != null && !av0.isEmpty()) Glide.with(avatarV).load(av0).override(96, 96).circleCrop().into(avatarV);
        connectController();
        // returning from the mini player: playback is already running — don't restart, just refresh the info
        boolean resumed = getIntent().getBooleanExtra("from_mini", false)
            && PlaybackService.miniActive && PlaybackService.exo != null
            && videoId != null && videoId.equals(PlaybackService.curId);
        if (resumed) {
            PlaybackService.miniActive = false;
            title = PlaybackService.curTitle;
            uploader = PlaybackService.curUploader;
            thumb = PlaybackService.curThumb;
            audioMode = PlaybackService.curAudio;
            spinner.setVisibility(View.GONE);
            titleV.setText(title == null ? "" : title);
            channelV.setText(uploader == null ? "" : uploader);
            updateChips();
            updateRateUi();
            updateSubUi();
            updateBgRow();
            loadMetaOnly();
        } else {
            loadStreams();
        }
        handler.postDelayed(skipper, 500);
    }

    // ------------------------------------------------------------------ layout

    private TextView chip(String label, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 12.5f, true, Ui.fg);
        t.setPadding(Ui.dp(16), Ui.dp(9), Ui.dp(16), Ui.dp(9));
        t.setBackground(Ui.rect(Ui.surface, 20));
        t.setOnClickListener(l);
        return t;
    }

    /** Pill with a small icon and a label (used for like / dislike / audio). */
    private LinearLayout iconChip(int iconRes, String label, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(Ui.dp(14), Ui.dp(9), Ui.dp(16), Ui.dp(9));
        box.setBackground(Ui.rect(Ui.surface, 20));
        ImageView ic = Ui.icon(this, iconRes, Ui.fg, 18);
        box.addView(ic, new LinearLayout.LayoutParams(Ui.dp(18), Ui.dp(18)));
        TextView t = Ui.text(this, label, 12.5f, true, Ui.fg);
        t.setPadding(Ui.dp(8), 0, 0, 0);
        box.addView(t);
        box.setOnClickListener(l);
        return box;
    }

    private void styleChip(LinearLayout box, boolean on, String label) {
        // YouTube's selected pill: white background with black text (dark mode), black with white (light)
        box.setBackground(Ui.rect(on ? Ui.pillOn() : Ui.surface, 20));
        int fg = on ? Ui.pillOnFg() : Ui.fg;
        ((ImageView) box.getChildAt(0)).setColorFilter(fg, PorterDuff.Mode.SRC_IN);
        TextView t = (TextView) box.getChildAt(1);
        t.setTextColor(fg);
        t.setText(label);
        t.setVisibility(label.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void build() {
        portraitH = Math.min(getResources().getDisplayMetrics().widthPixels,
            getResources().getDisplayMetrics().heightPixels) * 9 / 16;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (full) v.setPadding(0, 0, 0, 0);
            else v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        playerBox = new FrameLayout(this);
        playerBox.setBackgroundColor(0xFF000000);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setFullscreenButtonClickListener(isFs -> setFull(!full));
        playerBox.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        spinner = new ProgressBar(this);
        spinner.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
        playerBox.addView(spinner, new FrameLayout.LayoutParams(Ui.dp(40), Ui.dp(40), Gravity.CENTER));
        overlayMsg = Ui.text(this, "", 13, false, 0xFFFFFFFF);
        overlayMsg.setGravity(Gravity.CENTER);
        overlayMsg.setPadding(Ui.dp(24), 0, Ui.dp(24), 0);
        overlayMsg.setVisibility(View.GONE);
        playerBox.addView(overlayMsg, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        root.addView(playerBox, new LinearLayout.LayoutParams(-1, portraitH));

        scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, Ui.dp(20));

        titleV = Ui.text(this, title == null ? "Video" : title, 18, true, Ui.fg);
        titleV.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(2));
        content.addView(titleV);
        metaV = Ui.text(this, "", 12, false, Ui.muted);
        metaV.setPadding(Ui.dp(16), Ui.dp(2), Ui.dp(16), Ui.dp(10));
        content.addView(metaV);

        // channel row: avatar, name + subscribers, Subscribe button
        LinearLayout ch = new LinearLayout(this);
        ch.setGravity(Gravity.CENTER_VERTICAL);
        ch.setPadding(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(12));
        avatarV = new ImageView(this);
        avatarV.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarV.setBackground(Ui.gradientOval());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(40), Ui.dp(40));
        ap.rightMargin = Ui.dp(12);
        ch.addView(avatarV, ap);
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        channelV = Ui.text(this, uploader == null ? "" : uploader, 15, true, Ui.fg);
        channelV.setMaxLines(1);
        channelV.setEllipsize(TextUtils.TruncateAt.END);
        names.addView(channelV);
        subsV = Ui.text(this, "", 11.5f, false, Ui.muted);
        subsV.setVisibility(View.GONE);
        names.addView(subsV);
        ch.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        subBtn = Ui.text(this, "Subscribe", 13, true, Ui.onAccent);
        subBtn.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
        subBtn.setOnClickListener(v -> toggleSubscribe());
        ch.addView(subBtn);
        content.addView(ch);
        updateSubUi();

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(Ui.dp(16), 0, Ui.dp(16), Ui.dp(12));
        likeChip = iconChip(R.drawable.ic_like, "Like", v -> rate(1));
        dislikeChip = iconChip(R.drawable.ic_dislike, "", v -> rate(-1));
        audioChip = iconChip(R.drawable.ic_music, "Audio only", v -> toggleAudio());
        qualityChip = chip("Quality: Auto", v -> pickQuality());
        TextView share = chip("Share", v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, (title == null ? "" : title) + "\nhttps://youtu.be/" + videoId);
            startActivity(Intent.createChooser(i, "Share"));
        });
        dislikeChip.setContentDescription("Dislike");
        TextView webChip = chip("Web player", v -> { webAlt = webMode && !webAlt; startWebFallback(); });
        View[] all = {likeChip, dislikeChip, audioChip, qualityChip, share, webChip};
        for (View c : all) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.rightMargin = Ui.dp(8);
            chips.addView(c, p);
        }
        hs.addView(chips);
        content.addView(hs);
        updateChips();
        updateRateUi();

        // per-video background play switch (under every video)
        LinearLayout bgRow = new LinearLayout(this);
        bgRow.setGravity(Gravity.CENTER_VERTICAL);
        bgRow.setPadding(Ui.dp(16), Ui.dp(2), Ui.dp(16), Ui.dp(10));
        ImageView mIcon = Ui.icon(this, R.drawable.ic_music, Ui.fg, 18);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(Ui.dp(18), Ui.dp(18));
        mp.rightMargin = Ui.dp(12);
        bgRow.addView(mIcon, mp);
        LinearLayout bc = new LinearLayout(this);
        bc.setOrientation(LinearLayout.VERTICAL);
        bc.addView(Ui.text(this, "Background play", 14, true, Ui.fg));
        TextView bs = Ui.text(this, "Keep this video playing when the screen is off or the app is minimized",
            11.5f, false, Ui.muted);
        bs.setPadding(0, Ui.dp(2), 0, 0);
        bc.addView(bs);
        bgRow.addView(bc, new LinearLayout.LayoutParams(0, -2, 1));
        bgRow.addView(buildBgSwitch());
        content.addView(bgRow);

        descV = Ui.text(this, "", 13, false, Ui.fg);
        descV.setMaxLines(3);
        descV.setEllipsize(TextUtils.TruncateAt.END);
        descV.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        descV.setBackground(Ui.rect(Ui.surface, 14));
        descV.setVisibility(View.GONE);
        descV.setOnClickListener(v -> {
            descExpanded = !descExpanded;
            descV.setMaxLines(descExpanded ? 200 : 3);
        });
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(Ui.dp(16), 0, Ui.dp(16), Ui.dp(10));
        content.addView(descV, dp);

        buildComments(content);

        TextView up = Ui.text(this, "Up next", 16, true, Ui.fg);
        up.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(2));
        content.addView(up);
        relatedBox = new LinearLayout(this);
        relatedBox.setOrientation(LinearLayout.VERTICAL);
        content.addView(relatedBox, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        applySystemUi(false);
    }

    // ------------------------------------------------------------------ background play (per video)

    /** Background play is a per-video switch now, so only the videos you choose keep playing. */
    private boolean bgOn(String id) { return id != null && prefs.getBoolean("bg_" + id, false); }

    private View buildBgSwitch() {
        final FrameLayout track = new FrameLayout(this);
        final View knob = new View(this);
        knob.setBackground(Ui.oval(0xFFFFFFFF));
        final FrameLayout.LayoutParams kp = new FrameLayout.LayoutParams(Ui.dp(20), Ui.dp(20));
        kp.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
        track.addView(knob, kp);
        Runnable apply = () -> {
            boolean on = bgOn(videoId);
            track.setBackground(on ? Ui.gradient(14) : Ui.rect(Ui.surface2, 14));
            kp.gravity = Gravity.CENTER_VERTICAL | (on ? Gravity.END : Gravity.START);
            knob.setLayoutParams(kp);
        };
        bgApply[0] = apply;
        apply.run();
        track.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(26)));
        track.setOnClickListener(v -> {
            boolean now = !bgOn(videoId);
            prefs.edit().putBoolean("bg_" + videoId, now).apply();
            apply.run();
            Toast.makeText(this, now
                ? "Background play on — this video keeps playing with the screen off"
                : "Background play off for this video", Toast.LENGTH_SHORT).show();
        });
        return track;
    }

    private void updateBgRow() { if (bgApply[0] != null) bgApply[0].run(); }

    // ------------------------------------------------------------------ comments

    private void buildComments(LinearLayout content) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        commentsHeader = Ui.text(this, "Comments", 16, true, Ui.fg);
        commentsHeader.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(2));
        box.addView(commentsHeader);

        addComment = Ui.text(this, "Add a comment...", 13.5f, false, Ui.muted);
        addComment.setPadding(Ui.dp(16), Ui.dp(12), Ui.dp(16), Ui.dp(12));
        addComment.setBackground(Ui.rect(Ui.surface, 20));
        addComment.setOnClickListener(v -> openCommentDialog());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(4));
        box.addView(addComment, ap);

        commentsList = new LinearLayout(this);
        commentsList.setOrientation(LinearLayout.VERTICAL);
        box.addView(commentsList, new LinearLayout.LayoutParams(-1, -2));

        commentsMoreBtn = Ui.text(this, "Show more comments", 13, true, Ui.fg);
        commentsMoreBtn.setPadding(Ui.dp(20), Ui.dp(11), Ui.dp(20), Ui.dp(11));
        commentsMoreBtn.setBackground(Ui.rect(Ui.surface, 20));
        commentsMoreBtn.setVisibility(View.GONE);
        commentsMoreBtn.setOnClickListener(v -> loadMoreComments());
        LinearLayout.LayoutParams mp2 = new LinearLayout.LayoutParams(-2, -2);
        mp2.setMargins(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(8));
        box.addView(commentsMoreBtn, mp2);

        content.addView(box, new LinearLayout.LayoutParams(-1, -2));
    }

    private void resetComments() {
        commentsGen++;
        commentsData = null;
        if (commentsList != null) commentsList.removeAllViews();
        if (commentsHeader != null) commentsHeader.setText("Comments");
        if (commentsMoreBtn != null) commentsMoreBtn.setVisibility(View.GONE);
    }

    private void loadComments() {
        if (videoId == null || commentsList == null) return;
        final String vid = videoId;
        resetComments();
        final int g = commentsGen;
        TextView loading = Ui.text(this, "Loading comments…", 13, false, Ui.muted);
        loading.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
        loading.setOnClickListener(v -> loadComments());
        commentsList.addView(loading);
        pool.execute(() -> {
            try {
                final Yt.Comments c = Yt.comments(vid);
                runOnUiThread(() -> { if (g == commentsGen && vid.equals(videoId)) applyComments(c, false); });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (g != commentsGen || !vid.equals(videoId)) return;
                    commentsList.removeAllViews();
                    TextView err = Ui.text(PlayerActivity.this, "Couldn't load comments · tap to retry",
                        13, false, Ui.muted);
                    err.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
                    err.setOnClickListener(v -> loadComments());
                    commentsList.addView(err);
                });
            }
        });
    }

    private void applyComments(Yt.Comments c, boolean append) {
        if (!append) {
            commentsData = c;
            commentsList.removeAllViews();
        } else {
            commentsData.items.addAll(c.items);
            commentsData.raw.addAll(c.raw);
            commentsData.next = c.next;
        }
        if (c.disabled) {
            addComment.setVisibility(View.GONE);
            TextView off = Ui.text(this, "Comments are turned off", 13, false, Ui.muted);
            off.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
            commentsList.addView(off);
            commentsMoreBtn.setVisibility(View.GONE);
            return;
        }
        addComment.setVisibility(View.VISIBLE);
        commentsHeader.setText((c.total > 0 ? Ui.count(c.total) + " " : "") + "Comments");
        for (int i = 0; i < c.items.size(); i++) {
            final int idx = append ? commentsData.items.size() - c.items.size() + i : i;
            commentsList.addView(commentView(c.items.get(i), idx, false));
        }
        commentsMoreBtn.setVisibility(c.next != null && !c.items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void loadMoreComments() {
        if (commentsData == null || commentsData.next == null) return;
        commentsMoreBtn.setEnabled(false);
        ((TextView) commentsMoreBtn).setText("Loading…");
        final Yt.Comments cd = commentsData;
        final int g = commentsGen;
        pool.execute(() -> {
            try {
                final Yt.Comments more = Yt.commentsMore(cd);
                runOnUiThread(() -> {
                    if (g != commentsGen) return;
                    commentsMoreBtn.setEnabled(true);
                    ((TextView) commentsMoreBtn).setText("Show more comments");
                    applyComments(more, true);
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (g != commentsGen) return;
                    commentsMoreBtn.setEnabled(true);
                    ((TextView) commentsMoreBtn).setText("Show more comments");
                    Toast.makeText(PlayerActivity.this, "Couldn't load more comments", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    /** One comment row: avatar, author, time, text, likes, replies. */
    private View commentView(final JSONObject c, final int idx, final boolean isReply) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = Ui.dp(8);
        if (isReply) cp.leftMargin = Ui.dp(42);
        card.setLayoutParams(cp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.TOP);
        int avSize = isReply ? Ui.dp(26) : Ui.dp(34);
        ImageView av = new ImageView(this);
        av.setScaleType(ImageView.ScaleType.CENTER_CROP);
        av.setBackground(Ui.oval(Ui.surface2));
        LinearLayout.LayoutParams ap2 = new LinearLayout.LayoutParams(avSize, avSize);
        ap2.rightMargin = Ui.dp(10);
        row.addView(av, ap2);
        String avUrl = c.optString("avatar", "");
        if (!avUrl.isEmpty() && !avUrl.equals("null"))
            Glide.with(av).load(avUrl).override(96, 96).circleCrop().into(av);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        String author = c.optString("author", "");
        TextView nameV = Ui.text(this, author.isEmpty() ? "@user" : author, 12, true,
            c.optBoolean("owner", false) ? Ui.muted : Ui.fg);
        head.addView(nameV, new LinearLayout.LayoutParams(-2, -2));
        String when = c.optString("when", "");
        StringBuilder meta = new StringBuilder();
        if (c.optBoolean("pinned", false)) meta.append("Pinned");
        if (!when.isEmpty()) { if (meta.length() > 0) meta.append(" · "); meta.append(when); }
        if (meta.length() > 0) {
            TextView w = Ui.text(this, meta.toString(), 11, false, Ui.muted);
            w.setPadding(Ui.dp(8), 0, 0, 0);
            head.addView(w, new LinearLayout.LayoutParams(-2, -2));
        }
        col.addView(head);

        String text = c.optString("text", "");
        if (!text.isEmpty()) {
            TextView tv = Ui.text(this, text, 13.5f, false, Ui.fg);
            tv.setPadding(0, Ui.dp(3), 0, 0);
            col.addView(tv);
        }

        LinearLayout foot = new LinearLayout(this);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0, Ui.dp(5), 0, 0);
        String lt = c.optString("likesText", "");
        long likes = c.optLong("likes", -1);
        if ((lt.isEmpty() && likes > 0) || !lt.isEmpty()) {
            ImageView lk = Ui.icon(this, R.drawable.ic_like, Ui.muted, 14);
            foot.addView(lk, new LinearLayout.LayoutParams(Ui.dp(14), Ui.dp(14)));
            TextView lv = Ui.text(this, lt.isEmpty() ? Ui.count(likes) : lt, 11.5f, false, Ui.muted);
            lv.setPadding(Ui.dp(5), 0, 0, 0);
            foot.addView(lv, new LinearLayout.LayoutParams(-2, -2));
        }
        if (c.optBoolean("hearted", false)) {
            TextView heart = Ui.text(this, "♥", 13, true, Ui.accent);
            heart.setPadding(Ui.dp(10), 0, 0, 0);
            foot.addView(heart, new LinearLayout.LayoutParams(-2, -2));
        }
        col.addView(foot, new LinearLayout.LayoutParams(-1, -2));

        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        if (!isReply && c.optInt("replies", 0) > 0 && idx >= 0) {
            final LinearLayout repliesHolder = new LinearLayout(this);
            repliesHolder.setOrientation(LinearLayout.VERTICAL);
            final TextView repliesBtn = Ui.text(this, c.optInt("replies", 0)
                + (c.optInt("replies", 0) == 1 ? " reply" : " replies"), 12, true, Ui.accentText());
            repliesBtn.setPadding(0, Ui.dp(6), 0, Ui.dp(2));
            repliesBtn.setOnClickListener(v -> {
                if (repliesHolder.getChildCount() > 0) {
                    repliesHolder.setVisibility(repliesHolder.getVisibility() == View.VISIBLE
                        ? View.GONE : View.VISIBLE);
                    return;
                }
                repliesBtn.setText("Loading replies…");
                final Yt.Comments cd = commentsData;
                final int g = commentsGen;
                pool.execute(() -> {
                    try {
                        final List<JSONObject> reps = Yt.commentReplies(cd, idx);
                        runOnUiThread(() -> {
                            if (g != commentsGen) return;
                            repliesHolder.removeAllViews();
                            for (JSONObject r : reps) repliesHolder.addView(commentView(r, -1, true));
                            if (reps.isEmpty()) repliesBtn.setText("No replies");
                            else repliesBtn.setText(c.optInt("replies", 0)
                                + (c.optInt("replies", 0) == 1 ? " reply" : " replies"));
                        });
                    } catch (final Exception e) {
                        runOnUiThread(() -> {
                            if (g != commentsGen) return;
                            repliesBtn.setText("Couldn't load replies · tap to retry");
                            Toast.makeText(PlayerActivity.this, "Couldn't load replies", Toast.LENGTH_SHORT).show();
                        });
                    }
                });
            });
            card.addView(repliesBtn);
            card.addView(repliesHolder, new LinearLayout.LayoutParams(-1, -2));
        }
        return card;
    }

    private void openCommentDialog() {
        if (!Auth.signedIn(this)) { needLogin(); return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(8), Ui.dp(12), Ui.dp(8), Ui.dp(4));
        final EditText input = new EditText(this);
        input.setHint("Add a comment...");
        input.setHintTextColor(Ui.muted);
        input.setTextColor(Ui.fg);
        input.setTextSize(14);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMinLines(3);
        input.setGravity(Gravity.TOP);
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));
        dlg().setTitle("Add a comment").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Post", (dd, w) -> {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                postComment(input.getText().toString().trim());
            }).show();
        input.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
    }

    private void postComment(final String text) {
        if (text.isEmpty()) return;
        final String vid = videoId;
        Toast.makeText(this, "Posting comment…", Toast.LENGTH_SHORT).show();
        pool.execute(() -> {
            try {
                Auth.postComment(this, vid, text);
                runOnUiThread(() -> {
                    Toast.makeText(PlayerActivity.this, "Comment posted", Toast.LENGTH_SHORT).show();
                    if (vid.equals(videoId)) loadComments();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> Toast.makeText(PlayerActivity.this,
                    "Couldn't post: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    // ------------------------------------------------------------------ chips / actions UI

    private void updateChips() {
        styleChip(audioChip, audioMode, audioMode ? "Video" : "Audio only");
        String q = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        String label;
        if (q.equals("auto")) label = "Auto";
        else label = q + "p";
        qualityChip.setText("Quality: " + label);
        qualityChip.setVisibility(audioMode ? View.GONE : View.VISIBLE);
    }

    private void updateRateUi() {
        long l = likesBase >= 0 ? likesBase + (rating == 1 ? 1 : 0) - (rating0 == 1 ? 1 : 0) : -1;
        long d = dislikesBase >= 0 ? dislikesBase + (rating == -1 ? 1 : 0) - (rating0 == -1 ? 1 : 0) : -1;
        styleChip(likeChip, rating == 1, l >= 0 ? Ui.count(l) : (!likesText.isEmpty() ? likesText : "Like"));
        styleChip(dislikeChip, rating == -1, d >= 0 ? Ui.count(d) : "");
    }

    private void updateSubUi() {
        subBtn.setText(subscribed ? "Subscribed" : "Subscribe");
        if (subscribed) {
            subBtn.setTextColor(Ui.fg);
            subBtn.setBackground(Ui.rect(Ui.surface, 18));
        } else {
            // YouTube's subscribe button: white pill, black text (dark mode) / black pill, white text (light)
            subBtn.setTextColor(Ui.pillOnFg());
            subBtn.setBackground(Ui.rect(Ui.pillOn(), 18));
        }
    }

    // ------------------------------------------------------------------ fullscreen

    private void applySystemUi(boolean f) {
        int flags = 0;
        if (f) {
            flags = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!Ui.dark) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void applyFull(boolean f) {
        full = f;
        scroll.setVisibility(f ? View.GONE : View.VISIBLE);
        ViewGroup.LayoutParams lp = playerBox.getLayoutParams();
        lp.height = f ? ViewGroup.LayoutParams.MATCH_PARENT : portraitH;
        playerBox.setLayoutParams(lp);
        if (f) root.setPadding(0, 0, 0, 0);
        else root.requestApplyInsets();
        applySystemUi(f);
    }

    private void setFull(boolean f) {
        setRequestedOrientation(f ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        applyFull(f);
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        boolean land = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (land != full) applyFull(land);
    }

    @Override public void onBackPressed() {
        if (customView != null) { hideCustomView(); return; }
        if (full) { setFull(false); return; }
        // back from a playing video: keep it running in the small player at the bottom of the feed (like YouTube)
        if (!webMode && exo != null && videoId != null && videoId.equals(PlaybackService.curId)
            && exo.getPlaybackState() != Player.STATE_IDLE && exo.getPlaybackState() != Player.STATE_ENDED) {
            PlaybackService.miniActive = true;
            finish();
            return;
        }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ player connection

    private void connectController() {
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                exo = PlaybackService.exo;
                if (exo == null) { showMsg("Player service not ready.\nTap to retry"); overlayMsg.setOnClickListener(v -> { overlayMsg.setVisibility(View.GONE); connectController(); }); return; }
                playerView.setPlayer(exo);
                playerListener = new Player.Listener() {
                    @Override public void onPlaybackStateChanged(int state) {
                        spinner.setVisibility(state == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                        if (state == Player.STATE_READY) {
                            startedOk = true;
                            handler.removeCallbacks(watchdog);
                            overlayMsg.setVisibility(View.GONE);
                        }
                        if (state == Player.STATE_ENDED) playNext();
                    }
                    @Override public void onPlayerError(PlaybackException error) { advance(error.getErrorCodeName()); }
                };
                exo.addListener(playerListener);
                if (pendingStart) {
                    pendingStart = false;
                    if (!isFinishing() && !isDestroyed()) startPlayback(resumeMs);
                }
            } catch (Exception e) {
                showMsg("Player service connection failed: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void showMsg(String m) {
        spinner.setVisibility(View.GONE);
        overlayMsg.setText(m);
        overlayMsg.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ loading

    private void loadStreams() {
        final int g = ++loadGen;
        final String vid = videoId;
        info = null;
        cands.clear();
        handler.removeCallbacks(watchdog);
        spinner.setVisibility(View.VISIBLE);
        overlayMsg.setVisibility(View.GONE);
        overlayMsg.setOnClickListener(null);
        pool.execute(() -> {
            try {
                final Yt.Info d = Yt.info(vid);
                runOnUiThread(() -> { if (g == loadGen) onInfo(d, true); });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (g != loadGen) return;
                    String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    String hint = "";
                    if (m.contains("LOGIN_REQUIRED") || m.toLowerCase().contains("bot")) {
                        hint = Auth.signedIn(PlayerActivity.this)
                            ? "\n\nYouTube is checking this connection. Wait a moment and tap to retry; "
                              + "if it keeps happening, Sign out and sign in again from the You tab."
                            : "\n\nSign in from the You tab, then try again.";
                    }
                    if (!(e instanceof java.net.UnknownHostException)) { startWebFallback(); return; }
                    showMsg("Couldn't load this video.\n" + m + hint + "\n\nTap to retry");
                    overlayMsg.setOnClickListener(v -> { reExtracted = false; loadStreams(); });
                });
            }
        });
    }

    /** Only refreshes title / description / related / comments — used when returning from the mini player. */
    private void loadMetaOnly() {
        final int g = ++loadGen;
        final String vid = videoId;
        pool.execute(() -> {
            try {
                final Yt.Info d = Yt.info(vid);
                runOnUiThread(() -> { if (g == loadGen) onInfo(d, false); });
            } catch (Exception ignored) { }
        });
    }

    private void onInfo(Yt.Info d, boolean startPlay) {
        if (isFinishing() || isDestroyed()) return;   // user already left — don't start a ghost video
        info = d;
        if (!d.title.isEmpty()) { title = d.title; titleV.setText(d.title); }
        if (!d.uploader.isEmpty()) { uploader = d.uploader; channelV.setText(d.uploader); }
        if (!d.avatar.isEmpty()) Glide.with(avatarV).load(d.avatar).override(96, 96).circleCrop().into(avatarV);
        if (d.subs >= 0) { subsV.setText(Ui.count(d.subs) + " subscribers"); subsV.setVisibility(View.VISIBLE); }
        else subsV.setVisibility(View.GONE);
        curChannelId = d.channelId;
        subscribed = Auth.isSubscribed(this, d.channelId);
        updateSubUi();

        StringBuilder m = new StringBuilder();
        if (d.live) m.append("● LIVE");
        if (d.views >= 0) { if (m.length() > 0) m.append("  ·  "); m.append(Ui.count(d.views)).append(d.live ? " watching" : " views"); }
        if (!d.uploadDate.isEmpty()) { if (m.length() > 0) m.append("  ·  "); m.append(d.uploadDate); }
        metaV.setText(m.toString());

        likesBase = d.likes;
        dislikesBase = -1;
        updateRateUi();
        final String vid = d.id;

        String desc = d.desc;
        if (!desc.isEmpty()) {
            if (desc.length() > 4000) desc = desc.substring(0, 4000);
            CharSequence cs = d.descHtml ? (Build.VERSION.SDK_INT >= 24 ? Html.fromHtml(desc, 0) : Html.fromHtml(desc)) : desc;
            descV.setText(cs);
            descV.setVisibility(View.VISIBLE);
        } else {
            descV.setVisibility(View.GONE);
        }

        relatedBox.removeAllViews();
        for (int i = 0; i < d.related.size() && i < 30; i++) {
            VideoCardView c = new VideoCardView(this);
            c.bind(d.related.get(i), this);
            relatedBox.addView(c, new LinearLayout.LayoutParams(-1, -2));
        }

        // sponsor / ad segments
        segments = new ArrayList<>();
        if (!d.live && prefs.getBoolean("adblock", true)) {
            pool.execute(() -> {
                final List<double[]> s = Yt.sponsorSegments(vid);
                runOnUiThread(() -> { if (vid.equals(videoId)) segments = s; });
            });
        }

        // make sure the subscribe button is accurate (subscription list is fetched once after login)
        if (Auth.signedIn(this) && prefs.getLong("subs_time", 0) == 0) {
            pool.execute(() -> {
                try { Auth.refreshSubscriptions(this); } catch (Exception ignored) { }
                runOnUiThread(() -> { subscribed = Auth.isSubscribed(this, curChannelId); updateSubUi(); });
            });
        }

        updateChips();
        loadComments();
        if (startPlay) {
            buildCandidates();
            startPlayback(resumeMs);
            resumeMs = 0;
        }
    }

    // ------------------------------------------------------------------ stream selection

    private int targetHeight() {
        String q = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        if (q.equals("auto")) return 720;
        try { return Integer.parseInt(q); } catch (Exception e) { return 720; }
    }

    private static int codecRank(String codec) {
        if (codec.startsWith("avc")) return 0;
        if (codec.startsWith("av01")) return 2;
        return 1;
    }

    private Yt.VS pickVideo(List<Yt.VS> list, int target, boolean avc) {
        Yt.VS best = null, lowestAbove = null;
        for (Yt.VS v : list) {
            boolean isAvc = codecRank(v.codec) == 0;
            if (avc != isAvc) continue;
            if (!avc && codecRank(v.codec) == 2) continue;
            if (v.height <= target) {
                if (best == null || v.height > best.height) best = v;
            } else if (lowestAbove == null || v.height < lowestAbove.height) {
                lowestAbove = v;
            }
        }
        return best != null ? best : lowestAbove;
    }

    private Yt.AS pickAudio(boolean m4a) {
        Yt.AS best = null, any = null;
        for (Yt.AS a : info.audio) {
            if (any == null || a.bitrate > any.bitrate) any = a;
            boolean isM4a = a.suffix.equals("m4a") || a.suffix.equals("mp4");
            if (isM4a != m4a) continue;
            if (best == null || a.bitrate > best.bitrate) best = a;
        }
        return best != null ? best : any;
    }

    private void buildCandidates() {
        buildBaseCandidates();
        List<Cand> out = new ArrayList<>();
        for (Cand c : cands) {
            out.add(c);
            if (c.type != T_HLS) out.add(new Cand(c.type, c.v, c.a, true));
        }
        cands.clear();
        cands.addAll(out);
        candIdx = 0;
    }

    private void buildBaseCandidates() {
        cands.clear();
        candIdx = 0;
        if (info == null) return;
        Yt.Info d = info;
        if (audioMode) {
            List<Yt.AS> a = new ArrayList<>(d.audio);
            Collections.sort(a, new Comparator<Yt.AS>() {
                @Override public int compare(Yt.AS x, Yt.AS y) {
                    boolean xm = x.suffix.equals("m4a"), ym = y.suffix.equals("m4a");
                    if (xm != ym) return xm ? -1 : 1;
                    return Integer.compare(y.bitrate, x.bitrate);
                }
            });
            for (Yt.AS s : a) cands.add(new Cand(T_AUDIO, s.url, null));
            if (!d.hls.isEmpty()) cands.add(new Cand(T_HLS, d.hls, null));
            return;
        }
        if (d.live && !d.hls.isEmpty()) cands.add(new Cand(T_HLS, d.hls, null));
        int target = targetHeight();
        // 1) high quality: separate video + audio merged on the device
        Yt.AS a1 = pickAudio(true), a2 = pickAudio(false);
        Yt.VS v1 = pickVideo(d.videoOnly, target, true), v2 = pickVideo(d.videoOnly, target, false);
        if (v1 != null && a1 != null) cands.add(new Cand(T_MERGED, v1.url, a1.url));
        if (v2 != null && a2 != null) cands.add(new Cand(T_MERGED, v2.url, a2.url));
        // 2) single-file streams (most compatible)
        List<Yt.VS> prog = new ArrayList<>(d.muxed);
        final int tg = target;
        Collections.sort(prog, new Comparator<Yt.VS>() {
            @Override public int compare(Yt.VS x, Yt.VS y) {
                boolean xo = x.height <= tg, yo = y.height <= tg;
                if (xo != yo) return xo ? -1 : 1;
                return xo ? Integer.compare(y.height, x.height) : Integer.compare(x.height, y.height);
            }
        });
        for (Yt.VS s : prog) cands.add(new Cand(T_PROG, s.url, null));
        // 3) HLS as a last resort
        if (!d.live && !d.hls.isEmpty()) cands.add(new Cand(T_HLS, d.hls, null));
    }

    private MediaItem item(String url, String mime) {
        MediaMetadata.Builder md = new MediaMetadata.Builder().setTitle(title).setArtist(uploader);
        if (thumb != null && !thumb.isEmpty()) md.setArtworkUri(Uri.parse(thumb));
        MediaItem.Builder mb = new MediaItem.Builder().setUri(url).setMediaId(String.valueOf(videoId))
            .setMediaMetadata(md.build());
        if (mime != null) mb.setMimeType(mime);
        return mb.build();
    }

    private MediaSource source(Cand c) {
        DataSource.Factory f = Net.dataSourceFactory(this);
        if (c.type == T_HLS) return new HlsMediaSource.Factory(f).createMediaSource(item(c.v, MimeTypes.APPLICATION_M3U8));
        ProgressiveMediaSource.Factory pf = new ProgressiveMediaSource.Factory(f);
        if (c.type == T_MERGED)
            return new MergingMediaSource(pf.createMediaSource(item(c.v, null)), pf.createMediaSource(item(c.a, null)));
        return pf.createMediaSource(item(c.v, null));
    }

    private void startPlayback(long seekMs) {
        // remember what is playing so the mini player in the feed can show it
        PlaybackService.curId = videoId == null ? "" : videoId;
        PlaybackService.curTitle = title == null ? "" : title;
        PlaybackService.curUploader = uploader == null ? "" : uploader;
        PlaybackService.curThumb = thumb == null ? "" : thumb;
        PlaybackService.curAudio = audioMode;
        if (cands.isEmpty()) {
            if (info != null) showMsg("No playable stream was found for this video.");
            return;
        }
        if (exo == null) { resumeMs = seekMs; pendingStart = true; return; }
        if (candIdx >= cands.size()) candIdx = 0;
        Cand c = cands.get(candIdx);
        Net.postMode = c.post;
        startedOk = false;
        try {
            MediaSource ms = source(c);
            if (seekMs > 0 && !(info != null && info.live)) exo.setMediaSource(ms, seekMs);
            else exo.setMediaSource(ms);
            exo.prepare();
            exo.setPlayWhenReady(true);
        } catch (Exception e) {
            advance(String.valueOf(e.getMessage()));
            return;
        }
        handler.removeCallbacks(watchdog);
        handler.postDelayed(watchdog, 12000);
        if (audioMode) Toast.makeText(this, "Audio mode · keeps playing with the screen off", Toast.LENGTH_SHORT).show();
    }

    /** Current stream failed: try the next one, then fetch fresh links once, then give up with a retry button. */
    private void advance(String why) {
        handler.removeCallbacks(watchdog);
        if (exo == null) return;
        long pos = Math.max(0, exo.getCurrentPosition());
        if (candIdx + 1 < cands.size()) {
            candIdx++;
            startPlayback(startedOk ? pos : 0);
            return;
        }
        if (!reExtracted) {
            reExtracted = true;
            resumeMs = startedOk ? pos : 0;
            loadStreams();
            return;
        }
        startWebFallback();
    }

    // ------------------------------------------------------------------ compatibility (web) player

    private void hideCustomView() {
        if (customView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        applySystemUi(false);
    }

    private void leaveWebMode() {
        if (!webMode) return;
        webMode = false;
        webAlt = false;
        hideCustomView();
        if (webPlayer != null) { webPlayer.loadUrl("about:blank"); webPlayer.setVisibility(View.GONE); }
        stopService(new Intent(this, KeepAliveService.class));
        playerView.setVisibility(View.VISIBLE);
    }

    /**
     * Direct stream extraction can be blocked for an IP ("confirm you're not a bot"). YouTube's own web player running in a
     * real WebView with the signed-in session is not blocked, so we fall back to it. Ads are auto-skipped by a small script.
     */
    private void startWebFallback() {
        handler.removeCallbacks(watchdog);
        if (exo != null) exo.stop();
        spinner.setVisibility(View.GONE);
        overlayMsg.setVisibility(View.GONE);
        playerView.setVisibility(View.GONE);
        webMode = true;
        if (webPlayer == null) {
            webPlayer = new WebView(this);
            webPlayer.setBackgroundColor(0xFF000000);
            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(webPlayer, true);
            WebSettings ws = webPlayer.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setMediaPlaybackRequiresUserGesture(false);
            ws.setUserAgentString(Net.UA_WEB);
            webPlayer.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String url) {
                    if (url == null || !url.contains("youtube.com")) return;
                    if (prefs.getBoolean("adblock", true)) v.evaluateJavascript(AD_JS, null);
                    if (bgOn(videoId)) v.evaluateJavascript(BG_JS, null);
                }
            });
            webPlayer.setWebChromeClient(new WebChromeClient() {
                @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                    if (customView != null) { cb.onCustomViewHidden(); return; }
                    customView = v;
                    customCb = cb;
                    ((FrameLayout) getWindow().getDecorView()).addView(v, new FrameLayout.LayoutParams(-1, -1));
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                    applySystemUi(true);
                }
                @Override public void onHideCustomView() { hideCustomView(); }
            });
            playerBox.addView(webPlayer, new FrameLayout.LayoutParams(-1, -1));
        }
        webPlayer.setVisibility(View.VISIBLE);
        if (webAlt) {
            webPlayer.loadUrl("https://m.youtube.com/watch?v=" + videoId);
        } else {
            Map<String, String> h = new HashMap<>();
            h.put("Referer", "https://www.youtube.com/");
            webPlayer.loadUrl("https://www.youtube.com/embed/" + videoId
                + "?autoplay=1&playsinline=1&rel=0&fs=1&enablejsapi=1", h);
        }
        Toast.makeText(this, "Using compatibility player", Toast.LENGTH_SHORT).show();
        if (bgOn(videoId)) {
            try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); }
            catch (Exception ignored) { }
        }
        // channel / likes / subscribers / suggestions via YouTube's own page data (not blocked like stream extraction)
        final String vid = videoId;
        pool.execute(() -> {
            try {
                final Yt.Info w = Yt.webInfo(vid, Auth.nextInfo(this, vid));
                runOnUiThread(() -> onWebInfo(w));
            } catch (Exception ignored) { }
        });
    }

    private void onWebInfo(Yt.Info w) {
        if (!webMode || !w.id.equals(videoId)) return;
        if (!w.channelId.isEmpty()) curChannelId = w.channelId;
        if (!w.uploader.isEmpty()) { uploader = w.uploader; channelV.setText(w.uploader); }
        if (!w.title.isEmpty()) { title = w.title; titleV.setText(w.title); }
        if (!w.avatar.isEmpty()) Glide.with(avatarV).load(w.avatar).override(96, 96).circleCrop().into(avatarV);
        if (!w.subsText.isEmpty()) { subsV.setText(w.subsText); subsV.setVisibility(View.VISIBLE); }
        likesText = w.likesText;
        subscribed = Auth.isSubscribed(this, curChannelId);
        updateSubUi();
        updateRateUi();
        relatedBox.removeAllViews();
        for (int i = 0; i < w.related.size() && i < 30; i++) {
            VideoCardView c = new VideoCardView(this);
            c.bind(w.related.get(i), this);
            relatedBox.addView(c, new LinearLayout.LayoutParams(-1, -2));
        }
        loadComments();
    }

    // ------------------------------------------------------------------ actions

    private AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK
            : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    }

    private void toggleAudio() {
        if (webMode) { Toast.makeText(this, "Audio-only isn't available in compatibility mode", Toast.LENGTH_SHORT).show(); return; }
        long pos = exo == null ? 0 : Math.max(0, exo.getCurrentPosition());
        audioMode = !audioMode;
        updateChips();
        buildCandidates();
        startPlayback(pos);
        if (audioMode && !bgOn(videoId))
            Toast.makeText(this, "Tip: turn on Background play below to keep listening with the screen off",
                Toast.LENGTH_LONG).show();
    }

    private void pickQuality() {
        if (info == null) return;
        final List<String> labels = new ArrayList<>(), values = new ArrayList<>();
        labels.add("Auto (up to 720p)"); values.add("auto");
        List<Integer> hs = new ArrayList<>();
        for (Yt.VS s : info.videoOnly) if (s.height > 0 && !hs.contains(s.height)) hs.add(s.height);
        for (Yt.VS s : info.muxed) if (s.height > 0 && !hs.contains(s.height)) hs.add(s.height);
        Collections.sort(hs, Collections.reverseOrder());
        for (int h : hs) { labels.add(h + "p"); values.add(String.valueOf(h)); }
        String cur = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        int checked = Math.max(0, values.indexOf(cur));
        new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Video quality")
            .setSingleChoiceItems(labels.toArray(new String[0]), checked, (dlg, w) -> {
                forcedQuality = values.get(w);
                dlg.dismiss();
                long pos = exo == null ? 0 : Math.max(0, exo.getCurrentPosition());
                updateChips();
                buildCandidates();
                startPlayback(pos);
            }).show();
    }

    private void needLogin() {
        new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Sign in required")
            .setMessage("Sign in with your Google account to like, comment and subscribe to channels.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Sign in", (d, w) -> startActivityForResult(new Intent(this, LoginActivity.class), RC_LOGIN))
            .show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOGIN && res == RESULT_OK) {
            rating = rating0 = Auth.ratingOf(this, videoId);
            subscribed = Auth.isSubscribed(this, curChannelId);
            updateRateUi();
            updateSubUi();
            Toast.makeText(this, "Signed in", Toast.LENGTH_SHORT).show();
        }
    }

    private void rate(int want) {
        if (!Auth.signedIn(this)) { needLogin(); return; }
        final int prev = rating;
        final int next = prev == want ? 0 : want;
        final String action = next == 0 ? "removelike" : (next == 1 ? "like" : "dislike");
        final String vid = videoId;
        rating = next;
        Auth.saveRating(this, vid, next);
        updateRateUi();
        pool.execute(() -> {
            try { Auth.rate(this, vid, action); }
            catch (final Exception e) {
                runOnUiThread(() -> {
                    Auth.saveRating(this, vid, prev);
                    if (vid.equals(videoId)) { rating = prev; updateRateUi(); }
                    Toast.makeText(this, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void toggleSubscribe() {
        if (curChannelId.isEmpty()) {
            Toast.makeText(this, "Channel not loaded yet", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Auth.signedIn(this)) { needLogin(); return; }
        final String cid = curChannelId;
        final boolean want = !subscribed;
        subscribed = want;
        updateSubUi();
        pool.execute(() -> {
            try { Auth.subscribe(this, cid, want); }
            catch (final Exception e) {
                runOnUiThread(() -> {
                    subscribed = !want;
                    updateSubUi();
                    Toast.makeText(this, "Couldn't update subscription: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void playNext() {
        if (!prefs.getBoolean("autoplay", true) || info == null || info.related.isEmpty()) return;
        JSONObject n = info.related.get(0);
        String id = Yt.videoId(n.optString("url", ""));
        if (id.isEmpty() || id.equals(videoId)) return;
        onOpen(id, n.optString("title", ""), n.optString("uploaderName", ""), n.optString("thumbnail", ""),
            n.optString("uploaderAvatar", ""), audioMode);
    }

    /** Called when a suggested video is tapped; reuses this screen instead of stacking new ones. */
    @Override public void onOpen(String id, String t, String author, String th, String av, boolean audio) {
        if (id == null || id.isEmpty()) return;
        Ui.saveHistory(this, id, t, author, th);
        videoId = id;
        title = t;
        uploader = author;
        thumb = th;
        audioMode = audio;
        forcedQuality = null;
        leaveWebMode();
        reExtracted = false;
        resumeMs = 0;
        rating = rating0 = Auth.ratingOf(this, id);
        likesBase = dislikesBase = -1;
        likesText = "";
        curChannelId = "";
        relatedBox.removeAllViews();
        subscribed = false;
        segments = new ArrayList<>();
        resetComments();
        updateBgRow();
        titleV.setText(t == null ? "" : t);
        channelV.setText(author == null ? "" : author);
        subsV.setVisibility(View.GONE);
        metaV.setText("");
        descV.setVisibility(View.GONE);
        avatarV.setImageDrawable(null);
        if (av != null && !av.isEmpty()) Glide.with(avatarV).load(av).override(96, 96).circleCrop().into(avatarV);
        scroll.scrollTo(0, 0);
        updateChips();
        updateRateUi();
        updateSubUi();
        loadStreams();
    }

    // ------------------------------------------------------------------ lifecycle

    @Override protected void onPause() {
        boolean keep = webMode && bgOn(videoId) && !isFinishing();
        if (webPlayer != null && !keep) webPlayer.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webPlayer != null) webPlayer.onResume();
    }

    @Override protected void onStop() {
        // pause unless background play is on for this particular video
        if (!bgOn(videoId) && exo != null) exo.pause();
        super.onStop();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (exo != null && playerListener != null) exo.removeListener(playerListener);
        if (playerView != null) playerView.setPlayer(null);
        // going back to the mini player? then playback must survive; otherwise stop it unless this
        // video is allowed to run in the background (or the activity is just being recreated)
        if (!PlaybackService.miniActive && !isChangingConfigurations() && !bgOn(videoId) && exo != null) exo.stop();
        if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
        controller = null;
        exo = null;
        stopService(new Intent(this, KeepAliveService.class));
        if (webPlayer != null) { webPlayer.stopLoading(); webPlayer.destroy(); webPlayer = null; }
        pool.shutdownNow();
        super.onDestroy();
    }
}
