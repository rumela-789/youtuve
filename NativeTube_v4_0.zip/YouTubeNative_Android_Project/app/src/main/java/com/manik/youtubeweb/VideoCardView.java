package com.manik.youtubeweb;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Outline;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import org.json.JSONObject;

/** One video row: 16:9 thumbnail with duration badge, channel avatar, title, metadata and a menu. */
final class VideoCardView extends LinearLayout {
    interface Listener {
        void onOpen(String id, String title, String author, String thumb, boolean audioOnly);
    }

    private final ImageView thumb, avatar, more;
    private final TextView title, meta, badge;

    VideoCardView(Context c) {
        super(c);
        setOrientation(VERTICAL);
        int margin = Ui.dp(12);
        setPadding(margin, Ui.dp(8), margin, Ui.dp(10));

        int sw = c.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(sw, Ui.dp(640)) - 2 * margin;
        int h = w * 9 / 16;

        FrameLayout box = new FrameLayout(c);
        box.setBackground(Ui.rect(Ui.surface2, 14));
        box.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(14));
            }
        });
        box.setClipToOutline(true);
        thumb = new ImageView(c);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        box.addView(thumb, new FrameLayout.LayoutParams(-1, -1));
        badge = Ui.text(c, "", 11, true, 0xFFFFFFFF);
        badge.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(2));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2);
        bp.gravity = Gravity.BOTTOM | Gravity.END;
        bp.setMargins(0, 0, Ui.dp(8), Ui.dp(8));
        box.addView(badge, bp);
        addView(box, new LinearLayout.LayoutParams(-1, h));

        LinearLayout row = new LinearLayout(c);
        row.setPadding(0, Ui.dp(10), 0, 0);
        row.setGravity(Gravity.TOP);
        avatar = new ImageView(c);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38));
        ap.rightMargin = Ui.dp(12);
        row.addView(avatar, ap);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(VERTICAL);
        title = Ui.text(c, "", 15, true, Ui.fg);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        meta = Ui.text(c, "", 12, false, Ui.muted);
        meta.setMaxLines(2);
        meta.setEllipsize(TextUtils.TruncateAt.END);
        meta.setPadding(0, Ui.dp(3), 0, 0);
        col.addView(title);
        col.addView(meta);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        more = Ui.icon(c, R.drawable.ic_more, Ui.muted, 22);
        more.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(2), Ui.dp(6));
        row.addView(more, new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(34)));
        addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    void bind(JSONObject it, final Listener l) {
        final String id = Yt.videoId(it.optString("url", it.optString("id", "")));
        final String t = it.optString("title", "Untitled video");
        final String a = Ui.firstNonEmpty(it.optString("uploaderName", ""), it.optString("uploader", ""),
                it.optString("author", ""));
        String th = Ui.firstNonEmpty(it.optString("thumbnail", ""), it.optString("thumb", ""));
        if (th.isEmpty() && id.length() == 11) th = "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg";
        final String thumbUrl = th;

        title.setText(t);
        StringBuilder m = new StringBuilder(a);
        long v = it.optLong("views", -1);
        if (v >= 0) { if (m.length() > 0) m.append("  ·  "); m.append(Ui.count(v)).append(" views"); }
        String ago = it.optString("uploadedDate", "");
        if (!ago.isEmpty() && !ago.equals("null")) { if (m.length() > 0) m.append("  ·  "); m.append(ago); }
        meta.setText(m.toString());

        long d = it.optLong("duration", 0);
        if (d < 0) {
            badge.setText("● LIVE");
            badge.setBackground(Ui.rect(0xFFE5213A, 6));
            badge.setVisibility(View.VISIBLE);
        } else if (d > 0) {
            badge.setText(Ui.duration(d));
            badge.setBackground(Ui.rect(0xCC000000, 6));
            badge.setVisibility(View.VISIBLE);
        } else {
            badge.setVisibility(View.GONE);
        }

        Glide.with(thumb).load(thumbUrl).override(640, 360).centerCrop()
                .placeholder(new ColorDrawable(Ui.surface2))
                .transition(DrawableTransitionOptions.withCrossFade(120)).into(thumb);

        avatar.setBackground(Ui.oval(Ui.surface2));
        String av = it.optString("uploaderAvatar", "");
        if (!av.isEmpty() && !av.equals("null")) {
            Glide.with(avatar).load(av).override(96, 96).circleCrop().into(avatar);
        } else {
            Glide.with(avatar).clear(avatar);
            avatar.setImageDrawable(null);
            avatar.setBackground(Ui.gradientOval());
        }

        setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { l.onOpen(id, t, a, thumbUrl, false); }
        });
        more.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                PopupMenu pm = new PopupMenu(getContext(), view);
                pm.getMenu().add(0, 1, 0, "Play in background");
                pm.getMenu().add(0, 2, 1, "Share");
                pm.getMenu().add(0, 3, 2, "Copy link");
                pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override public boolean onMenuItemClick(android.view.MenuItem mi) {
                        String link = "https://youtu.be/" + id;
                        if (mi.getItemId() == 1) {
                            l.onOpen(id, t, a, thumbUrl, true);
                        } else if (mi.getItemId() == 2) {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("text/plain");
                            i.putExtra(Intent.EXTRA_TEXT, t + "\n" + link);
                            getContext().startActivity(Intent.createChooser(i, "Share"));
                        } else {
                            ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", link));
                            Toast.makeText(getContext(), "Link copied", Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    }
                });
                pm.show();
            }
        });
    }
}
