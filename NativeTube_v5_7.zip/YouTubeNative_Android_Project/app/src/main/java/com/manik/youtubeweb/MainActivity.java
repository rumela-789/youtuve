package com.manik.youtubeweb;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import java.util.HashMap;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.view.ViewOutlineProvider;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** YouTube Premium home: Home / Subscriptions / History / You (profile). Feed videos play inline. */
public class MainActivity extends Activity implements VideoCardView.Listener {
    private static final int RC_LOGIN = 9001;

    private static final String[] TOPICS = {"music", "bangla natok", "gaming", "news today", "movie trailers",
        "comedy", "bangla song", "sports highlights", "technology", "podcast", "cooking", "travel vlog",
        "live now", "science", "cartoon"};
    private static final String[] TOPIC_SUFFIX = {"", " latest", " best", " 2026"};
    private static final String[] CHIPS = {"All", "Music", "Gaming", "News", "Live", "Movies", "Comedy",
        "Sports", "Tech", "Bangla"};
    private static final String[] TABS = {"home", "subs", "history", "profile"};
    private static final String[] TAB_LABELS = {"Home", "Subs", "History", "You"};
    private static final int[] TAB_ICONS = {R.drawable.ic_home, R.drawable.ic_subs,
        R.drawable.ic_history, R.drawable.ic_profile};
    private static final String[][] REGIONS = {{"US", "United States"}, {"GB", "United Kingdom"},
        {"BD", "Bangladesh"}, {"IN", "India"}, {"PK", "Pakistan"}, {"CA", "Canada"}, {"AU", "Australia"},
        {"DE", "Germany"}, {"FR", "France"}, {"BR", "Brazil"}, {"JP", "Japan"}, {"SA", "Saudi Arabia"},
        {"AE", "United Arab Emirates"}, {"MY", "Malaysia"}};
    private static final String[][] QUALITIES = {{"auto", "Auto (up to 720p)"}, {"1080", "1080p"}, {"720", "720p"},
        {"480", "480p"}, {"360", "360p"}};

    private interface BoolCb { void on(boolean v); }

    private SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(6);
    private LinearLayout root, nav, searchRow, chipRow, emptyView;
    private HorizontalScrollView chipScroll;
    private EditText searchBox;
    private TextView status;
    private LinearLayout top;
    private FrameLayout miniBox;
    private PlayerView miniPlayer;
    private ImageView miniThumb, miniPlayBtn;
    private EqualizerView miniEq;
    private View miniProg;
    private int miniW;
    private boolean warmed = false;
    private FeedPlayer feedPlayer;
    private boolean resumed = false;
    private final Runnable autoplayRun = new Runnable() {
        @Override public void run() { updateAutoplay(); }
    };

    // per-tab memory so switching tabs never reloads (or reshuffles) a feed by itself
    private static final class TabState {
        List<JSONObject> data; Object nextTok; int topicIndex, pos, off; String status; Set<String> seen;
    }
    private final HashMap<String, TabState> states = new HashMap<>();
    private final List<JSONObject> heldRecs = new ArrayList<>(), heldSubs = new ArrayList<>();
    private boolean holdHome = false;
    private int homeRecJobs = 0;

    private void saveState() {
        if (adapter == null || adapter.skeleton || adapter.data.isEmpty() || searchQuery != null || showingCache || holdHome) return;
        if (!(tab.equals("home") || tab.equals("subs"))) return;
        TabState st = new TabState();
        st.data = new ArrayList<>(adapter.data);
        st.nextTok = nextTok;
        st.topicIndex = topicIndex;
        st.seen = new HashSet<>(seen);
        st.status = String.valueOf(status.getText());
        st.pos = Math.max(0, lm.findFirstVisibleItemPosition());
        View v = lm.findViewByPosition(st.pos);
        st.off = v == null ? 0 : v.getTop();
        states.put(tab, st);
    }

    private boolean restoreState(String key) {
        TabState st = states.get(key);
        if (st == null || st.data.isEmpty()) return false;
        adapter.addAll(new ArrayList<>(st.data));
        seen.addAll(st.seen);
        nextTok = st.nextTok;
        topicIndex = st.topicIndex;
        status.setText(st.status);
        final int pos = st.pos, off = st.off;
        recycler.post(() -> lm.scrollToPositionWithOffset(pos, off));
        return true;
    }
    private final Runnable miniTick = new Runnable() {
        @Override public void run() {
            ExoPlayer e = PlaybackService.exo;
            if (e != null && miniBox.getVisibility() == View.VISIBLE) {
                long d = e.getDuration();
                ViewGroup.LayoutParams lp = miniProg.getLayoutParams();
                lp.width = d > 0 ? (int) (miniW * Math.min(1.0, e.getCurrentPosition() / (double) d)) : 0;
                miniProg.setLayoutParams(lp);
                miniBox.postDelayed(this, 500);
            }
        }
    };
    private final Player.Listener miniListener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int st) { updateMini(); }
        @Override public void onPlayWhenReadyChanged(boolean pwr, int reason) { updateMini(); }
    };
    private ScrollView profileScroll;
    private RecyclerView recycler;
    private SwipeRefreshLayout swipe;
    private boolean manualRefresh = false;
    private LinearLayoutManager lm;
    private FeedAdapter adapter;
    private final LinearLayout[] navItems = new LinearLayout[TABS.length];

    private String tab = "", searchQuery = null, chip = "All";
    private Object nextTok = null, lastTok = null;
    private String lastError = null;
    private final Set<String> seen = new HashSet<>();
    private int gen = 0, pending = 0, topicIndex = 0;
    private boolean loadingMore = false, showingCache = false, prefetch = false;
    private long lastBack = 0;

    private String region() { return prefs.getString("region", "BD"); }

    private static String regionName(String code) {
        for (String[] r : REGIONS) if (r[0].equals(code)) return r[1];
        return "";
    }

    // ------------------------------------------------------------------ lifecycle

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = Ui.prefs(this);
        Ui.load(this);
        PoTokens.install(this);
        feedPlayer = new FeedPlayer(this);
        Yt.init(region());
        Net.setCookie(Auth.cookie(this));
        PoTokens.warmUp();
        try { startService(new Intent(this, PlaybackService.class)); } catch (Exception ignored) { }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 701);
        }
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        if (!Ui.dark) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        build();
        String restore = prefs.getString("restore_tab", "home");
        if (!restore.equals("home") && !restore.equals("subs") && !restore.equals("history") && !restore.equals("profile")) restore = "home";
        prefs.edit().remove("restore_tab").apply();
        switchTab(restore);
        refreshAccountInBackground();
    }

    @Override protected void onStart() {
        super.onStart();
        PlaybackService.activityStarted();
    }

    @Override protected void onStop() {
        PlaybackService.activityStopped();
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (feedPlayer != null) feedPlayer.release();
        pool.shutdownNow();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (!tab.equals("home") || searchQuery != null || searchRow.getVisibility() == View.VISIBLE) {
            searchQuery = null;
            searchBox.setText("");
            chip = "All";
            updateChips();
            tab = "";
            switchTab("home");
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) { finish(); return; }
        lastBack = now;
        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ layout

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(6), Ui.dp(4));
        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_yt_logo);
        brandRow.addView(logo, new LinearLayout.LayoutParams(Ui.dp(30), Ui.dp(21)));
        TextView brand = Ui.text(this, "Premium", 21, true, Ui.fg);
        brand.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        brand.setLetterSpacing(-0.06f);
        brand.setPadding(Ui.dp(6), 0, Ui.dp(3), 0);
        brandRow.addView(brand);
        top.addView(brandRow);
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        ImageView searchBtn = Ui.icon(this, R.drawable.ic_search, Ui.fg, 24);
        searchBtn.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        searchBtn.setContentDescription("Search");
        searchBtn.setOnClickListener(v -> setSearchMode(true));
        top.addView(searchBtn, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        root.addView(top);

        // search bar (opens when the search icon is tapped, like YouTube)
        searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchRow.setPadding(Ui.dp(4), Ui.dp(5), Ui.dp(12), Ui.dp(5));
        searchRow.setVisibility(View.GONE);
        ImageView sBack = Ui.icon(this, R.drawable.ic_back, Ui.fg, 24);
        sBack.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        sBack.setOnClickListener(v -> onBackPressed());
        searchRow.addView(sBack, new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(46)));
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setTextColor(Ui.fg);
        searchBox.setHintTextColor(Ui.muted);
        searchBox.setHint("Search YouTube");
        searchBox.setTextSize(16);
        searchBox.setPadding(Ui.dp(18), 0, Ui.dp(14), 0);
        searchBox.setBackground(Ui.rect(Ui.surface, 22));
        searchBox.setOnEditorActionListener((v, action, event) -> { doSearch(); return true; });
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, Ui.dp(42), 1));
        ImageView go = Ui.icon(this, R.drawable.ic_search, Ui.fg, 22);
        go.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        go.setBackground(Ui.oval(Ui.surface));
        go.setOnClickListener(v -> doSearch());
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(42), Ui.dp(42));
        gp.leftMargin = Ui.dp(8);
        searchRow.addView(go, gp);
        root.addView(searchRow);

        chipScroll = new HorizontalScrollView(this);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setPadding(Ui.dp(14), Ui.dp(2), Ui.dp(14), Ui.dp(8));
        chipScroll.addView(chipRow);
        root.addView(chipScroll);
        updateChips();

        status = Ui.text(this, "", 12, false, Ui.muted);
        status.setPadding(Ui.dp(18), Ui.dp(2), Ui.dp(18), Ui.dp(4));
        root.addView(status);

        FrameLayout content = new FrameLayout(this);
        recycler = new RecyclerView(this);
        lm = new LinearLayoutManager(this);
        recycler.setLayoutManager(lm);
        adapter = new FeedAdapter();
        recycler.setAdapter(adapter);
        recycler.setItemAnimator(null);
        recycler.setItemViewCacheSize(10);
        recycler.setHasFixedSize(false);
        recycler.setNestedScrollingEnabled(true);
        recycler.setClipToPadding(false);
        recycler.setPadding(0, 0, 0, Ui.dp(8));
        recycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrollStateChanged(RecyclerView rv, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) scheduleAutoplay(40);
            }
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy != 0) scheduleAutoplay(180);
                if (dy <= 0 || adapter.skeleton) return;
                if (lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 6) loadMore();
            }
        });
        swipe = new SwipeRefreshLayout(this);
        swipe.setColorSchemeColors(Ui.accent);
        swipe.setProgressBackgroundColorSchemeColor(Ui.surface2);
        swipe.addView(recycler, new ViewGroup.LayoutParams(-1, -1));
        swipe.setOnRefreshListener(() -> {
            manualRefresh = true;
            reloadCurrent();
            swipe.postDelayed(() -> swipe.setRefreshing(false), 900);
        });
        content.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
        emptyView = new LinearLayout(this);
        emptyView.setOrientation(LinearLayout.VERTICAL);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(Ui.dp(28), Ui.dp(20), Ui.dp(28), Ui.dp(60));
        emptyView.setVisibility(View.GONE);
        content.addView(emptyView, new FrameLayout.LayoutParams(-1, -1));
        profileScroll = new ScrollView(this);
        profileScroll.setVisibility(View.GONE);
        content.addView(profileScroll, new FrameLayout.LayoutParams(-1, -1));
        buildMini();
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        View divider = new View(this);
        divider.setBackgroundColor(Ui.line);
        root.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        nav = new LinearLayout(this);
        nav.setBackgroundColor(Ui.bg);
        nav.setPadding(Ui.dp(4), Ui.dp(6), Ui.dp(4), Ui.dp(6));
        for (int i = 0; i < TABS.length; i++) {
            final String id = TABS[i];
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setOnClickListener(v -> switchTab(id));
            navItems[i] = item;
            nav.addView(item, new LinearLayout.LayoutParams(0, Ui.dp(52), 1));
        }
        root.addView(nav);
        setContentView(root);
        miniBox.setVisibility(View.GONE);
        addContentView(miniBox, miniLp);
    }

    private void updateNav() {
        for (int i = 0; i < TABS.length; i++) {
            boolean sel = TABS[i].equals(tab);
            LinearLayout item = navItems[i];
            item.removeAllViews();
            int color = sel ? Ui.fg : Ui.muted;
            FrameLayout wrap = new FrameLayout(this);
            ImageView ic = Ui.icon(this, TAB_ICONS[i], color, 26);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(Ui.dp(26), Ui.dp(26));
            ip.gravity = Gravity.CENTER;
            wrap.addView(ic, ip);
            item.addView(wrap, new LinearLayout.LayoutParams(Ui.dp(60), Ui.dp(40)));
            item.setContentDescription(TAB_LABELS[i]);
        }
    }

    private void updateChips() {
        chipRow.removeAllViews();
        for (final String c : CHIPS) {
            boolean sel = c.equals(chip);
            TextView t = Ui.text(this, c, 13.5f, true, sel ? Ui.invFg : Ui.fg);
            t.setPadding(Ui.dp(14), Ui.dp(7), Ui.dp(14), Ui.dp(7));
            t.setBackground(Ui.rect(sel ? Ui.invBg : Ui.surface, 9));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.rightMargin = Ui.dp(8);
            chipRow.addView(t, p);
            t.setOnClickListener(v -> {
                chip = c;
                updateChips();
                setSearchMode(false);
                if (c.equals("All")) { searchBox.setText(""); loadHome(); }
                else { searchBox.setText(c); startSearch(queryFor(c)); }
            });
        }
    }

    private String queryFor(String c) {
        switch (c) {
            case "Live": return "live now";
            case "Movies": return "movie trailers";
            case "Tech": return "technology reviews";
            case "Bangla": return "bangla natok";
            case "News": return "news today";
            case "Sports": return "sports highlights";
            default: return c;
        }
    }

    /** Swaps the logo header for the search bar (and back). */
    private void setSearchMode(boolean on) {
        top.setVisibility(on ? View.GONE : View.VISIBLE);
        searchRow.setVisibility(on ? View.VISIBLE : View.GONE);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (on) {
            searchBox.requestFocus();
            if (imm != null) imm.showSoftInput(searchBox, 0);
        } else if (imm != null) {
            imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        }
    }

    private void switchTab(String t) {
        if (t.equals(tab) && searchQuery == null && adapter.data.size() > 0 && !t.equals("profile")) {
            recycler.smoothScrollToPosition(0);
            return;
        }
        saveState();
        feedPlayer.stop();
        tab = t;
                setSearchMode(t.equals("home") && searchQuery != null && searchRow.getVisibility() == View.VISIBLE);
        chipScroll.setVisibility(t.equals("home") ? View.VISIBLE : View.GONE);
        updateNav();
        switch (t) {
            case "subs": loadSubs(); break;
            case "history": loadHistory(); break;
            case "profile": showProfile(); break;
            default: loadHome(); break;
        }
    }

    // ------------------------------------------------------------------ feed adapter

    private final class FeedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        final List<JSONObject> data = new ArrayList<>();
        boolean skeleton = false, footer = false;

        @Override public int getItemCount() { return skeleton ? 4 : data.size() + (footer ? 1 : 0); }

        @Override public int getItemViewType(int p) {
            if (skeleton) return 0;
            return p < data.size() ? 1 : 2;
        }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) {
            View v;
            if (type == 1) v = new VideoCardView(MainActivity.this, true);
            else if (type == 0) v = skeletonView();
            else v = footerView();
            v.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
            int type = getItemViewType(pos);
            if (type == 1) {
                feedPlayer.stopIfHost((VideoCardView) h.itemView);
                ((VideoCardView) h.itemView).bind(data.get(pos), MainActivity.this);
            } else if (type == 0) {
                ObjectAnimator a = ObjectAnimator.ofFloat(h.itemView, "alpha", 0.45f, 1f);
                a.setDuration(750);
                a.setRepeatCount(ValueAnimator.INFINITE);
                a.setRepeatMode(ValueAnimator.REVERSE);
                a.start();
                h.itemView.setTag(a);
            }
        }

        @Override public void onViewDetachedFromWindow(RecyclerView.ViewHolder h) {
            if (h.itemView instanceof VideoCardView) feedPlayer.stopIfHost((VideoCardView) h.itemView);
            Object t = h.itemView.getTag();
            if (t instanceof ObjectAnimator) {
                ((ObjectAnimator) t).cancel();
                h.itemView.setAlpha(1f);
                h.itemView.setTag(null);
            }
        }

        void clear() { data.clear(); skeleton = false; footer = false; notifyDataSetChanged(); }

        void showSkeleton() { data.clear(); footer = false; skeleton = true; notifyDataSetChanged(); }

        void addAll(List<JSONObject> add) {
            if (add.isEmpty()) return;
            if (skeleton) {
                skeleton = false;
                data.addAll(add);
                notifyDataSetChanged();
            } else {
                int start = data.size();
                data.addAll(add);
                notifyItemRangeInserted(start, add.size());
            }
            scheduleAutoplay(150);
        }

        void setFooter(boolean f) {
            if (skeleton || footer == f) return;
            footer = f;
            if (f) notifyItemInserted(data.size()); else notifyItemRemoved(data.size());
        }
    }

    private View skeletonView() {
        int m = Ui.dp(12);
        int w = Math.min(getResources().getDisplayMetrics().widthPixels, Ui.dp(640)) - 2 * m;
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(m, Ui.dp(8), m, Ui.dp(10));
        View t = new View(this);
        t.setBackground(Ui.rect(Ui.surface2, 14));
        c.addView(t, new LinearLayout.LayoutParams(-1, w * 9 / 16));
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, Ui.dp(12), 0, 0);
        View av = new View(this);
        av.setBackground(Ui.oval(Ui.surface2));
        row.addView(av, new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(12), 0, 0, 0);
        View l1 = new View(this);
        l1.setBackground(Ui.rect(Ui.surface2, 6));
        col.addView(l1, new LinearLayout.LayoutParams(-1, Ui.dp(14)));
        View l2 = new View(this);
        l2.setBackground(Ui.rect(Ui.surface2, 6));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(w * 6 / 10, Ui.dp(12));
        p2.topMargin = Ui.dp(8);
        col.addView(l2, p2);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(row);
        return c;
    }

    private View footerView() {
        FrameLayout f = new FrameLayout(this);
        f.setPadding(0, Ui.dp(16), 0, Ui.dp(24));
        ProgressBar pb = new ProgressBar(this);
        pb.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
        f.addView(pb, new FrameLayout.LayoutParams(Ui.dp(28), Ui.dp(28), Gravity.CENTER));
        return f;
    }

    // ------------------------------------------------------------------ feed loading

    private void resetFeed() {
        gen++;
        adapter.clear();
        seen.clear();
        nextTok = null;
        lastTok = null;
        lastError = null;
        loadingMore = false;
        showingCache = false;
        prefetch = false;
        pending = 0;
        topicIndex = 0;
        emptyView.setVisibility(View.GONE);
        profileScroll.setVisibility(View.GONE);
        swipe.setVisibility(View.VISIBLE);
        status.setVisibility(View.VISIBLE);
        status.setOnClickListener(null);
        recycler.scrollToPosition(0);
    }

    private String nextTopic() {
        int n = TOPICS.length;
        String t = TOPICS[topicIndex % n] + TOPIC_SUFFIX[(topicIndex / n) % TOPIC_SUFFIX.length];
        topicIndex++;
        return t;
    }

    private void loadHome() {
        tab = "home";
        searchQuery = null;
        resetFeed();
        status.setText("Recommended for you");
        holdHome = false;
        heldRecs.clear();
        heldSubs.clear();
        if (!manualRefresh && restoreState("home")) return;
        if (manualRefresh) {
            topicIndex = new java.util.Random().nextInt(TOPICS.length);
            manualRefresh = false;
            adapter.showSkeleton();
        } else if (!showCachedHome()) adapter.showSkeleton();
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        for (int k = 0; k < 4; k++) {
            final String q = nextTopic();
            jobs.add(() -> Yt.search(q, null));
        }
        homeRecJobs = jobs.size();
        // mix in the newest videos from channels the user subscribes to
        heldRecs.clear();
        heldSubs.clear();
        holdHome = false;
        if (Auth.signedIn(this)) {
            JSONArray subs = readSubs();
            List<String> ids = new ArrayList<>();
            for (int i = 0; i < subs.length(); i++) {
                JSONObject o = subs.optJSONObject(i);
                if (o != null && !o.optString("id", "").isEmpty()) ids.add(o.optString("id"));
            }
            Collections.shuffle(ids);
            for (int i = 0; i < ids.size() && i < 12; i++) {
                final String id = ids.get(i);
                jobs.add(() -> Yt.rss(id));
            }
            holdHome = jobs.size() > homeRecJobs;
        }
        runJobs(jobs, -1);
    }

    /** Interleaves subscribed-channel videos into the recommended list (about 1 in every 3). */
    private void releaseHome() {
        holdHome = false;
        Collections.sort(heldSubs, (a, b) -> Long.compare(b.optLong("uploaded", 0), a.optLong("uploaded", 0)));
        List<JSONObject> subs = Yt.playable(toArray(heldSubs), seen);
        List<JSONObject> recs = Yt.playable(toArray(heldRecs), seen);
        if (subs.size() > 14) subs = new ArrayList<>(subs.subList(0, 14));
        List<JSONObject> out = new ArrayList<>();
        int si = 0;
        for (int i = 0; i < recs.size(); i++) {
            out.add(recs.get(i));
            if (i % 3 == 1 && si < subs.size()) out.add(subs.get(si++));
        }
        while (si < subs.size()) out.add(subs.get(si++));
        heldRecs.clear();
        heldSubs.clear();
        if (!out.isEmpty() && showingCache) {
            if (isAtTop()) { adapter.clear(); showingCache = false; adapter.addAll(out); }
        } else {
            adapter.addAll(out);
        }
    }

    private static JSONArray toArray(List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        return a;
    }

    private boolean isAtTop() {
        if (lm.findFirstVisibleItemPosition() > 0) return false;
        View v = lm.findViewByPosition(0);
        return v == null || v.getTop() >= -Ui.dp(8);
    }

    private void startSearch(final String q) {
        if (searchQuery == null) saveState();
        tab = "home";
        searchQuery = q;
        resetFeed();
        status.setText("Results for “" + q + "”  ·  tap to clear");
        status.setOnClickListener(v -> {
            setSearchMode(false);
            searchBox.setText("");
            chip = "All";
            updateChips();
            loadHome();
        });
        adapter.showSkeleton();
        prefetch = true;
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        jobs.add(() -> Yt.search(q, null));
        runJobs(jobs, 0);
    }

    private void doSearch() {
        String q = searchBox.getText().toString().trim();
        if (q.isEmpty()) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        chip = "";
        updateChips();
        startSearch(q);
    }

    private void loadMore() {
        if (loadingMore || adapter.skeleton || adapter.data.isEmpty()) return;
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        int tokenJob = -1;
        if (tab.equals("home") && searchQuery == null) {
            for (int k = 0; k < 2; k++) {
                final String q = nextTopic();
                jobs.add(() -> Yt.search(q, null));
            }
        } else if (tab.equals("home")) {
            if (nextTok == null || searchQuery == null) return;
            final String q = searchQuery;
            final Object t = nextTok;
            lastTok = t;
            nextTok = null;
            jobs.add(() -> Yt.searchMore(q, t));
            tokenJob = 0;
        } else {
            return;
        }
        loadingMore = true;
        adapter.setFooter(true);
        runJobs(jobs, tokenJob);
    }

    private void runJobs(final List<Callable<Yt.Page>> jobs, final int tokenJob) {
        final int g = gen;
        pending = jobs.size();
        for (int i = 0; i < jobs.size(); i++) {
            final int idx = i;
            final Callable<Yt.Page> job = jobs.get(i);
            pool.execute(() -> {
                Yt.Page p = null;
                String err = null;
                try { p = job.call(); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
                final Yt.Page fp = p;
                final String fe = err;
                runOnUiThread(() -> onJobDone(g, idx, idx == tokenJob, fp, fe));
            });
        }
    }

    private void onJobDone(int g, int idx, boolean isTokenJob, Yt.Page p, String err) {
        if (g != gen) return;
        if (holdHome) {
            if (p != null) {
                for (int i = 0; i < p.items.length(); i++) {
                    JSONObject o = p.items.optJSONObject(i);
                    if (o != null) (idx >= homeRecJobs ? heldSubs : heldRecs).add(o);
                }
            } else if (idx < homeRecJobs) {
                lastError = err;
            }
            pending--;
            if (pending <= 0) { releaseHome(); jobsFinished(); }
            return;
        }
        if (p != null) {
            List<JSONObject> fresh = Yt.playable(p.items, showingCache ? new HashSet<String>() : seen);
            if (showingCache && !fresh.isEmpty()) {
                // saved feed is on screen: only swap in the fresh one if the user hasn't scrolled away
                if (isAtTop()) {
                    adapter.clear();
                    seen.clear();
                    showingCache = false;
                    adapter.addAll(Yt.playable(p.items, seen));
                }
            } else {
                adapter.addAll(fresh);
            }
            if (isTokenJob) nextTok = p.next;
        } else {
            lastError = err;
            if (isTokenJob) nextTok = lastTok;
        }
        pending--;
        if (pending <= 0) jobsFinished();
    }

    private void jobsFinished() {
        loadingMore = false;
        adapter.setFooter(false);
        if (tab.equals("subs")) {
            Collections.sort(adapter.data, (a, b) -> Long.compare(b.optLong("uploaded", 0), a.optLong("uploaded", 0)));
            adapter.notifyDataSetChanged();
        }
        if (adapter.data.isEmpty()) {
            showEmpty("Couldn't load videos",
                (lastError == null ? "Please check your internet connection." : lastError)
                    + "\n\nCheck your connection and try again.",
                "Try again", this::reloadCurrent);
            return;
        }
        if (tab.equals("home") && searchQuery == null && !showingCache) cacheHome();
        if (!warmed && !showingCache && !adapter.data.isEmpty()) {
            warmed = true;
            final String wid = Yt.videoId(adapter.data.get(0).optString("url", ""));
            if (!wid.isEmpty()) pool.execute(() -> Yt.warm(wid));
        }
        if (prefetch) {
            prefetch = false;
            if (nextTok != null) { loadMore(); return; }
        }
        recycler.post(() -> {
            if (!adapter.skeleton && lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 3) loadMore();
        });
    }

    private void reloadCurrent() {
        states.remove(tab);
        if (tab.equals("home") && searchQuery != null) startSearch(searchQuery);
        else if (tab.equals("subs")) loadSubs();
        else if (tab.equals("history")) loadHistory();
        else loadHome();
    }

    private void showEmpty(String title, String detail, String button, final Runnable action) {
        adapter.clear();
        emptyView.removeAllViews();
        TextView h = Ui.text(this, title, 18, true, Ui.fg);
        h.setGravity(Gravity.CENTER);
        emptyView.addView(h);
        TextView d = Ui.text(this, detail, 13, false, Ui.muted);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, Ui.dp(10), 0, Ui.dp(18));
        emptyView.addView(d);
        if (button != null && action != null) {
            TextView b = Ui.text(this, button, 14, true, Ui.onAccent);
            b.setGravity(Gravity.CENTER);
            b.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
            b.setBackground(Ui.gradient(24));
            b.setOnClickListener(v -> action.run());
            emptyView.addView(b, new LinearLayout.LayoutParams(-2, -2));
        }
        swipe.setVisibility(View.GONE);
        emptyView.setVisibility(View.VISIBLE);
    }

    private boolean showCachedHome() {
        String s = prefs.getString("home_cache", "");
        if (s.isEmpty()) return false;
        try {
            List<JSONObject> l = Yt.playable(new JSONArray(s), seen);
            if (l.isEmpty()) return false;
            adapter.addAll(l);
            showingCache = true;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void cacheHome() {
        try {
            JSONArray a = new JSONArray();
            for (int i = 0; i < adapter.data.size() && i < 40; i++) a.put(adapter.data.get(i));
            prefs.edit().putString("home_cache", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void loadHistory() {
        tab = "history";
        searchQuery = null;
        resetFeed();
        try {
            JSONArray items = new JSONArray(prefs.getString("watch_history", "[]"));
            status.setText(items.length() + " recently watched");
            if (items.length() == 0) {
                showEmpty("No history yet", "Videos you watch will show up here.", null, null);
                return;
            }
            List<JSONObject> l = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o != null) l.add(o);
            }
            adapter.addAll(l);
        } catch (Exception e) {
            showEmpty("Could not read history", String.valueOf(e.getMessage()), null, null);
        }
    }

    private void loadSubs() {
        tab = "subs";
        searchQuery = null;
        resetFeed();
        status.setText("Latest from your subscriptions");
        if (restoreState("subs")) return;
        if (!Auth.signedIn(this)) {
            showEmpty("Sign in to see subscriptions",
                "Sign in with your Google account to see new videos from the channels you follow.",
                "Sign in with Google", this::signIn);
            return;
        }
        JSONArray subs = readSubs();
        adapter.showSkeleton();
        if (subs.length() == 0) { fetchSubscriptions(true); return; }
        List<Callable<Yt.Page>> jobs = new ArrayList<>();
        for (int i = 0; i < subs.length() && i < 40; i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s == null) continue;
            final String id = s.optString("id", "");
            if (id.isEmpty()) continue;
            jobs.add(() -> Yt.rss(id));
        }
        if (jobs.isEmpty()) {
            showEmpty("No subscriptions found", "Subscribe to some channels first.", null, null);
            return;
        }
        status.setText("Latest from " + subs.length() + " subscribed channels");
        runJobs(jobs, -1);
    }

    private JSONArray readSubs() {
        try { return new JSONArray(prefs.getString("subs", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    @Override public void onOpen(String id, String title, String author, String thumb, String avatar, boolean audio) {
        if (id == null || id.isEmpty()) {
            Toast.makeText(this, "Video unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        feedPlayer.stop();
        Ui.saveHistory(this, id, title, author, thumb);
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", title);
        in.putExtra("uploader", author);
        in.putExtra("thumbnail", thumb);
        in.putExtra("avatar", avatar);
        if (audio) in.putExtra("start_audio", true);
        startActivity(in);
    }

    // ------------------------------------------------------------------ account (WebView login, no Play services)

    private void signIn() {
        startActivityForResult(new Intent(this, LoginActivity.class), RC_LOGIN);
    }

    private void signOut() {
        Auth.signOut(this);
        states.clear();
        Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show();
        if (tab.equals("profile")) showProfile();
        else if (tab.equals("subs")) loadSubs();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOGIN && res == RESULT_OK) {
            String n = prefs.getString("acct_name", "");
            Toast.makeText(this, n.isEmpty() ? "Signed in" : "Welcome, " + n, Toast.LENGTH_SHORT).show();
            states.clear();
                if (tab.equals("profile")) showProfile();
            else if (tab.equals("subs")) loadSubs();
        }
    }

    /** Keeps the subscription list / profile fresh (at most every 6 hours). */
    private void refreshAccountInBackground() {
        if (!Auth.signedIn(this)) return;
        if (System.currentTimeMillis() - prefs.getLong("subs_time", 0) < 6L * 3600 * 1000) return;
        pool.execute(() -> {
            Auth.refreshAccount(this);
            try { Auth.refreshSubscriptions(this); } catch (Exception ignored) { }
            runOnUiThread(() -> { if (tab.equals("profile")) showProfile(); });
        });
    }

    private void fetchSubscriptions(final boolean thenLoadFeed) {
        if (!Auth.signedIn(this)) return;
        pool.execute(() -> {
            try {
                Auth.refreshSubscriptions(this);
                runOnUiThread(() -> {
                    if (tab.equals("profile")) showProfile();
                    if (thenLoadFeed && tab.equals("subs")) { states.remove("subs"); loadSubs(); }
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (tab.equals("subs")) {
                        showEmpty("Couldn't load subscriptions", String.valueOf(e.getMessage()),
                            "Try again", () -> loadSubs());
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------ profile screen

    private AlertDialog.Builder dlg() {
        return new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK
            : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
    }

    private View avatar(int size) {
        String name = prefs.getString("acct_name", "");
        String photo = prefs.getString("acct_photo", "");
        boolean in = Auth.signedIn(this);
        FrameLayout ring = new FrameLayout(this);
        ring.setBackground(Ui.gradientOval());
        if (in && !photo.isEmpty()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(size - 4), Ui.dp(size - 4));
            p.gravity = Gravity.CENTER;
            ring.addView(iv, p);
            Glide.with(getApplicationContext()).load(photo).override(Ui.dp(size), Ui.dp(size)).circleCrop().into(iv);
        } else if (in && !name.isEmpty()) {
            TextView tv = Ui.text(this, name.substring(0, 1).toUpperCase(), size / 2.4f, true, 0xFFFFFFFF);
            tv.setGravity(Gravity.CENTER);
            ring.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            ImageView iv = Ui.icon(this, R.drawable.ic_profile, 0xFFFFFFFF, size / 2f);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(size / 2f), Ui.dp(size / 2f));
            p.gravity = Gravity.CENTER;
            ring.addView(iv, p);
        }
        return ring;
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        attachMini();
        scheduleAutoplay(150);
    }

    @Override protected void onPause() {
        resumed = false;
        recycler.removeCallbacks(autoplayRun);
        feedPlayer.release();
        detachMini();
        super.onPause();
    }

    // ------------------------------------------------------------------ inline autoplay + feed buttons

    private void scheduleAutoplay(long delay) {
        if (recycler == null) return;
        recycler.removeCallbacks(autoplayRun);
        recycler.postDelayed(autoplayRun, delay);
    }

    private boolean autoplayAllowed() {
        String mode = prefs.getString("feed_autoplay", "always");
        if (mode.equals("off")) return false;
        if (!(tab.equals("home") || tab.equals("subs"))) return false;
        if (adapter == null || adapter.skeleton || adapter.data.isEmpty()) return false;
        if (profileScroll.getVisibility() == View.VISIBLE) return false;
        ExoPlayer e = PlaybackService.exo;
        if (e != null && e.getPlayWhenReady() && e.getPlaybackState() != Player.STATE_IDLE
                && e.getPlaybackState() != Player.STATE_ENDED) return false;   // something else is already playing
        if (mode.equals("wifi")) {
            android.net.ConnectivityManager cm =
                (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null || cm.isActiveNetworkMetered()) return false;
        }
        return true;
    }

    /** Plays the video card that is most visible (at least 60% on screen); stops when none qualifies. */
    private void updateAutoplay() {
        if (!resumed) { feedPlayer.stop(); return; }
        int first = lm.findFirstVisibleItemPosition(), last = lm.findLastVisibleItemPosition();
        if (first >= 0) prefetchAhead(last);
        // a video the person started by tapping keeps playing while it is still mostly on screen
        VideoCardView held = feedPlayer.host();
        if (feedPlayer.isManual() && held != null) {
            int[] hb = held.visibleBox();
            if (hb != null && hb[0] >= 35) return;
        }
        if (!autoplayAllowed()) { feedPlayer.stop(); return; }
        if (first < 0) return;
        android.graphics.Rect rr = new android.graphics.Rect();
        if (!recycler.getGlobalVisibleRect(rr)) return;
        int mid = (rr.top + rr.bottom) / 2;
        VideoCardView best = null;
        int bestDist = Integer.MAX_VALUE;
        for (int p = first; p <= last; p++) {
            View v = lm.findViewByPosition(p);
            if (!(v instanceof VideoCardView)) continue;
            VideoCardView c = (VideoCardView) v;
            if (!c.canAutoplay()) continue;
            int[] vb = c.visibleBox();
            if (vb == null || vb[0] < 50) continue;
            int dist = Math.abs(vb[1] - mid);
            if (dist < bestDist) { bestDist = dist; best = c; }
        }
        if (best == null) { feedPlayer.stop(); return; }
        feedPlayer.play(best, best.videoId());
    }

    /** Warms the stream data of the next few videos so they start instantly when they scroll into view. */
    private void prefetchAhead(int lastVisible) {
        if (adapter == null || adapter.skeleton) return;
        for (int p = Math.max(0, lastVisible - 1); p <= lastVisible + 3 && p < adapter.data.size(); p++) {
            feedPlayer.prefetch(Yt.videoId(adapter.data.get(p).optString("url", "")));
        }
    }

    @Override public void onVideoTap(VideoCardView card, String id) {
        if (card == feedPlayer.host()) feedPlayer.togglePause();
        else feedPlayer.playManual(card, id);
    }

    @Override public void onSeekBy(long deltaMs) { feedPlayer.seekBy(deltaMs); }

    @Override public void onSeekTo(float fraction) { feedPlayer.seekToFraction(fraction); }

    @Override public void onChannel(String channelId, String name, String avatar) {
        feedPlayer.stop();
        Intent in = new Intent(this, ChannelActivity.class);
        in.putExtra("channel_id", channelId);
        in.putExtra("name", name);
        in.putExtra("avatar", avatar);
        startActivity(in);
    }

    @Override public void onComment(String id) {
        CommentSheet.show(this, id, this::needLoginDialog);
    }

    /** Background button on a card: only the sound plays and the video page is NOT opened. */
    @Override public void onBackground(String id, String title, String author, String thumb, String avatar) {
        if (id == null || id.isEmpty()) {
            Toast.makeText(this, "Video unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        // continue from the second the video on the card has reached
        long pos = id.equals(feedPlayer.currentId()) ? feedPlayer.position() : 0;
        feedPlayer.stop();
        Ui.saveHistory(this, id, title, author, thumb);
        Toast.makeText(this, "Playing in background", Toast.LENGTH_SHORT).show();
        BgPlayer.start(this, id, title, author, thumb, avatar, pos, () -> { if (resumed) attachMini(); });
    }

    /** Full-screen button on the video: landscape player, continuing from the same second and quality. */
    @Override public void onFullscreen(String id, String title, String author, String thumb, String avatar) {
        if (id == null || id.isEmpty()) return;
        long pos = id.equals(feedPlayer.currentId()) ? feedPlayer.position() : 0;
        int q = id.equals(feedPlayer.currentId()) ? feedPlayer.quality() : 0;
        feedPlayer.stop();
        Ui.saveHistory(this, id, title, author, thumb);
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", title);
        in.putExtra("uploader", author);
        in.putExtra("thumbnail", thumb);
        in.putExtra("avatar", avatar);
        in.putExtra("start_full", true);
        in.putExtra("start_pos", pos);
        if (q > 0) in.putExtra("quality", String.valueOf(q));
        startActivity(in);
    }

    @Override public void onQuality(VideoCardView card, String id, int height) {
        feedPlayer.setQuality(card, id, height);
    }

    @Override public int currentQuality(String id) {
        return id != null && id.equals(feedPlayer.currentId()) ? feedPlayer.quality() : 0;
    }

    @Override public void onDownload(String id, String title) {
        Downloads.start(this, id, title);
    }

    @Override public void onNeedLogin() { needLoginDialog(); }

    @Override public void onMuteToggle() { feedPlayer.toggleMute(); }

    private void needLoginDialog() {
        dlg().setTitle("Sign in required")
            .setMessage("Sign in with your Google account to like, comment, subscribe and save videos.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Sign in", (d, w) -> signIn())
            .show();
    }

    // ------------------------------------------------------------------ mini player

    private FrameLayout.LayoutParams miniLp;

    private void buildMini() {
        int sw = getResources().getDisplayMetrics().widthPixels;
        miniW = Math.min(sw, Ui.dp(640)) / 2;
        int mh = miniW * 9 / 16;
        miniBox = new FrameLayout(this);
        miniBox.setBackgroundColor(0xFF000000);
        miniBox.setElevation(Ui.dp(10));
        miniBox.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(10)); }
        });
        miniBox.setClipToOutline(true);
        miniThumb = new ImageView(this);
        miniThumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        miniBox.addView(miniThumb, new FrameLayout.LayoutParams(-1, -1));
        miniPlayer = new PlayerView(this);
        miniPlayer.setUseController(false);
        miniPlayer.setShutterBackgroundColor(Color.TRANSPARENT);
        miniBox.addView(miniPlayer, new FrameLayout.LayoutParams(-1, -1));
        // audio-only (background play): sound bars on the dimmed thumbnail instead of a black video surface
        miniEq = new EqualizerView(this);
        miniEq.setVisibility(View.GONE);
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(Ui.dp(26), Ui.dp(22), Gravity.CENTER);
        miniBox.addView(miniEq, ep);
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        miniBox.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy, sx, sy;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = v.getTranslationX() - e.getRawX();
                        dy = v.getTranslationY() - e.getRawY();
                        sx = e.getRawX(); sy = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!moved && Math.hypot(e.getRawX() - sx, e.getRawY() - sy) > slop) {
                            moved = true;
                            v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (moved) moveMini(e.getRawX() + dx, e.getRawY() + dy);
                        return true;
                    case MotionEvent.ACTION_UP:
                        // a tap does nothing: the video page is not opened (use the buttons)
                        return true;
                    default:
                        return true;
                }
            }
        });

        miniPlayBtn = Ui.icon(this, R.drawable.ic_pause, 0xFFFFFFFF, 26);
        miniPlayBtn.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        miniPlayBtn.setBackground(Ui.oval(0x66000000));
        miniPlayBtn.setOnClickListener(v -> {
            ExoPlayer e = PlaybackService.exo;
            if (e == null) return;
            if (e.getPlaybackState() == Player.STATE_ENDED) { e.seekTo(0); e.play(); }
            else if (e.getPlayWhenReady()) e.pause();
            else e.play();
        });
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(Ui.dp(38), Ui.dp(38), Gravity.CENTER_VERTICAL | Gravity.START);
        pp.leftMargin = Ui.dp(8);
        miniBox.addView(miniPlayBtn, pp);

        ImageView close = Ui.icon(this, R.drawable.ic_close, 0xFFFFFFFF, 24);
        close.setPadding(Ui.dp(7), Ui.dp(7), Ui.dp(7), Ui.dp(7));
        close.setBackground(Ui.oval(0x66000000));
        close.setContentDescription("Close");
        close.setOnClickListener(v -> closeMini(true));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(Ui.dp(38), Ui.dp(38), Gravity.CENTER_VERTICAL | Gravity.END);
        cp.rightMargin = Ui.dp(8);
        miniBox.addView(close, cp);

        miniProg = new View(this);
        miniProg.setBackgroundColor(0xFFFF0000);
        miniBox.addView(miniProg, new FrameLayout.LayoutParams(0, Ui.dp(3), Gravity.BOTTOM | Gravity.START));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(miniW, mh, Gravity.BOTTOM | Gravity.END);
        lp.setMargins(0, 0, Ui.dp(10), Ui.dp(84));
        miniBox.setVisibility(View.GONE);
        miniLp = lp;
    }

    /** Keeps the mini player anywhere on screen (inside the system bars). */
    private void moveMini(float tx, float ty) {
        View parent = (View) miniBox.getParent();
        if (parent == null) return;
        int mr = miniLp.rightMargin, mb = miniLp.bottomMargin;
        float baseLeft = parent.getWidth() - miniBox.getWidth() - mr;
        float baseTop = parent.getHeight() - miniBox.getHeight() - mb;
        float minX = -baseLeft + Ui.dp(4), maxX = mr - Ui.dp(4);
        float minY = -baseTop + root.getPaddingTop() + Ui.dp(4), maxY = mb - root.getPaddingBottom() - Ui.dp(4);
        miniBox.setTranslationX(Math.max(minX, Math.min(maxX, tx)));
        miniBox.setTranslationY(Math.max(minY, Math.min(maxY, ty)));
    }

    private void attachMini() {
        ExoPlayer e = PlaybackService.exo;
        if (e == null || PlaybackService.curId == null) { miniBox.setVisibility(View.GONE); return; }
        int st = e.getPlaybackState();
        if (st == Player.STATE_IDLE || st == Player.STATE_ENDED) {
            miniBox.setVisibility(View.GONE);
            if (st == Player.STATE_ENDED) PlaybackService.clearCurrent();
            return;
        }
        miniPlayer.setPlayer(e);
        boolean audioOnly = PlaybackService.curAudio;
        miniPlayer.setVisibility(audioOnly ? View.GONE : View.VISIBLE);
        miniEq.setVisibility(audioOnly ? View.VISIBLE : View.GONE);
        if (audioOnly) miniThumb.setColorFilter(0xAA000000, android.graphics.PorterDuff.Mode.SRC_ATOP);
        else miniThumb.clearColorFilter();
        e.removeListener(miniListener);
        e.addListener(miniListener);
        String th = PlaybackService.curThumb;
        if (th != null && !th.isEmpty()) Glide.with(this).load(th).centerCrop().into(miniThumb);
        miniBox.setVisibility(View.VISIBLE);
        updateMini();
        miniBox.removeCallbacks(miniTick);
        miniBox.post(miniTick);
    }

    private void detachMini() {
        miniBox.removeCallbacks(miniTick);
        ExoPlayer e = PlaybackService.exo;
        if (e != null) e.removeListener(miniListener);
        miniPlayer.setPlayer(null);
    }

    private void updateMini() {
        ExoPlayer e = PlaybackService.exo;
        if (e == null) { miniBox.setVisibility(View.GONE); return; }
        int st = e.getPlaybackState();
        if (st == Player.STATE_ENDED) { closeMini(false); return; }
        boolean playing = e.getPlayWhenReady() && st != Player.STATE_IDLE;
        miniPlayBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        miniEq.setPlaying(playing && st == Player.STATE_READY);
    }

    private void closeMini(boolean resumeVideo) {
        detachMini();
        ExoPlayer e = PlaybackService.exo;
        final String bgId = PlaybackService.curId;
        final boolean wasBg = PlaybackService.curAudio;
        final long bgPos = e == null ? 0 : Math.max(0, e.getCurrentPosition());
        if (e != null) { e.stop(); e.clearMediaItems(); }
        PlaybackService.clearCurrent();
        miniBox.setVisibility(View.GONE);
        try { stopService(new Intent(this, PlaybackService.class)); } catch (Exception ignored) { }
        if (resumeVideo && wasBg && bgId != null) resumeFeedVideo(bgId, bgPos);
    }

    /** Background play was switched off: the video continues in its card from where the sound stopped. */
    private void resumeFeedVideo(final String id, final long pos) {
        if (recycler == null || lm == null || !resumed) return;
        recycler.post(new Runnable() {
            @Override public void run() {
                if (adapter == null || adapter.skeleton) return;
                int first = lm.findFirstVisibleItemPosition(), last = lm.findLastVisibleItemPosition();
                for (int p = first; p >= 0 && p <= last; p++) {
                    View v = lm.findViewByPosition(p);
                    if (!(v instanceof VideoCardView)) continue;
                    VideoCardView c = (VideoCardView) v;
                    if (id.equals(c.videoId())) {
                        feedPlayer.playManualFrom(c, id, pos);
                        return;
                    }
                }
            }
        });
    }

    private void expandMini() {
        String id = PlaybackService.curId;
        if (id == null) return;
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", PlaybackService.curTitle);
        in.putExtra("uploader", PlaybackService.curUploader);
        in.putExtra("thumbnail", PlaybackService.curThumb);
        in.putExtra("avatar", PlaybackService.curAvatar);
        in.putExtra("resume", true);
        if (PlaybackService.curAudio) in.putExtra("start_audio", true);
        startActivity(in);
    }

    private void showProfile() {
        tab = "profile";
        gen++;
        searchQuery = null;
        swipe.setVisibility(View.GONE);
        emptyView.setVisibility(View.GONE);
        status.setVisibility(View.GONE);
        profileScroll.setVisibility(View.VISIBLE);
        profileScroll.removeAllViews();
        profileScroll.addView(buildProfile());
        updateNav();
    }

    private LinearLayout group() {
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(Ui.outline(Ui.surface, Ui.line, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = Ui.dp(18);
        g.setLayoutParams(p);
        return g;
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s.toUpperCase(), 11.5f, true, Ui.muted);
        t.setLetterSpacing(0.1f);
        t.setPadding(Ui.dp(6), Ui.dp(4), 0, Ui.dp(8));
        return t;
    }

    private void addRow(LinearLayout g, String title, String sub, View trailing, View.OnClickListener click) {
        if (g.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(Ui.line);
            g.addView(d, new LinearLayout.LayoutParams(-1, 1));
        }
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.addView(Ui.text(this, title, 15, true, Ui.fg));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 12, false, Ui.muted);
            s.setPadding(0, Ui.dp(2), 0, 0);
            c.addView(s);
        }
        r.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        if (trailing != null) {
            ViewGroup.LayoutParams tl = trailing.getLayoutParams();
            r.addView(trailing, tl != null ? tl : new LinearLayout.LayoutParams(-2, -2));
        }
        if (click != null) r.setOnClickListener(click);
        g.addView(r, new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView valueText(String s) {
        return Ui.text(this, s, 13, true, Ui.accentText());
    }

    private View toggle(boolean initial, final BoolCb cb) {
        final FrameLayout track = new FrameLayout(this);
        final View knob = new View(this);
        knob.setBackground(Ui.oval(0xFFFFFFFF));
        final FrameLayout.LayoutParams kp = new FrameLayout.LayoutParams(Ui.dp(20), Ui.dp(20));
        kp.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
        track.addView(knob, kp);
        final boolean[] on = {initial};
        final Runnable[] apply = new Runnable[1];
        apply[0] = () -> {
            track.setBackground(on[0] ? Ui.rect(Ui.link, 14) : Ui.rect(Ui.line, 14));
            kp.gravity = Gravity.CENTER_VERTICAL | (on[0] ? Gravity.END : Gravity.START);
            knob.setLayoutParams(kp);
        };
        apply[0].run();
        track.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(26)));
        track.setOnClickListener(v -> { on[0] = !on[0]; apply[0].run(); cb.on(on[0]); });
        return track;
    }

    private View buildProfile() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(28));

        // account card
        boolean signed = Auth.signedIn(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(20), Ui.dp(26), Ui.dp(20), Ui.dp(22));
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.surface2, Ui.surface});
        gd.setCornerRadius(Ui.dp(24));
        gd.setStroke(Ui.dp(1), Ui.line);
        card.setBackground(gd);
        card.addView(avatar(88), new LinearLayout.LayoutParams(Ui.dp(88), Ui.dp(88)));
        String an = prefs.getString("acct_name", "");
        String name = signed ? (an.isEmpty() ? "Signed in" : an) : "Guest";
        TextView nm = Ui.text(this, name, 20, true, Ui.fg);
        nm.setPadding(0, Ui.dp(12), 0, 0);
        nm.setGravity(Gravity.CENTER);
        card.addView(nm, new LinearLayout.LayoutParams(-1, -2));
        String handle = prefs.getString("acct_handle", "");
        String sub = signed ? (handle.isEmpty() ? "Your YouTube account" : handle)
            : "Sign in to sync your YouTube subscriptions";
        TextView em = Ui.text(this, sub, 13, false, Ui.muted);
        em.setGravity(Gravity.CENTER);
        em.setPadding(0, Ui.dp(2), 0, 0);
        card.addView(em, new LinearLayout.LayoutParams(-1, -2));
        if (signed) {
            int n = readSubs().length();
            if (n > 0) {
                TextView f = Ui.text(this, "Following " + n + " channels", 12, true, Ui.accentText());
                f.setPadding(0, Ui.dp(8), 0, 0);
                f.setGravity(Gravity.CENTER);
                card.addView(f, new LinearLayout.LayoutParams(-1, -2));
            }
        }
        TextView btn = Ui.text(this, signed ? "Sign out" : "Sign in with Google", 14, true,
            signed ? Ui.fg : Ui.onAccent);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
        btn.setBackground(signed ? Ui.outline(Ui.surface, Ui.line, 24) : Ui.gradient(24));
        btn.setOnClickListener(v -> { if (!Auth.signedIn(this)) signIn(); else signOut(); });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = Ui.dp(16);
        card.addView(btn, bp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = Ui.dp(20);
        col.addView(card, cp);

        // customize
        col.addView(sectionTitle("Customize"));
        LinearLayout cg = group();
        final String[][] themes = {{"midnight", "Dark"}, {"amoled", "AMOLED black"}, {"light", "Light"},
            {"system", "Follow system"}};
        String curTheme = prefs.getString("theme2", "midnight");
        String themeName = themes[0][1];
        int themeIdx = 0;
        for (int i = 0; i < themes.length; i++) if (themes[i][0].equals(curTheme)) { themeName = themes[i][1]; themeIdx = i; }
        final int themeChecked = themeIdx;
        addRow(cg, "Theme", "Choose how the app looks", valueText(themeName), v -> {
            String[] names = new String[themes.length];
            for (int i = 0; i < themes.length; i++) names[i] = themes[i][1];
            dlg().setTitle("Theme").setSingleChoiceItems(names, themeChecked, (d, w) -> {
                prefs.edit().putString("theme2", themes[w][0]).putString("restore_tab", "profile").apply();
                d.dismiss();
                recreate();
            }).show();
        });
        String regionName = region();
        int regionIdx = 0;
        for (int i = 0; i < REGIONS.length; i++) if (REGIONS[i][0].equals(regionName)) { regionName = REGIONS[i][1]; regionIdx = i; }
        final int regionChecked = regionIdx;
        addRow(cg, "Home region", "Which country's videos you see", valueText(regionName), v -> {
            String[] names = new String[REGIONS.length];
            for (int i = 0; i < REGIONS.length; i++) names[i] = REGIONS[i][1];
            dlg().setTitle("Home region").setSingleChoiceItems(names, regionChecked, (d, w) -> {
                prefs.edit().putString("region", REGIONS[w][0]).apply();
                states.clear();
                Yt.init(REGIONS[w][0]);
                d.dismiss();
                showProfile();
            }).show();
        });
        col.addView(cg);

        // settings
        col.addView(sectionTitle("Settings"));
        LinearLayout sg = group();
        addRow(sg, "Autoplay next", "Play the first suggested video when one ends",
            toggle(prefs.getBoolean("autoplay", true), v -> prefs.edit().putBoolean("autoplay", v).apply()), null);
        final String[][] feedModes = {{"always", "Always"}, {"wifi", "Wi-Fi only"}, {"off", "Off"}};
        String fmCur = prefs.getString("feed_autoplay", "always");
        String fmName = feedModes[0][1];
        int fmIdx = 0;
        for (int i = 0; i < feedModes.length; i++) if (feedModes[i][0].equals(fmCur)) { fmName = feedModes[i][1]; fmIdx = i; }
        final int fmChecked = fmIdx;
        addRow(sg, "Autoplay in feed", "Videos play (muted) as you scroll, no tap needed", valueText(fmName), v -> {
            String[] names = new String[feedModes.length];
            for (int i = 0; i < feedModes.length; i++) names[i] = feedModes[i][1];
            dlg().setTitle("Autoplay in feed").setSingleChoiceItems(names, fmChecked, (d, w) -> {
                prefs.edit().putString("feed_autoplay", feedModes[w][0]).apply();
                d.dismiss();
                showProfile();
            }).show();
        });
        String q = prefs.getString("quality", "auto");
        String qName = QUALITIES[0][1];
        int qIdx = 0;
        for (int i = 0; i < QUALITIES.length; i++) if (QUALITIES[i][0].equals(q)) { qName = QUALITIES[i][1]; qIdx = i; }
        final int qChecked = qIdx;
        addRow(sg, "Video quality", "Preferred playback quality", valueText(qName), v -> {
            String[] names = new String[QUALITIES.length];
            for (int i = 0; i < QUALITIES.length; i++) names[i] = QUALITIES[i][1];
            dlg().setTitle("Video quality").setSingleChoiceItems(names, qChecked, (d, w) -> {
                prefs.edit().putString("quality", QUALITIES[w][0]).apply();
                d.dismiss();
                showProfile();
            }).show();
        });
        addRow(sg, "Ad block", "No video ads · also skips sponsor & self-promo segments inside videos",
            toggle(prefs.getBoolean("adblock", true), v -> prefs.edit().putBoolean("adblock", v).apply()), null);
        addRow(sg, "Clear watch history", "Removes the list stored on this device", null, v ->
            dlg().setTitle("Clear watch history?").setMessage("This only removes history saved on this device.")
                .setNegativeButton("Cancel", null).setPositiveButton("Clear", (d, w) -> {
                    prefs.edit().remove("watch_history").apply();
                    Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
                }).show());
        addRow(sg, "Clear cache", "Forget the saved home feed", null, v -> {
            prefs.edit().remove("home_cache").apply();
            Glide.get(this).clearMemory();
            Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show();
        });
        col.addView(sg);

        // about
        col.addView(sectionTitle("About"));
        LinearLayout ag = group();
        addRow(ag, "YouTube", "Version 4.8 · native Android", null, null);
        addRow(ag, "How it works", "Videos are read directly on your phone (no middle servers), so they play"
            + " without YouTube's ads. Sign-in uses Google's own login page.", null, null);
        addRow(ag, "Developer", "Manik Mia", null, null);
        col.addView(ag);
        return col;
    }
}
