package com.manik.youtubeweb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import com.bumptech.glide.Glide;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** NativeTube home UI. Built entirely with native Android views; no WebView. */
public class MainActivity extends Activity {
    private LinearLayout root, feed, categoryRow;
    private EditText search;
    private TextView status;
    private SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private boolean dark;
    private int bg, surface, fg, muted, line, accent;
    private String selectedCategory = "All";
    private String currentTab = "Home";

    private String apiBase() {
        return prefs.getString("api", YoutubeApiClient.DEFAULT_BASE);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("native_settings", MODE_PRIVATE);
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 701);
        }
        applyTheme();
        buildHome();
        loadHome();
    }

    private void applyTheme() {
        String theme = prefs.getString("theme", "system");
        dark = theme.equals("dark") || (theme.equals("system") &&
            (getResources().getConfiguration().uiMode & 0x30) == 0x20);
        bg = dark ? Color.rgb(15,15,15) : Color.WHITE;
        surface = dark ? Color.rgb(35,35,35) : Color.rgb(245,245,245);
        fg = dark ? Color.WHITE : Color.rgb(20,20,20);
        muted = dark ? Color.rgb(175,175,175) : Color.rgb(95,95,95);
        line = dark ? Color.rgb(48,48,48) : Color.rgb(225,225,225);
        accent = dark ? Color.rgb(255,65,65) : Color.rgb(210,0,0);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String value, float size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private Button pill(String title, boolean active) {
        Button b = new Button(this); b.setText(title); b.setTextSize(12); b.setAllCaps(false);
        b.setTextColor(active ? (dark ? Color.BLACK : Color.WHITE) : fg);
        b.setBackground(rounded(active ? (dark ? Color.WHITE : Color.BLACK) : surface, 24));
        b.setPadding(dp(14), 0, dp(14), 0); return b;
    }

    private void buildHome() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        root.setPadding(0, dp(4), 0, 0);

        LinearLayout appbar = new LinearLayout(this); appbar.setGravity(Gravity.CENTER_VERTICAL); appbar.setPadding(dp(16), dp(4), dp(12), dp(4));
        TextView logo = label("▶", 25, true, accent); appbar.addView(logo);
        TextView brand = label("NativeTube", 22, true, fg); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(52), 1); bp.leftMargin = dp(8); brand.setGravity(Gravity.CENTER_VERTICAL); appbar.addView(brand, bp);
        TextView cast = label("⌕", 27, false, fg); cast.setGravity(Gravity.CENTER); appbar.addView(cast, new LinearLayout.LayoutParams(dp(42), dp(48)));
        TextView profile = label("●", 24, false, fg); profile.setGravity(Gravity.CENTER); profile.setOnClickListener(v -> openSettings()); appbar.addView(profile, new LinearLayout.LayoutParams(dp(42), dp(48)));
        root.addView(appbar);

        LinearLayout searchRow = new LinearLayout(this); searchRow.setGravity(Gravity.CENTER_VERTICAL); searchRow.setPadding(dp(14), dp(4), dp(14), dp(8));
        search = new EditText(this); search.setSingleLine(true); search.setTextColor(fg); search.setHintTextColor(muted); search.setHint("Search YouTube"); search.setTextSize(15);
        search.setPadding(dp(16), 0, dp(12), 0); search.setBackground(rounded(surface, 28));
        searchRow.addView(search, new LinearLayout.LayoutParams(0, dp(44), 1));
        TextView go = label("⌕", 25, true, fg); go.setGravity(Gravity.CENTER); go.setBackground(rounded(surface, 28));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(48), dp(44)); gp.leftMargin = dp(8); searchRow.addView(go, gp); go.setOnClickListener(v -> doSearch());
        search.setOnEditorActionListener((v, action, event) -> { doSearch(); return true; });
        root.addView(searchRow);

        HorizontalScrollView cats = new HorizontalScrollView(this); cats.setHorizontalScrollBarEnabled(false);
        categoryRow = new LinearLayout(this); categoryRow.setPadding(dp(12), dp(2), dp(12), dp(10)); categoryRow.setGravity(Gravity.CENTER_VERTICAL);
        cats.addView(categoryRow); root.addView(cats); updateCategories();

        status = label("Loading videos…", 12, false, muted); status.setPadding(dp(16), dp(4), dp(16), dp(8)); root.addView(status);
        ScrollView scroller = new ScrollView(this); scroller.setFillViewport(true);
        feed = new LinearLayout(this); feed.setOrientation(LinearLayout.VERTICAL); feed.setPadding(0, 0, 0, dp(10)); scroller.addView(feed);
        root.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4), dp(7), dp(4), dp(7)); nav.setBackgroundColor(bg);
        String[] navLabels = {"⌂\nHome", "🔥\nTrending", "◷\nHistory", "⚙\nSettings"};
        String[] tabs = {"Home", "Trending", "History", "Settings"};
        for (int i=0;i<navLabels.length;i++) {
            final int index=i; boolean selected=currentTab.equals(tabs[i]);
            TextView item=label(navLabels[i], 11, selected, selected?accent:fg); item.setGravity(Gravity.CENTER);
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(52),1));
            item.setOnClickListener(v -> {
                currentTab=tabs[index];
                if(index==0) loadHome();
                else if(index==1) loadTrending();
                else if(index==2) loadHistory();
                else openSettings();
            });
        }
        root.addView(nav); setContentView(root);
    }

    private void updateCategories() {
        categoryRow.removeAllViews();
        String[] cats = {"All", "Music", "Gaming", "News", "Live", "Mixes", "Recently uploaded"};
        for (String c : cats) {
            Button b = pill(c, selectedCategory.equals(c));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(36)); p.rightMargin = dp(7); categoryRow.addView(b,p);
            b.setOnClickListener(v -> { selectedCategory=c; updateCategories(); if(c.equals("All")) loadHome(); else { search.setText(c); doSearch(); } });
        }
    }

    private void loadHome() {
        currentTab="Home"; status.setText("Recommended videos"); feed.removeAllViews(); addLoading();
        io.execute(() -> {
            try { JSONArray items = new YoutubeApiClient(apiBase()).trending("US"); runOnUiThread(() -> renderItems(items, "Home")); }
            catch (Exception e) { runOnUiThread(() -> showError("Could not load recommendations", e.getMessage())); }
        });
    }

    private void loadTrending() {
        currentTab="Trending"; status.setText("Trending videos"); feed.removeAllViews(); addLoading();
        io.execute(() -> {
            try { JSONArray items = new YoutubeApiClient(apiBase()).trending("US"); runOnUiThread(() -> renderItems(items, "Trending")); }
            catch (Exception e) { runOnUiThread(() -> showError("Could not load trending videos", e.getMessage())); }
        });
    }

    private void saveHistory(String id,String title,String author,String thumb) {
        if(id==null || id.isEmpty()) return;
        try {
            JSONArray old=new JSONArray(prefs.getString("watch_history","[]")); JSONArray next=new JSONArray();
            JSONObject entry=new JSONObject(); entry.put("id",id); entry.put("title",title); entry.put("author",author); entry.put("thumb",thumb); entry.put("time",System.currentTimeMillis()); next.put(entry);
            for(int i=0;i<old.length() && next.length()<100;i++) { JSONObject x=old.optJSONObject(i); if(x!=null && !id.equals(x.optString("id"))) next.put(x); }
            prefs.edit().putString("watch_history",next.toString()).apply();
        } catch(Exception ignored) { }
    }

    private void loadHistory() {
        currentTab="History"; feed.removeAllViews();
        try {
            JSONArray items=new JSONArray(prefs.getString("watch_history","[]"));
            status.setText(items.length()+" recently watched videos");
            if(items.length()==0) { showError("Your watch history is empty", "Videos you open will appear here."); return; }
            renderItems(items,"History");
        } catch(Exception e) { showError("Could not read history",e.getMessage()); }
    }

    private void doSearch() {
        String q = search.getText().toString().trim(); if (q.isEmpty()) return;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(), 0);
        status.setText("Search results for “" + q + "”"); feed.removeAllViews(); addLoading();
        io.execute(() -> {
            try { JSONArray items = new YoutubeApiClient(apiBase()).search(q); runOnUiThread(() -> renderItems(items, "Search")); }
            catch (Exception e) { runOnUiThread(() -> showError("Search failed", e.getMessage())); }
        });
    }

    private void addLoading() {
        TextView t=label("Loading videos…",14,false,muted); t.setGravity(Gravity.CENTER); t.setPadding(0,dp(40),0,dp(40)); feed.addView(t);
    }
    private void showError(String title, String detail) {
        feed.removeAllViews(); TextView h=label(title,17,true,fg); h.setGravity(Gravity.CENTER); h.setPadding(dp(20),dp(35),dp(20),dp(8)); feed.addView(h);
        TextView d=label((detail==null?"API unavailable":detail)+"\n\nTry another API instance in Settings.",13,false,muted); d.setGravity(Gravity.CENTER); d.setPadding(dp(24),dp(6),dp(24),dp(20)); feed.addView(d);
        Button retry=pill("Retry",true); feed.addView(retry,new LinearLayout.LayoutParams(-1,dp(44))); retry.setOnClickListener(v -> { if(search.getText().length()>0) doSearch(); else loadHome(); });
    }

    private void renderItems(JSONArray items, String source) {
        feed.removeAllViews();
        if (items == null || items.length()==0) { showError("No videos found", "Try a different search or API instance."); return; }
        status.setText(items.length()+" videos · "+source);
        for (int i=0;i<items.length();i++) {
            JSONObject item=items.optJSONObject(i); if(item==null) continue;
            String title=item.optString("title","Untitled video");
            String url=item.optString("url",item.optString("id","")); String id=YoutubeApiClient.videoId(url);
            String author=item.optString("uploaderName",item.optString("uploader",item.optString("author","YouTube")));
            String thumb=item.optString("thumbnail",item.optString("thumb",""));
            String duration=item.optString("duration","");
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12),dp(8),dp(12),dp(13));
            ImageView image=new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP); image.setBackground(rounded(surface,12));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(194)); card.addView(image,ip);
            if(!thumb.isEmpty()) Glide.with(this).load(thumb).centerCrop().into(image);
            image.setOnClickListener(v -> openVideo(id,title,author,thumb));
            LinearLayout meta=new LinearLayout(this); meta.setGravity(Gravity.TOP|Gravity.CENTER_VERTICAL); meta.setPadding(0,dp(9),0,0);
            TextView avatar=label("●",25,true,accent); avatar.setGravity(Gravity.CENTER); meta.addView(avatar,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(9),0,0,0);
            TextView name=label(title,15,true,fg); name.setMaxLines(2); info.addView(name);
            String views=item.optString("views",""); if(views.equals("-1")||views.equals("null")) views="";
            TextView sub=label(author+(views.isEmpty()?"":"  ·  "+views)+ (duration.isEmpty()?"":"  ·  "+duration),12,false,muted); sub.setPadding(0,dp(4),0,0); info.addView(sub);
            meta.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            TextView more=label("⋮",24,false,fg); more.setGravity(Gravity.CENTER); meta.addView(more,new LinearLayout.LayoutParams(dp(32),dp(42)));
            card.addView(meta);
            LinearLayout actions=new LinearLayout(this); actions.setPadding(dp(48),dp(7),0,0); actions.setGravity(Gravity.CENTER_VERTICAL);
            TextView bgButton=label("♫  Background",11,true,fg); bgButton.setGravity(Gravity.CENTER); bgButton.setBackground(rounded(surface,22)); actions.addView(bgButton,new LinearLayout.LayoutParams(0,dp(36),1));
            TextView open=label("▶  Watch",11,true,fg); open.setGravity(Gravity.CENTER); open.setBackground(rounded(surface,22)); LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,dp(36),1); op.leftMargin=dp(7); actions.addView(open,op);
            bgButton.setOnClickListener(v -> { if(id.isEmpty()) return; if(!prefs.getBoolean("background_play",true)){Toast.makeText(this,"Enable Background Play in Settings",Toast.LENGTH_SHORT).show();return;} saveHistory(id,title,author,thumb); Intent in=playerIntent(id,title,author,thumb);in.putExtra("start_audio",true);startActivity(in); });
            open.setOnClickListener(v -> openVideo(id,title,author,thumb));
            card.addView(actions); card.setOnClickListener(v -> openVideo(id,title,author,thumb)); feed.addView(card);
        }
    }

    private Intent playerIntent(String id,String title,String author,String thumb) { Intent in=new Intent(this,PlayerActivity.class);in.putExtra("video_id",id);in.putExtra("title",title);in.putExtra("uploader",author);in.putExtra("thumbnail",thumb);return in; }
    private void openVideo(String id,String title,String author,String thumb) { if(id==null||id.isEmpty()){Toast.makeText(this,"Video ID unavailable",Toast.LENGTH_SHORT).show();return;} saveHistory(id,title,author,thumb); startActivity(playerIntent(id,title,author,thumb)); }

    private void openSettings() {
        currentTab="Settings";
        String[] options={"Customize","Background Play: "+(prefs.getBoolean("background_play",true)?"ON":"OFF"),"Ad Block (all videos): "+(prefs.getBoolean("adblock",false)?"ON":"OFF"),"API instance","Account / Sign in","About NativeTube"};
        new android.app.AlertDialog.Builder(this).setTitle("Settings").setItems(options,(d,w)->{
            if(w==0) openCustomize();
            else if(w==1){prefs.edit().putBoolean("background_play",!prefs.getBoolean("background_play",true)).apply();openSettings();}
            else if(w==2){boolean enabled=!prefs.getBoolean("adblock",false);prefs.edit().putBoolean("adblock",enabled).apply();Toast.makeText(this,enabled?"Global ad-filter preference enabled. Blocking depends on provider support.":"Global ad-filter preference disabled.",Toast.LENGTH_LONG).show();openSettings();}
            else if(w==3) editApi();
            else if(w==4) new android.app.AlertDialog.Builder(this).setTitle("Account sign-in").setMessage("Google / YouTube sign-in is not included. microG is a separate system component, not a library that can simply be bundled into NativeTube. This build does not yet implement a supported account authentication flow.").setPositiveButton("OK",null).show();
            else new android.app.AlertDialog.Builder(this).setTitle("About NativeTube").setMessage("Native Android video client. Playback and search depend on third-party Piped-compatible public API instances. YouTube account features and guaranteed ad removal are not available in this build.").setPositiveButton("OK",null).show();
        }).show();
    }

    private void openCustomize() {
        String[] options={"Appearance / Theme","Clear watch history"};
        new android.app.AlertDialog.Builder(this).setTitle("Customize").setItems(options,(d,w)->{
            if(w==0){String[] themes={"System default","Light","Dark"};new android.app.AlertDialog.Builder(this).setTitle("App theme").setItems(themes,(x,k)->{prefs.edit().putString("theme",new String[]{"system","light","dark"}[k]).apply();recreate();}).show();}
            else new android.app.AlertDialog.Builder(this).setTitle("Clear watch history?").setMessage("This removes the locally saved watch history from this device.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(x,k)->{prefs.edit().remove("watch_history").apply();Toast.makeText(this,"Watch history cleared",Toast.LENGTH_SHORT).show();}).show();
        }).show();
    }
    private void editApi() {
        EditText e=new EditText(this);e.setSingleLine(true);e.setText(apiBase());
        new android.app.AlertDialog.Builder(this).setTitle("Piped API instance URL").setView(e).setPositiveButton("Save",(d,w)->prefs.edit().putString("api",e.getText().toString().trim()).apply()).setNegativeButton("Cancel",null).show();
    }
    @Override public void onBackPressed() { new android.app.AlertDialog.Builder(this).setTitle("Exit NativeTube?").setMessage("Are you sure you want to close the app?").setNegativeButton("Stay",null).setPositiveButton("Exit",(d,w)->finish()).show(); }
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
