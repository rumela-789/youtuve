package com.manik.youtubeweb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Video / audio player with suggestions, quality picker, fullscreen and autoplay. */
public class PlayerActivity extends Activity implements VideoCardView.Listener {
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private SharedPreferences prefs;
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private boolean pendingStart = false;

    private LinearLayout root, relatedBox;
    private FrameLayout playerBox;
    private PlayerView playerView;
    private ProgressBar spinner;
    private TextView overlayMsg, titleV, metaV, channelV, descV, audioChip, qualityChip;
    private ImageView avatarV;
    private ScrollView scroll;

    private String videoId, title, uploader, thumb;
    private JSONObject streamInfo;
    private int loadGen = 0, portraitH;
    private boolean audioMode, full = false, descExpanded = false;
    private String forcedQuality = null;
    private final List<String[]> candidates = new ArrayList<>();
    private int candIdx = 0;
    private final List<JSONObject> relatedList = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Ui.prefs(this);
        Ui.load(this);
        videoId = getIntent().getStringExtra("video_id");
        title = getIntent().getStringExtra("title");
        uploader = getIntent().getStringExtra("uploader");
        thumb = getIntent().getStringExtra("thumbnail");
        audioMode = getIntent().getBooleanExtra("start_audio", false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        build();
        connectController();
        loadStreams();
    }

    // ------------------------------------------------------------------ layout

    private TextView chip(String label, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 12.5f, true, Ui.fg);
        t.setPadding(Ui.dp(16), Ui.dp(9), Ui.dp(16), Ui.dp(9));
        t.setBackground(Ui.outline(Ui.surface, Ui.line, 20));
        t.setOnClickListener(l);
        return t;
    }

    private void build() {
        portraitH = Math.min(getResources().getDisplayMetrics().widthPixels,
            getResources().getDisplayMetrics().heightPixels) * 9 / 16;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (full) v.setPadding(0, 0, 0, 0);
            else v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        playerBox = new FrameLayout(this);
        playerBox.setBackgroundColor(0xFF000000);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setFullscreenButtonClickListener(isFs -> setFull(!full));
        playerBox.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        spinner = new ProgressBar(this);
        spinner.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
        playerBox.addView(spinner, new FrameLayout.LayoutParams(Ui.dp(40), Ui.dp(40), Gravity.CENTER));
        overlayMsg = Ui.text(this, "", 13, false, 0xFFFFFFFF);
        overlayMsg.setGravity(Gravity.CENTER);
        overlayMsg.setPadding(Ui.dp(24), 0, Ui.dp(24), 0);
        overlayMsg.setVisibility(View.GONE);
        playerBox.addView(overlayMsg, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        root.addView(playerBox, new LinearLayout.LayoutParams(-1, portraitH));

        scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, Ui.dp(20));

        titleV = Ui.text(this, title == null ? "Video" : title, 18, true, Ui.fg);
        titleV.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(2));
        content.addView(titleV);
        metaV = Ui.text(this, "", 12, false, Ui.muted);
        metaV.setPadding(Ui.dp(16), Ui.dp(2), Ui.dp(16), Ui.dp(10));
        content.addView(metaV);

        LinearLayout ch = new LinearLayout(this);
        ch.setGravity(Gravity.CENTER_VERTICAL);
        ch.setPadding(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(12));
        avatarV = new ImageView(this);
        avatarV.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarV.setBackground(Ui.gradientOval());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(40), Ui.dp(40));
        ap.rightMargin = Ui.dp(12);
        ch.addView(avatarV, ap);
        channelV = Ui.text(this, uploader == null ? "" : uploader, 15, true, Ui.fg);
        ch.addView(channelV, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(ch);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(Ui.dp(16), 0, Ui.dp(16), Ui.dp(12));
        audioChip = chip("♫  Audio only", v -> toggleAudio());
        qualityChip = chip("Quality: Auto", v -> pickQuality());
        TextView share = chip("Share", v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, (title == null ? "" : title) + "\nhttps://youtu.be/" + videoId);
            startActivity(Intent.createChooser(i, "Share"));
        });
        for (TextView c : new TextView[]{audioChip, qualityChip, share}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.rightMargin = Ui.dp(8);
            chips.addView(c, p);
        }
        hs.addView(chips);
        content.addView(hs);
        updateChips();

        descV = Ui.text(this, "", 13, false, Ui.fg);
        descV.setMaxLines(3);
        descV.setEllipsize(TextUtils.TruncateAt.END);
        descV.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        descV.setBackground(Ui.rect(Ui.surface, 14));
        descV.setVisibility(View.GONE);
        descV.setOnClickListener(v -> {
            descExpanded = !descExpanded;
            descV.setMaxLines(descExpanded ? 200 : 3);
        });
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(Ui.dp(16), 0, Ui.dp(16), Ui.dp(10));
        content.addView(descV, dp);

        TextView up = Ui.text(this, "Up next", 16, true, Ui.fg);
        up.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(2));
        content.addView(up);
        relatedBox = new LinearLayout(this);
        relatedBox.setOrientation(LinearLayout.VERTICAL);
        content.addView(relatedBox, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        applySystemUi(false);
    }

    private void updateChips() {
        audioChip.setText(audioMode ? "▶  Video" : "♫  Audio only");
        String q = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        String label;
        if (q.equals("auto")) label = "Auto";
        else if (q.equals("adaptive")) label = "Adaptive";
        else label = q + "p";
        qualityChip.setText("Quality: " + label);
        qualityChip.setVisibility(audioMode ? View.GONE : View.VISIBLE);
    }

    // ------------------------------------------------------------------ fullscreen

    private void applySystemUi(boolean f) {
        int flags = 0;
        if (f) {
            flags = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!Ui.dark) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void applyFull(boolean f) {
        full = f;
        scroll.setVisibility(f ? View.GONE : View.VISIBLE);
        ViewGroup.LayoutParams lp = playerBox.getLayoutParams();
        lp.height = f ? ViewGroup.LayoutParams.MATCH_PARENT : portraitH;
        playerBox.setLayoutParams(lp);
        if (f) root.setPadding(0, 0, 0, 0);
        else root.requestApplyInsets();
        applySystemUi(f);
    }

    private void setFull(boolean f) {
        setRequestedOrientation(f ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        applyFull(f);
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        boolean land = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (land != full) applyFull(land);
    }

    @Override public void onBackPressed() {
        if (full) { setFull(false); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ player connection

    private void connectController() {
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                playerView.setPlayer(controller);
                controller.addListener(new Player.Listener() {
                    @Override public void onPlaybackStateChanged(int state) {
                        spinner.setVisibility(state == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                        if (state == Player.STATE_READY) overlayMsg.setVisibility(View.GONE);
                        if (state == Player.STATE_ENDED) playNext();
                    }
                    @Override public void onPlayerError(PlaybackException error) { onPlayError(error); }
                });
                if (pendingStart) { pendingStart = false; startPlayback(0); }
            } catch (Exception e) {
                showMsg("Player service connection failed: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void showMsg(String m) {
        spinner.setVisibility(View.GONE);
        overlayMsg.setText(m);
        overlayMsg.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ loading

    private void loadStreams() {
        final int g = ++loadGen;
        final String vid = videoId;
        streamInfo = null;
        candidates.clear();
        spinner.setVisibility(View.VISIBLE);
        overlayMsg.setVisibility(View.GONE);
        overlayMsg.setOnClickListener(null);
        pool.execute(() -> {
            try {
                final JSONObject d = new YoutubeApiClient(prefs.getString("api_custom", "")).streams(vid);
                runOnUiThread(() -> { if (g == loadGen) onStreams(d); });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (g != loadGen) return;
                    showMsg("Couldn't load this video.\n" + e.getMessage() + "\n\nTap to retry");
                    overlayMsg.setOnClickListener(v -> loadStreams());
                });
            }
        });
    }

    private void onStreams(JSONObject d) {
        streamInfo = d;
        String t = d.optString("title", "");
        if (!t.isEmpty()) { title = t; titleV.setText(t); }
        String up = d.optString("uploader", "");
        if (!up.isEmpty()) { uploader = up; channelV.setText(up); }
        String av = d.optString("uploaderAvatar", "");
        if (!av.isEmpty() && !av.equals("null")) {
            Glide.with(avatarV).load(av).override(96, 96).circleCrop().into(avatarV);
        }
        StringBuilder m = new StringBuilder();
        long views = d.optLong("views", -1);
        if (views >= 0) m.append(Ui.count(views)).append(" views");
        long likes = d.optLong("likes", -1);
        if (likes >= 0) { if (m.length() > 0) m.append("  ·  "); m.append(Ui.count(likes)).append(" likes"); }
        String date = d.optString("uploadDate", "");
        if (!date.isEmpty() && !date.equals("null")) { if (m.length() > 0) m.append("  ·  "); m.append(date); }
        metaV.setText(m.toString());

        String desc = d.optString("description", "");
        if (!desc.isEmpty() && !desc.equals("null")) {
            if (desc.length() > 4000) desc = desc.substring(0, 4000);
            CharSequence cs = Build.VERSION.SDK_INT >= 24 ? Html.fromHtml(desc, 0) : Html.fromHtml(desc);
            descV.setText(cs);
            descV.setVisibility(View.VISIBLE);
        } else {
            descV.setVisibility(View.GONE);
        }

        relatedBox.removeAllViews();
        relatedList.clear();
        JSONArray rel = d.optJSONArray("relatedStreams");
        if (rel != null) {
            for (int i = 0; i < rel.length() && relatedList.size() < 30; i++) {
                JSONObject o = rel.optJSONObject(i);
                if (o == null || !o.optString("url", "").startsWith("/watch")) continue;
                relatedList.add(o);
                VideoCardView c = new VideoCardView(this);
                c.bind(o, this);
                relatedBox.addView(c, new LinearLayout.LayoutParams(-1, -2));
            }
        }
        updateChips();
        buildCandidates();
        startPlayback(0);
    }

    // ------------------------------------------------------------------ stream selection

    private static List<JSONObject> list(JSONArray a) {
        List<JSONObject> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !o.optString("url", "").isEmpty()) out.add(o);
        }
        return out;
    }

    private static int height(JSONObject s) {
        int h = s.optInt("height", 0);
        if (h > 0) return h;
        String q = s.optString("quality", "").replaceAll("[^0-9].*$", "");
        try { return q.isEmpty() ? 0 : Integer.parseInt(q); } catch (Exception e) { return 0; }
    }

    private void buildCandidates() {
        candidates.clear();
        candIdx = 0;
        if (streamInfo == null) return;
        if (audioMode) {
            List<JSONObject> a = list(streamInfo.optJSONArray("audioStreams"));
            Collections.sort(a, new Comparator<JSONObject>() {
                @Override public int compare(JSONObject x, JSONObject y) {
                    boolean xm = x.optString("mimeType", "").contains("mp4");
                    boolean ym = y.optString("mimeType", "").contains("mp4");
                    if (xm != ym) return xm ? -1 : 1;
                    return Integer.compare(y.optInt("bitrate", 0), x.optInt("bitrate", 0));
                }
            });
            for (JSONObject s : a) candidates.add(new String[]{s.optString("url"), s.optString("mimeType", "")});
            String hls = streamInfo.optString("hls", "");
            if (candidates.isEmpty() && !hls.isEmpty() && !hls.equals("null"))
                candidates.add(new String[]{hls, MimeTypes.APPLICATION_M3U8});
            return;
        }
        List<JSONObject> prog = new ArrayList<>();
        for (JSONObject s : list(streamInfo.optJSONArray("videoStreams")))
            if (!s.optBoolean("videoOnly", false)) prog.add(s);
        Collections.sort(prog, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject x, JSONObject y) { return Integer.compare(height(y), height(x)); }
        });
        String q = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        String hls = streamInfo.optString("hls", "");
        String dash = streamInfo.optString("dash", "");
        boolean hasHls = !hls.isEmpty() && !hls.equals("null");
        boolean hasDash = !dash.isEmpty() && !dash.equals("null");
        if (q.equals("adaptive")) {
            if (hasHls) candidates.add(new String[]{hls, MimeTypes.APPLICATION_M3U8});
            if (hasDash) candidates.add(new String[]{dash, MimeTypes.APPLICATION_MPD});
        }
        int target = 100000;
        if (!q.equals("auto") && !q.equals("adaptive")) {
            try { target = Integer.parseInt(q); } catch (Exception ignored) { }
        }
        List<JSONObject> below = new ArrayList<>(), above = new ArrayList<>();
        for (JSONObject s : prog) { if (height(s) <= target) below.add(s); else above.add(s); }
        Collections.reverse(above);
        for (JSONObject s : below) candidates.add(new String[]{s.optString("url"), s.optString("mimeType", "")});
        for (JSONObject s : above) candidates.add(new String[]{s.optString("url"), s.optString("mimeType", "")});
        if (!q.equals("adaptive")) {
            if (hasHls) candidates.add(new String[]{hls, MimeTypes.APPLICATION_M3U8});
            if (hasDash) candidates.add(new String[]{dash, MimeTypes.APPLICATION_MPD});
        }
    }

    private void startPlayback(long seekMs) {
        if (candidates.isEmpty()) {
            if (streamInfo != null) showMsg("No playable stream was returned for this video.");
            return;
        }
        if (controller == null) { pendingStart = true; return; }
        if (candIdx >= candidates.size()) candIdx = 0;
        String[] c = candidates.get(candIdx);
        MediaMetadata.Builder md = new MediaMetadata.Builder().setTitle(title).setArtist(uploader);
        if (thumb != null && !thumb.isEmpty()) md.setArtworkUri(Uri.parse(thumb));
        MediaItem.Builder mb = new MediaItem.Builder().setUri(c[0]).setMediaId(String.valueOf(videoId))
            .setMediaMetadata(md.build());
        if (c[1] != null && !c[1].isEmpty() && !c[1].equals("null")) mb.setMimeType(c[1]);
        controller.setMediaItem(mb.build(), seekMs);
        controller.prepare();
        controller.play();
        if (audioMode) Toast.makeText(this, "Audio mode · keeps playing with the screen off", Toast.LENGTH_SHORT).show();
    }

    private void onPlayError(PlaybackException error) {
        if (candIdx + 1 < candidates.size()) {
            candIdx++;
            long pos = controller == null ? 0 : Math.max(0, controller.getCurrentPosition());
            startPlayback(pos);
        } else {
            showMsg("Playback failed (" + error.getErrorCodeName() + ").\nTap to retry");
            overlayMsg.setOnClickListener(v -> { overlayMsg.setVisibility(View.GONE); loadStreams(); });
        }
    }

    // ------------------------------------------------------------------ actions

    private void toggleAudio() {
        if (!audioMode && !prefs.getBoolean("background_play", true)) {
            Toast.makeText(this, "Turn on Background play in You › Settings", Toast.LENGTH_LONG).show();
            return;
        }
        long pos = controller == null ? 0 : Math.max(0, controller.getCurrentPosition());
        audioMode = !audioMode;
        updateChips();
        buildCandidates();
        startPlayback(pos);
    }

    private void pickQuality() {
        if (streamInfo == null) return;
        final List<String> labels = new ArrayList<>(), values = new ArrayList<>();
        labels.add("Auto (best)"); values.add("auto");
        List<Integer> seenH = new ArrayList<>();
        List<JSONObject> prog = new ArrayList<>();
        for (JSONObject s : list(streamInfo.optJSONArray("videoStreams")))
            if (!s.optBoolean("videoOnly", false)) prog.add(s);
        Collections.sort(prog, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject x, JSONObject y) { return Integer.compare(height(y), height(x)); }
        });
        for (JSONObject s : prog) {
            int h = height(s);
            if (h > 0 && !seenH.contains(h)) { seenH.add(h); labels.add(h + "p"); values.add(String.valueOf(h)); }
        }
        String hls = streamInfo.optString("hls", "");
        String dash = streamInfo.optString("dash", "");
        if ((!hls.isEmpty() && !hls.equals("null")) || (!dash.isEmpty() && !dash.equals("null"))) {
            labels.add("Adaptive (up to 1080p+)"); values.add("adaptive");
        }
        String cur = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        int checked = Math.max(0, values.indexOf(cur));
        new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Video quality")
            .setSingleChoiceItems(labels.toArray(new String[0]), checked, (d, w) -> {
                forcedQuality = values.get(w);
                d.dismiss();
                long pos = controller == null ? 0 : Math.max(0, controller.getCurrentPosition());
                updateChips();
                buildCandidates();
                startPlayback(pos);
            }).show();
    }

    private void playNext() {
        if (!prefs.getBoolean("autoplay", true) || relatedList.isEmpty()) return;
        JSONObject n = relatedList.get(0);
        String id = YoutubeApiClient.videoId(n.optString("url", ""));
        if (id.isEmpty() || id.equals(videoId)) return;
        onOpen(id, n.optString("title", ""), n.optString("uploaderName", ""),
            n.optString("thumbnail", ""), audioMode);
    }

    /** Called when a suggested video is tapped; reuses this screen instead of stacking new ones. */
    @Override public void onOpen(String id, String t, String author, String th, boolean audio) {
        if (id == null || id.isEmpty()) return;
        if (audio && !prefs.getBoolean("background_play", true)) {
            Toast.makeText(this, "Turn on Background play in You › Settings", Toast.LENGTH_LONG).show();
            return;
        }
        Ui.saveHistory(this, id, t, author, th);
        videoId = id;
        title = t;
        uploader = author;
        thumb = th;
        audioMode = audio;
        forcedQuality = null;
        titleV.setText(t == null ? "" : t);
        channelV.setText(author == null ? "" : author);
        metaV.setText("");
        descV.setVisibility(View.GONE);
        avatarV.setImageDrawable(null);
        scroll.scrollTo(0, 0);
        updateChips();
        loadStreams();
    }

    // ------------------------------------------------------------------ lifecycle

    @Override protected void onStop() {
        if (!prefs.getBoolean("background_play", true) && controller != null) controller.pause();
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (playerView != null) playerView.setPlayer(null);
        if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
        controller = null;
        pool.shutdownNow();
        super.onDestroy();
    }
}
