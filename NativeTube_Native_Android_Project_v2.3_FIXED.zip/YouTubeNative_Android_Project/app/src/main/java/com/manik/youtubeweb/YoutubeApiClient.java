package com.manik.youtubeweb;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Native JSON API adapter (Piped-compatible). No WebView.
 * Public instances often fail, so every request is raced across several instances in parallel
 * and the first valid answer wins. The instance that worked last is remembered.
 */
public final class YoutubeApiClient {
    public static final String DEFAULT_BASE = "https://pipedapi.kavin.rocks";
    private static final String UA = "YoutubePremium/3.0 (Android)";
    private static final String[] FALLBACKS = {
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.adminforge.de",
        "https://pipedapi.private.coffee",
        "https://api.piped.private.coffee",
        "https://pipedapi.ducks.party",
        "https://pipedapi.leptons.xyz",
        "https://piped-api.privacy.com.de",
        "https://pipedapi.nosebs.ru",
        "https://pipedapi.reallyaweso.me",
        "https://pipedapi.darkness.services",
        "https://pipedapi.orangenet.cc",
        "https://pipedapi.drgns.space",
        "https://api.piped.yt"
    };
    private static final int PARALLEL = 3;
    private static final int MAX_TRIES = 14;

    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS).readTimeout(9, TimeUnit.SECONDS)
        .callTimeout(12, TimeUnit.SECONDS).build();
    private static final ExecutorService RACE = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "api-race");
        t.setDaemon(true);
        return t;
    });
    private static volatile String lastGood = "";
    private static volatile List<String> extra = new ArrayList<>();

    private final String custom;

    /** @param custom user-chosen instance URL, or empty/null for automatic selection. */
    public YoutubeApiClient(String custom) {
        this.custom = clean(custom);
    }

    public interface Validator { boolean ok(String body); }

    public static final class Page {
        public final JSONArray items;
        public final String next;
        Page(JSONArray items, String next) {
            this.items = items == null ? new JSONArray() : items;
            this.next = next == null ? "" : next;
        }
    }

    public static OkHttpClient http() { return HTTP; }
    public static String getLastGood() { return lastGood; }
    public static void setLastGood(String s) { lastGood = clean(s); }
    public static void setExtra(List<String> l) { extra = l == null ? new ArrayList<String>() : l; }

    private static String clean(String u) {
        if (u == null) return "";
        u = u.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    /** Fetches the public list of live Piped API instances. */
    public static List<String> fetchInstances() throws IOException {
        Request req = new Request.Builder().url("https://piped-instances.kavin.rocks/")
            .header("User-Agent", UA).build();
        List<String> out = new ArrayList<>();
        try (Response r = HTTP.newCall(req).execute()) {
            if (!r.isSuccessful() || r.body() == null) throw new IOException("HTTP " + r.code());
            JSONArray arr = new JSONArray(r.body().string());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String u = clean(o.optString("api_url", ""));
                if (u.startsWith("https://")) out.add(u);
            }
        } catch (org.json.JSONException e) {
            throw new IOException("Bad instance list", e);
        }
        return out;
    }

    private List<String> candidates() {
        Set<String> set = new LinkedHashSet<>();
        if (!custom.isEmpty()) set.add(custom);
        if (!lastGood.isEmpty()) set.add(lastGood);
        for (String f : FALLBACKS) set.add(f);
        set.addAll(extra);
        return new ArrayList<>(set);
    }

    private static final class Attempt implements Callable<String[]> {
        private final String inst, path;
        private final Validator validator;
        private volatile Call call;
        Attempt(String inst, String path, Validator v) { this.inst = inst; this.path = path; this.validator = v; }
        @Override public String[] call() throws Exception {
            Request req = new Request.Builder().url(inst + path)
                .header("User-Agent", UA).header("Accept", "application/json").build();
            call = HTTP.newCall(req);
            try (Response r = call.execute()) {
                if (!r.isSuccessful() || r.body() == null) throw new IOException("API HTTP " + r.code());
                String body = r.body().string();
                if (validator != null && !validator.ok(body)) throw new IOException("Bad response");
                return new String[]{inst, body};
            }
        }
        void cancel() { Call c = call; if (c != null) c.cancel(); }
    }

    private String getBody(String path, Validator v) throws IOException {
        List<String> c = candidates();
        ExecutorCompletionService<String[]> ecs = new ExecutorCompletionService<>(RACE);
        List<Attempt> started = new ArrayList<>();
        int next = 0, inFlight = 0;
        String lastErr = "no instances";
        try {
            while (true) {
                while (inFlight < PARALLEL && next < c.size() && next < MAX_TRIES) {
                    Attempt a = new Attempt(c.get(next++), path, v);
                    started.add(a);
                    ecs.submit(a);
                    inFlight++;
                }
                if (inFlight == 0) break;
                try {
                    Future<String[]> f = ecs.take();
                    inFlight--;
                    try {
                        String[] r = f.get();
                        lastGood = r[0];
                        return r[1];
                    } catch (ExecutionException e) {
                        Throwable cause = e.getCause();
                        lastErr = cause == null ? "error" : String.valueOf(cause.getMessage());
                    }
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Interrupted");
                }
            }
        } finally {
            for (Attempt a : started) a.cancel();
        }
        throw new IOException("No working API server right now (" + lastErr + ")");
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s, StandardCharsets.UTF_8.name()); }
        catch (Exception e) { return s; }
    }

    private static boolean hasItems(String b) {
        try { return new JSONObject(b).has("items"); } catch (Exception e) { return false; }
    }

    public JSONArray trending(String region) throws IOException {
        String r = enc(region == null || region.isEmpty() ? "US" : region);
        String body = getBody("/trending?region=" + r, b -> {
            try { return new JSONArray(b).length() > 0; } catch (Exception e) { return false; }
        });
        try { return new JSONArray(body); }
        catch (org.json.JSONException e) { throw new IOException("Invalid trending response", e); }
    }

    /** One page of video search results; pass the previous page's {@code next} token for more. */
    public Page searchPage(String query, String token) throws IOException {
        String path = (token == null || token.isEmpty())
            ? "/search?q=" + enc(query) + "&filter=videos"
            : "/nextpage/search?nextpage=" + enc(token) + "&q=" + enc(query) + "&filter=videos";
        String body = getBody(path, YoutubeApiClient::hasItems);
        try {
            JSONObject o = new JSONObject(body);
            String next = o.isNull("nextpage") ? "" : o.optString("nextpage", "");
            return new Page(o.optJSONArray("items"), next);
        } catch (org.json.JSONException e) {
            throw new IOException("Invalid search response", e);
        }
    }

    public JSONArray channelVideos(String channelId) throws IOException {
        String body = getBody("/channel/" + enc(channelId), b -> {
            try { return new JSONObject(b).has("relatedStreams"); } catch (Exception e) { return false; }
        });
        try { return new JSONObject(body).optJSONArray("relatedStreams"); }
        catch (org.json.JSONException e) { throw new IOException("Invalid channel response", e); }
    }

    public JSONObject streams(String videoId) throws IOException {
        String body = getBody("/streams/" + enc(videoId), b -> {
            try {
                JSONObject o = new JSONObject(b);
                if (o.has("error")) return false;
                JSONArray v = o.optJSONArray("videoStreams");
                JSONArray a = o.optJSONArray("audioStreams");
                String hls = o.optString("hls", "");
                return (v != null && v.length() > 0) || (a != null && a.length() > 0)
                    || (!hls.isEmpty() && !hls.equals("null"));
            } catch (Exception e) { return false; }
        });
        try { return new JSONObject(body); }
        catch (org.json.JSONException e) { throw new IOException("Invalid stream response", e); }
    }

    public static String videoId(String url) {
        if (url == null) return "";
        if (url.matches("[A-Za-z0-9_-]{11}")) return url;
        if (url.startsWith("/watch?")) url = "https://www.youtube.com" + url;
        int v = url.indexOf("v=");
        if (v >= 0) {
            String id = url.substring(v + 2);
            int amp = id.indexOf('&');
            return amp >= 0 ? id.substring(0, amp) : id;
        }
        int last = url.lastIndexOf('/');
        return last >= 0 ? url.substring(last + 1) : url;
    }

    /** Keeps only regular watchable videos (no channels, playlists or Shorts) and removes duplicates. */
    public static List<JSONObject> playable(JSONArray arr, Set<String> seen) {
        List<JSONObject> out = new ArrayList<>();
        if (arr == null) return out;
        Set<String> local = seen == null ? new HashSet<String>() : seen;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String url = o.optString("url", "");
            if (!url.startsWith("/watch")) continue;
            if (o.optBoolean("isShort", false)) continue;
            String id = videoId(url);
            if (id.isEmpty() || !local.add(id)) continue;
            out.add(o);
        }
        return out;
    }
}
