package com.manik.youtubeweb;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/** Native JSON API adapter. No WebView is used. */
public final class YoutubeApiClient {
    public static final String DEFAULT_BASE = "https://pipedapi.ducks.party";
    private static final OkHttpClient HTTP = new OkHttpClient();
    private final String base;

    public YoutubeApiClient(String base) {
        String b = base == null || base.trim().isEmpty() ? DEFAULT_BASE : base.trim();
        this.base = b.endsWith("/") ? b.substring(0, b.length()-1) : b;
    }

    private String getBody(String path) throws IOException {
        Request req = new Request.Builder().url(base + path)
            .header("User-Agent", "NativeTube/2.0 (Android)")
            .header("Accept", "application/json").build();
        try (Response response = HTTP.newCall(req).execute()) {
            if (!response.isSuccessful() || response.body() == null)
                throw new IOException("API HTTP " + response.code());
            return response.body().string();
        }
    }

    private JSONObject getObject(String path) throws IOException {
        try {
            return new JSONObject(getBody(path));
        } catch (org.json.JSONException e) {
            throw new IOException("Invalid JSON response from API", e);
        }
    }

    public JSONArray trending(String region) throws IOException {
        String r = URLEncoder.encode(region == null || region.isEmpty() ? "US" : region, StandardCharsets.UTF_8.name());
        String body = getBody("/trending?region=" + r);
        try {
            return new JSONArray(body);
        } catch (org.json.JSONException ignored) {
            try {
                return new JSONObject(body).optJSONArray("items");
            } catch (org.json.JSONException e) {
                throw new IOException("Invalid trending JSON response", e);
            }
        }
    }

    public JSONArray search(String query) throws IOException {
        String q = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
        return getObject("/search?q=" + q + "&filter=videos").optJSONArray("items");
    }

    public JSONObject streams(String videoId) throws IOException {
        return getObject("/streams/" + URLEncoder.encode(videoId, StandardCharsets.UTF_8.name()));
    }

    public static String videoId(String url) {
        if (url == null) return "";
        if (url.matches("[A-Za-z0-9_-]{11}")) return url;
        if (url.startsWith("/watch?")) url = "https://www.youtube.com" + url;
        int v = url.indexOf("v=");
        if (v >= 0) {
            String id = url.substring(v+2);
            int amp = id.indexOf('&');
            return amp >= 0 ? id.substring(0, amp) : id;
        }
        int last = url.lastIndexOf('/');
        return last >= 0 ? url.substring(last+1) : url;
    }
}
