package com.manik.youtubeweb;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Shared theme colours and small view helpers (Midnight &amp; Gold premium look). */
final class Ui {
    static boolean dark = true;
    static int bg, surface, surface2, fg, muted, line, accent, accent2, onAccent;
    static float density = 2f;

    static final String[] ACCENT_NAMES = {"Gold", "Ruby", "Aqua", "Violet", "Emerald"};
    static final int[] ACCENT_A = {0xFFFFD36B, 0xFFFF6B7A, 0xFF5EEAD4, 0xFFA89BFF, 0xFF4ADE9C};
    static final int[] ACCENT_B = {0xFFF0A02E, 0xFFE0243B, 0xFF14B8A6, 0xFF6D4FF0, 0xFF16A36B};

    private Ui() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("native_settings", Context.MODE_PRIVATE);
    }

    static void load(Context c) {
        density = c.getResources().getDisplayMetrics().density;
        SharedPreferences p = prefs(c);
        String theme = p.getString("theme2", "midnight");
        boolean sysDark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (theme.equals("system")) theme = sysDark ? "midnight" : "light";
        dark = !theme.equals("light");
        if (theme.equals("amoled")) {
            bg = 0xFF000000; surface = 0xFF111114; surface2 = 0xFF1B1B21; line = 0xFF28282F;
        } else if (theme.equals("light")) {
            bg = 0xFFFAF8F4; surface = 0xFFFFFFFF; surface2 = 0xFFEDE8DF; line = 0xFFE3DDD0;
        } else {
            bg = 0xFF0B0B13; surface = 0xFF151521; surface2 = 0xFF1F1F2E; line = 0xFF2A2A3B;
        }
        fg = dark ? 0xFFF5F5FA : 0xFF16161D;
        muted = dark ? 0xFF9A9AB0 : 0xFF6B6760;
        int i = Math.max(0, Math.min(p.getInt("accent", 0), ACCENT_A.length - 1));
        accent = ACCENT_A[i];
        accent2 = ACCENT_B[i];
        onAccent = 0xFF1A1205;
    }

    static int dp(float v) { return (int) (v * density + .5f); }

    /** Accent colour that stays readable as text on the current background. */
    static int accentText() { return dark ? accent : accent2; }

    static TextView text(Context c, String s, float sp, boolean bold, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    static GradientDrawable rect(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    static GradientDrawable outline(int fill, int stroke, float radiusDp) {
        GradientDrawable d = rect(fill, radiusDp);
        d.setStroke(Math.max(1, dp(1)), stroke);
        return d;
    }

    static GradientDrawable gradient(float radiusDp) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{accent, accent2});
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    static GradientDrawable gradientOval() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{accent, accent2});
        d.setShape(GradientDrawable.OVAL);
        return d;
    }

    static GradientDrawable oval(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    static ImageView icon(Context c, int res, int color, float sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return v;
    }

    private static String one(double v) {
        String s = String.format(Locale.US, "%.1f", v);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    static String count(long n) {
        if (n >= 1_000_000_000L) return one(n / 1e9) + "B";
        if (n >= 1_000_000L) return one(n / 1e6) + "M";
        if (n >= 1_000L) return one(n / 1e3) + "K";
        return String.valueOf(n);
    }

    static String duration(long sec) {
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        return String.format(Locale.US, "%d:%02d", m, s);
    }

    static String firstNonEmpty(String... values) {
        for (String v : values) if (v != null && !v.isEmpty() && !v.equals("null")) return v;
        return "";
    }

    static void saveHistory(Context c, String id, String title, String author, String thumb) {
        if (id == null || id.isEmpty()) return;
        try {
            SharedPreferences p = prefs(c);
            JSONArray old = new JSONArray(p.getString("watch_history", "[]"));
            JSONArray next = new JSONArray();
            JSONObject e = new JSONObject();
            e.put("id", id);
            e.put("title", title == null ? "" : title);
            e.put("author", author == null ? "" : author);
            e.put("thumb", thumb == null ? "" : thumb);
            e.put("time", System.currentTimeMillis());
            next.put(e);
            for (int i = 0; i < old.length() && next.length() < 100; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x != null && !id.equals(x.optString("id"))) next.put(x);
            }
            p.edit().putString("watch_history", next.toString()).apply();
        } catch (Exception ignored) { }
    }
}
