NativeTube v2.3 — Native Android starter project
================================================

এই সংস্করণে Home UI-কে YouTube-ধাঁচের native Android layout-এ নতুন করে সাজানো হয়েছে:
- NativeTube app bar, search field এবং horizontal category chips
- বড় 16:9 video thumbnails, title, channel/metadata এবং per-video actions
- Bottom navigation shell: Home, Shorts, Subscriptions, You
- Dark / Light / System theme
- Per-video Background Play এবং ad-filter preference
- Player stream request-এ configured API ব্যর্থ হলে বিকল্প Piped-compatible instance চেষ্টা
- Home ও Player একই default API constant ব্যবহার করে
- কোনো WebView নেই

গুরুত্বপূর্ণ সীমাবদ্ধতা
----------------------
1. এটি YouTube-এর অফিসিয়াল অ্যাপ নয়। ভিডিও সার্চ/স্ট্রিম তৃতীয়-পক্ষ Piped-compatible API instance-এর ওপর নির্ভরশীল। Public instance বন্ধ, rate-limit বা HTTP 403 দিতে পারে। কোনো fallback সবসময় সচল থাকবে—এমন নিশ্চয়তা নেই।
2. microG-কে APK-এর মধ্যে সাধারণ dependency হিসেবে যোগ করা যায় না। microG হলো আলাদা GmsCore/system component; কিছু ডিভাইসে system signature spoofing/ROM support প্রয়োজন হয়। শুধু microG যোগ করলেই YouTube sign-in বা Google OAuth স্বয়ংক্রিয়ভাবে কাজ করবে না। এই প্রজেক্টে এখনো নিরাপদ ও সমর্থিত Google/YouTube account sign-in নেই।
3. Like/Dislike, Comments, Subscribe, personalized subscriptions feed এবং YouTube account sync এখনো বাস্তবায়িত নয়। Bottom navigation-এর Shorts/Subscriptions অংশ placeholder।
4. Ad filter button বর্তমানে per-video preference সংরক্ষণ করে; সব YouTube বিজ্ঞাপন ব্লক করার নিশ্চয়তা দেয় না।
5. Background audio Media3 MediaSessionService দিয়ে করা হয়েছে; screen-off playback বাস্তব ডিভাইসে পরীক্ষা করতে হবে।
6. এই পরিবেশে Android SDK/Gradle build চালিয়ে APK compile পরীক্ষা করা হয়নি। GitHub Actions-এ build সফল হওয়া এবং ফোনে feature test আলাদা ধাপ।

Build
-----
Repository root-এ ZIP extract করে `YouTubeNative_Android_Project` directory থেকে:
  gradle assembleDebug

APK path:
  app/build/outputs/apk/debug/app-debug.apk

Package: com.manik.youtubeweb
Version: 2.3-native


আপডেটেড v2.3 UI পরিবর্তন:
- Bottom navigation: Home, Trending, History, Settings। Shorts ও Subscriptions সরানো হয়েছে।
- History ডিভাইসে সর্বশেষ ১০০টি খোলা ভিডিও সংরক্ষণ করে। Customize থেকে History মুছতে পারবেন।
- Settings-এর ভিতরে Customize: System/Light/Dark theme এবং Clear History।
- Ad Block preference এখন Global; প্রতি ভিডিওতে আলাদা Filter control নেই। তবে এটি preference toggle মাত্র—Piped/API provider বা YouTube-এর সব বিজ্ঞাপন ব্লক করার নিশ্চয়তা দেয় না।
- APK Build ও বাস্তব ডিভাইসে playback পরীক্ষা না করা পর্যন্ত ফিচারগুলোকে verified বলা যাবে না।
