Youtube Premium (NativeTube) v3.0 — Native Android প্রজেক্ট
==========================================================

নতুন কী আছে
-----------
- অ্যাপের নাম: Youtube Premium। Midnight + Gold প্রিমিয়াম ডিজাইন, নতুন আইকন।
- হোম ফিড এখন অনেক বেশি ভিডিও দেখায়: Trending + একাধিক বিষয় (Music, Bangla natok, Gaming, News...) একসাথে লোড হয়।
  নিচে স্ক্রল করলে নতুন ভিডিও নিজে থেকে আসতে থাকে (infinite scroll)। সার্চেও পরের পেজ আসে।
- দ্রুত লোড: একসাথে ৩টা সার্ভারে রিকোয়েস্ট পাঠিয়ে যেটা আগে সাড়া দেয় সেটা ব্যবহার হয়; লোডিং-এর সময় skeleton কার্ড; আগের হোম ফিড ক্যাশ থেকে সাথে সাথে দেখায়।
- ইউটিউবের মতো কার্ড: বড় থাম্বনেইল, সময়/LIVE ব্যাজ, চ্যানেল অ্যাভাটার, ভিউ ও কবে আপলোড, ⋮ মেনু (Background play, Share, Copy link)।
- প্লেয়ার: ফুলস্ক্রিন, Quality বাছাই, Audio only (ব্যাকগ্রাউন্ড), Up next সাজেস্টেড ভিডিও, Autoplay next।
- নিচের মেনু: Home, Trending, Subs, History, You।
- You (প্রোফাইল) এর ভিতরে: Google সাইন-ইন, Customize (Theme, Accent color, Home region) এবং Settings
  (Background play, Autoplay, Video quality, Video server, Clear history/cache)।

Google লগইন চালু করার ধাপ (একবারই করতে হবে)
---------------------------------------------
Google লগইন কাজ করার জন্য আপনার নিজের Google Cloud প্রজেক্টে অ্যাপটি রেজিস্টার করা লাগবে। এটা কোড দিয়ে করা যায় না।
১. https://console.cloud.google.com এ নতুন প্রজেক্ট খুলুন।
২. APIs & Services > Library > "YouTube Data API v3" Enable করুন।
৩. APIs & Services > OAuth consent screen > External। অ্যাপের নাম দিন, Scopes-এ
   .../auth/youtube.readonly যোগ করুন, আর Test users-এ আপনার Gmail যোগ করুন।
৪. Credentials > Create credentials > OAuth client ID > Application type: Android
     Package name : com.manik.youtubeweb
     SHA-1        : 7E:1A:E1:53:4E:B8:28:AE:BF:8B:0E:CD:B5:9E:51:4A:6B:61:D3:28
   (এই SHA-1 প্রজেক্টের app/debug.keystore এর। GitHub Actions বা নিজের পিসিতে এই প্রজেক্ট থেকে build করলে একই থাকবে।)
৫. APK ইনস্টল করে You > Sign in with Google চাপুন।
বি.দ্র.: অ্যাপ "Testing" অবস্থায় থাকলে মাঝে মাঝে আবার সাইন-ইন করতে হতে পারে।
লগইন করলে নাম/ছবি/ইমেইল দেখাবে এবং Subs ট্যাবে আপনার সাবস্ক্রাইব করা চ্যানেলের নতুন ভিডিও আসবে।

সীমাবদ্ধতা (সৎভাবে)
--------------------
1. এটি YouTube-এর অফিসিয়াল অ্যাপ নয়, আর আসল YouTube Premium সাবস্ক্রিপশনও নয়। শুধু নামটা Youtube Premium।
2. ভিডিও সার্চ/স্ট্রিম তৃতীয়-পক্ষ Piped-compatible পাবলিক সার্ভারের ওপর নির্ভর করে। সার্ভার বন্ধ/ব্যস্ত থাকতে পারে;
   অ্যাপ অনেকগুলো সার্ভার চেষ্টা করে, তবু সব একসাথে ব্যর্থ হলে Try again চাপুন বা পরে চেষ্টা করুন।
3. Piped স্ট্রিমে সাধারণত YouTube-এর ভিডিওর ভিতরের বিজ্ঞাপন থাকে না, কিন্তু এটার গ্যারান্টি দেওয়া যায় না।
4. Like/Dislike, Comment, Subscribe বাটন এখনো নেই (শুধু দেখা/সাবস্ক্রিপশন তালিকা)।
5. এই পরিবেশে Android SDK/Gradle ছিল না, তাই APK compile ও ফোনে পরীক্ষা করা হয়নি।
   GitHub Actions-এ build করে ফোনে টেস্ট করুন; কোনো error এলে লগ পাঠালে ঠিক করে দেব।

Build
-----
ZIP extract করে `YouTubeNative_Android_Project` ফোল্ডার থেকে:  gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
Package: com.manik.youtubeweb   Version: 3.0-premium
