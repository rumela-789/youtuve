package com.zchat.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private val popups = ArrayList<WebView>()
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val startUrl = "https://chat.z.ai"

    // WebView চিহ্ন ("; wv", "Version/4.0") বাদ দিয়ে সাধারণ Chrome-এর মতো UA
    private fun chromeUa(): String =
        WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "")

    @SuppressLint("SetJavaScriptEnabled")
    private fun setup(w: WebView) {
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true) // Google login popup অ্যাপের ভেতরেই খুলবে
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            userAgentString = chromeUa()
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(w, true)
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val scheme = r.url.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, r.url)); true } catch (e: Exception) { true }
            }
            override fun onPageFinished(v: WebView?, url: String?) {
                CookieManager.getInstance().flush() // login session সংরক্ষণ
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, msg: Message): Boolean {
                val child = WebView(this@MainActivity)
                setup(child)
                root.addView(child, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                popups.add(child)
                (msg.obj as WebView.WebViewTransport).webView = child
                msg.sendToTarget()
                return true
            }
            override fun onCloseWindow(window: WebView) {
                root.removeView(window)
                popups.remove(window)
                window.destroy()
                CookieManager.getInstance().flush()
            }
            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = cb
                return try {
                    startActivityForResult(params.createIntent(), 1001); true
                } catch (e: Exception) { filePathCallback = null; false }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        web = WebView(this)
        setup(web)
        root.addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(startUrl)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1001) {
            filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            filePathCallback = null
        } else super.onActivityResult(req, res, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            popups.isNotEmpty() -> {
                val p = popups.removeAt(popups.lastIndex)
                root.removeView(p); p.destroy()
            }
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }
    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); web.saveState(out) }
}
