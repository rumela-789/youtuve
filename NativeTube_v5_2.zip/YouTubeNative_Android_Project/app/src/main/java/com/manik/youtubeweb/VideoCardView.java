package com.manik.youtubeweb;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Outline;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ProgressBar;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One video row. In feed mode it is laid out like a Facebook post: channel avatar + name + Subscribe on top,
 * the title, the video (plays right inside the card) and a slim Like / Dislike / Comment / Download / Share /
 * Save bar underneath, so nothing needs to be opened first. Outside the feed (related videos) it stays a
 * plain thumbnail row.
 */
final class VideoCardView extends LinearLayout {
    interface Listener {
        void onOpen(String id, String title, String author, String thumb, String avatar, boolean audioOnly);
        default void onComment(String id) { }
        default void onDownload(String id, String title) { }
        default void onNeedLogin() { }
        default void onMuteToggle() { }
        /** Tap on the video itself: play / pause (never opens the video page). */
        default void onVideoTap(VideoCardView card, String id) { }
        default void onSeekBy(long deltaMs) { }
        default void onSeekTo(float fraction) { }
        /** Channel name / logo tapped. */
        default void onChannel(String channelId, String name, String avatar) { }
    }

    private static final ExecutorService IO = Executors.newFixedThreadPool(2);

    private final ImageView thumb, avatar, more, muteBtn;
    private final TextView title, meta, badge;
    private final FrameLayout box, videoHolder;
    private final View progress;
    private final boolean feed;
    private final int boxW, boxH;

    private static final Map<String, String> AVATARS = new HashMap<>();   // channelId -> avatar url
    private static final Map<String, String> SUBS = new HashMap<>();      // channelId -> "1.2M subscribers"
    private static final Set<String> SUBS_PENDING = new HashSet<>();
    private static final ExecutorService SUBS_IO = Executors.newSingleThreadExecutor();

    private static final Map<String, String[]> STATS = new HashMap<>();   // videoId -> {likes, comments}
    private static final Set<String> STATS_PENDING = new HashSet<>();
    private static final ExecutorService STATS_IO = Executors.newFixedThreadPool(2);

    private final TextView channelName, subLine, subBtn;
    private SeekView seek;
    private LinearLayout chanTap;
    private ImageView centerIcon;
    private TextView flash;
    private ProgressBar spinner;
    private GestureDetector taps;
    private long curDur = 0;
    private Listener curListener;
    private LinearLayout likeBtn, dislikeBtn, saveBtn, actionBar;
    private String curId = "";
    private String curChannel = "";
    private boolean live = false;

    VideoCardView(Context c) { this(c, false); }

    VideoCardView(Context c, boolean feedMode) {
        super(c);
        feed = feedMode;
        setOrientation(VERTICAL);
        int margin = Ui.dp(12);
        setPadding(margin, Ui.dp(8), margin, Ui.dp(10));

        int sw = c.getResources().getDisplayMetrics().widthPixels;
        boxW = Math.min(sw, Ui.dp(640)) - 2 * margin;
        boxH = boxW * 9 / 16;

        box = new FrameLayout(c);
        box.setBackground(Ui.rect(Ui.surface2, 14));
        box.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(14));
            }
        });
        box.setClipToOutline(true);
        thumb = new ImageView(c);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        box.addView(thumb, new FrameLayout.LayoutParams(-1, -1));

        videoHolder = new FrameLayout(c);
        videoHolder.setBackgroundColor(0xFF000000);
        videoHolder.setAlpha(0f);
        videoHolder.setVisibility(View.GONE);
        box.addView(videoHolder, new FrameLayout.LayoutParams(-1, -1));

        badge = Ui.text(c, "", 11, true, 0xFFFFFFFF);
        badge.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(2));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2);
        bp.gravity = Gravity.BOTTOM | Gravity.END;
        bp.setMargins(0, 0, Ui.dp(8), feed ? Ui.dp(22) : Ui.dp(8));
        box.addView(badge, bp);

        muteBtn = Ui.icon(c, R.drawable.ic_volume_off, 0xFFFFFFFF, 18);
        muteBtn.setBackground(Ui.oval(0x99000000));
        muteBtn.setPadding(Ui.dp(7), Ui.dp(7), Ui.dp(7), Ui.dp(7));
        muteBtn.setVisibility(View.GONE);
        muteBtn.setContentDescription("Sound");
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(Ui.dp(32), Ui.dp(32));
        mp.gravity = Gravity.TOP | Gravity.END;
        mp.setMargins(0, Ui.dp(8), Ui.dp(8), 0);
        box.addView(muteBtn, mp);

        progress = new View(c);
        progress.setBackgroundColor(0xFFFF0000);
        progress.setVisibility(View.GONE);
        FrameLayout.LayoutParams pgp = new FrameLayout.LayoutParams(0, Ui.dp(3));
        pgp.gravity = Gravity.BOTTOM | Gravity.START;
        box.addView(progress, pgp);

        if (feed) {
            spinner = new ProgressBar(c);
            spinner.setVisibility(View.GONE);
            FrameLayout.LayoutParams sp0 = new FrameLayout.LayoutParams(Ui.dp(30), Ui.dp(30), Gravity.CENTER);
            box.addView(spinner, sp0);

            centerIcon = Ui.icon(c, R.drawable.ic_play, 0xFFFFFFFF, 30);
            centerIcon.setBackground(Ui.oval(0x99000000));
            centerIcon.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
            centerIcon.setVisibility(View.GONE);
            box.addView(centerIcon, new FrameLayout.LayoutParams(Ui.dp(52), Ui.dp(52), Gravity.CENTER));

            flash = Ui.text(c, "", 14, true, 0xFFFFFFFF);
            flash.setBackground(Ui.rect(0x99000000, 18));
            flash.setPadding(Ui.dp(14), Ui.dp(7), Ui.dp(14), Ui.dp(7));
            flash.setVisibility(View.GONE);
            box.addView(flash, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

            seek = new SeekView(c);
            seek.setVisibility(View.GONE);
            seek.cb = new SeekView.Cb() {
                @Override public void onSeek(float f) { if (curListener != null) curListener.onSeekTo(f); }
            };
            box.addView(seek, new FrameLayout.LayoutParams(-1, Ui.dp(26), Gravity.BOTTOM));

            taps = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                    if (curListener != null) curListener.onVideoTap(VideoCardView.this, curId);
                    return true;
                }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    if (curListener == null) return true;
                    float x = e.getX() / Math.max(1f, box.getWidth());
                    if (videoHolder.getVisibility() != View.VISIBLE) {
                        curListener.onVideoTap(VideoCardView.this, curId);
                    } else if (x < 0.4f) {
                        curListener.onSeekBy(-10000);
                        flash("−10s");
                    } else if (x > 0.6f) {
                        curListener.onSeekBy(10000);
                        flash("+10s");
                    } else {
                        curListener.onVideoTap(VideoCardView.this, curId);
                    }
                    return true;
                }
            });
            box.setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, MotionEvent e) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                    return taps.onTouchEvent(e);
                }
            });
        }

        avatar = new ImageView(c);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        title = Ui.text(c, "", 15, true, Ui.fg);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        meta = Ui.text(c, "", 12, false, Ui.muted);
        meta.setMaxLines(2);
        meta.setEllipsize(TextUtils.TruncateAt.END);
        more = Ui.icon(c, R.drawable.ic_more, Ui.muted, 22);
        more.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(2), Ui.dp(6));
        channelName = Ui.text(c, "", 14.5f, true, Ui.fg);
        channelName.setMaxLines(1);
        channelName.setEllipsize(TextUtils.TruncateAt.END);
        subLine = Ui.text(c, "", 11.5f, false, Ui.muted);
        subLine.setMaxLines(1);
        subLine.setVisibility(View.GONE);
        subBtn = Ui.text(c, "Subscribe", 12.5f, true, 0xFFFFFFFF);
        subBtn.setPadding(Ui.dp(13), Ui.dp(6), Ui.dp(13), Ui.dp(6));
        subBtn.setVisibility(View.GONE);

        if (feed) {
            // Facebook-style post: [avatar  channel / subscribers  (Subscribe)  ⋮]  title  video  action bar
            LinearLayout head = new LinearLayout(c);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.setPadding(0, Ui.dp(4), 0, Ui.dp(8));
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(40), Ui.dp(40));
            ap.rightMargin = Ui.dp(10);
            head.addView(avatar, ap);
            LinearLayout names = new LinearLayout(c);
            names.setOrientation(VERTICAL);
            chanTap = names;
            names.addView(channelName);
            names.addView(subLine);
            head.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
            sp.leftMargin = Ui.dp(8);
            head.addView(subBtn, sp);
            head.addView(more, new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(34)));
            addView(head, new LinearLayout.LayoutParams(-1, -2));
            title.setPadding(0, 0, 0, Ui.dp(2));
            addView(title);
            meta.setPadding(0, 0, 0, Ui.dp(8));
            addView(meta);
            addView(box, new LinearLayout.LayoutParams(-1, boxH));
        } else {
            addView(box, new LinearLayout.LayoutParams(-1, boxH));
            LinearLayout row = new LinearLayout(c);
            row.setPadding(0, Ui.dp(10), 0, 0);
            row.setGravity(Gravity.TOP);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38));
            ap.rightMargin = Ui.dp(12);
            row.addView(avatar, ap);
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(VERTICAL);
            meta.setPadding(0, Ui.dp(3), 0, 0);
            col.addView(title);
            col.addView(meta);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(more, new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(34)));
            addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    // ------------------------------------------------------------------ inline video (driven by FeedPlayer)

    String videoId() { return curId; }

    boolean canAutoplay() { return feed && curId.length() == 11; }

    /** Visible part of the video area (0..1) and its centre on screen; null when it is off screen. */
    int[] visibleBox() {
        android.graphics.Rect r = new android.graphics.Rect();
        if (!box.getGlobalVisibleRect(r) || box.getHeight() <= 0) return null;
        return new int[]{r.height() * 100 / box.getHeight(), (r.top + r.bottom) / 2};
    }

    void attachVideo(TextureView tv) {
        videoHolder.removeAllViews();
        videoHolder.setAlpha(0f);
        videoHolder.setVisibility(View.VISIBLE);
        videoHolder.addView(tv, new FrameLayout.LayoutParams(boxW, boxH, Gravity.CENTER));
    }

    /** Letterbox the video inside the 16:9 area using its real aspect ratio. */
    void fitVideo(TextureView tv, float aspect) {
        if (aspect <= 0 || tv.getParent() != videoHolder) return;
        float boxAspect = boxW / (float) boxH;
        int w, h;
        if (aspect > boxAspect) { w = boxW; h = Math.round(boxW / aspect); }
        else { h = boxH; w = Math.round(boxH * aspect); }
        tv.setLayoutParams(new FrameLayout.LayoutParams(w, h, Gravity.CENTER));
    }

    void onVideoShown(boolean muted) {
        videoHolder.animate().alpha(1f).setDuration(120).start();
        muteBtn.setVisibility(View.VISIBLE);
        setLoading(false);
        updateMute(muted);
    }

    void updateMute(boolean muted) {
        muteBtn.setImageResource(muted ? R.drawable.ic_volume_off : R.drawable.ic_volume_on);
    }

    void setLoading(boolean on) {
        if (spinner != null) spinner.setVisibility(on ? View.VISIBLE : View.GONE);
    }

    void setPaused(boolean paused) {
        if (centerIcon == null) return;
        centerIcon.setImageResource(R.drawable.ic_play);
        centerIcon.setVisibility(paused ? View.VISIBLE : View.GONE);
    }

    private final Runnable hideFlash = new Runnable() {
        @Override public void run() { if (flash != null) flash.setVisibility(View.GONE); }
    };

    void flash(String text) {
        if (flash == null) return;
        flash.setText(text);
        flash.setVisibility(View.VISIBLE);
        removeCallbacks(hideFlash);
        postDelayed(hideFlash, 650);
    }

    /** Current position / length: moves the seek bar and shows "0:12 / 8:21" in the corner. */
    void setPosition(long posMs, long durMs) {
        if (seek == null || durMs <= 0) return;
        seek.setFrac(posMs / (float) durMs);
        seek.setVisibility(View.VISIBLE);
        badge.setText(Ui.duration(posMs / 1000) + " / " + Ui.duration(durMs / 1000));
        badge.setBackground(Ui.rect(0xCC000000, 6));
        badge.setVisibility(View.VISIBLE);
    }

    void clearVideo() {
        videoHolder.animate().cancel();
        videoHolder.removeAllViews();
        videoHolder.setAlpha(0f);
        videoHolder.setVisibility(View.GONE);
        muteBtn.setVisibility(View.GONE);
        if (seek != null) { seek.setVisibility(View.GONE); seek.setFrac(0f); }
        if (centerIcon != null) centerIcon.setVisibility(View.GONE);
        setLoading(false);
        applyBadge();
    }

    private void applyBadge() {
        if (curDur < 0) {
            badge.setText("● LIVE");
            badge.setBackground(Ui.rect(0xFFE5213A, 6));
            badge.setVisibility(View.VISIBLE);
        } else if (curDur > 0) {
            badge.setText(Ui.duration(curDur));
            badge.setBackground(Ui.rect(0xCC000000, 6));
            badge.setVisibility(View.VISIBLE);
        } else {
            badge.setVisibility(View.GONE);
        }
    }

    /** Thin draggable progress bar along the bottom of the video. */
    static final class SeekView extends View {
        interface Cb { void onSeek(float fraction); }
        Cb cb;
        private float frac = 0f;
        private boolean drag = false;
        private final android.graphics.Paint track = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint prog = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        SeekView(Context c) {
            super(c);
            track.setColor(0x66FFFFFF);
            prog.setColor(0xFFFF0000);
        }

        void setFrac(float f) {
            if (drag) return;
            frac = Math.max(0f, Math.min(1f, f));
            invalidate();
        }

        private float fracAt(float x) {
            float pad = Ui.dp(8);
            return Math.max(0f, Math.min(1f, (x - pad) / Math.max(1f, getWidth() - 2 * pad)));
        }

        @Override protected void onDraw(android.graphics.Canvas cv) {
            float pad = Ui.dp(8), w = getWidth() - 2 * pad;
            float cy = getHeight() - Ui.dp(8);
            float th = drag ? Ui.dp(4) : Ui.dp(2.5f);
            cv.drawRect(pad, cy - th / 2, pad + w, cy + th / 2, track);
            cv.drawRect(pad, cy - th / 2, pad + w * frac, cy + th / 2, prog);
            cv.drawCircle(pad + w * frac, cy, drag ? Ui.dp(8) : Ui.dp(5.5f), prog);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    drag = true;
                    frac = fracAt(e.getX());
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    frac = fracAt(e.getX());
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    frac = fracAt(e.getX());
                    drag = false;
                    invalidate();
                    if (cb != null) cb.onSeek(frac);
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    drag = false;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ action row

    /** A small icon with a tiny caption underneath. */
    private LinearLayout action(int icon, String label) {
        LinearLayout b = new LinearLayout(getContext());
        b.setOrientation(VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Ui.dp(7), 0, Ui.dp(6));
        b.setClickable(true);
        b.setClipChildren(false);
        b.setClipToPadding(false);
        ImageView ic = Ui.icon(getContext(), icon, Ui.muted, 18);
        b.addView(ic, new LinearLayout.LayoutParams(Ui.dp(19), Ui.dp(19)));
        TextView t = Ui.text(getContext(), label, 10f, false, Ui.muted);
        t.setPadding(0, Ui.dp(2), 0, 0);
        t.setMaxLines(1);
        b.addView(t);
        return b;
    }

    private void buildActions() {
        if (!feed || actionBar != null) return;
        View line = new View(getContext());
        line.setBackgroundColor(Ui.line);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.topMargin = Ui.dp(6);
        addView(line, lp);
        actionBar = new LinearLayout(getContext());
        likeBtn = action(R.drawable.ic_like, "Like");
        dislikeBtn = action(R.drawable.ic_dislike, "Dislike");
        LinearLayout comment = action(R.drawable.ic_comment, "Comment");
        LinearLayout dl = action(R.drawable.ic_headphones, "Background");
        LinearLayout share = action(R.drawable.ic_share, "Share");
        saveBtn = action(R.drawable.ic_save, "Save");
        View[] all = {likeBtn, dislikeBtn, comment, dl, share, saveBtn};
        for (View v : all) actionBar.addView(v, new LinearLayout.LayoutParams(0, -2, 1));
        addView(actionBar, new LinearLayout.LayoutParams(-1, -2));
    }

    private static void tint(LinearLayout b, boolean on, int icon, String label) {
        ImageView ic = (ImageView) b.getChildAt(0);
        TextView t = (TextView) b.getChildAt(1);
        int col = on ? Ui.link : Ui.muted;
        ic.setImageResource(icon);
        ic.setColorFilter(col, android.graphics.PorterDuff.Mode.SRC_IN);
        t.setTextColor(col);
        t.setText(label);
    }

    private String likeText = "", commentText = "";

    private void styleLike(int rating) {
        if (likeBtn == null) return;
        tint(likeBtn, rating == 1, R.drawable.ic_like, likeText.isEmpty() ? (rating == 1 ? "Liked" : "Like") : likeText);
        tint(dislikeBtn, rating == -1, R.drawable.ic_dislike, "Dislike");
    }

    private void styleComment() {
        if (actionBar == null) return;
        tint((LinearLayout) actionBar.getChildAt(2), false, R.drawable.ic_comment, commentText.isEmpty() ? "Comment" : commentText);
    }

    /** Like and comment numbers: from cache, otherwise fetched once per video in the background. */
    private void loadStats(final String vid) {
        likeText = ""; commentText = "";
        String[] known = STATS.get(vid);
        if (known != null) { likeText = known[0]; commentText = known[1]; return; }
        if (vid.length() != 11) return;
        synchronized (STATS_PENDING) { if (!STATS_PENDING.add(vid)) return; }
        final Context c = getContext().getApplicationContext();
        STATS_IO.execute(new Runnable() {
            @Override public void run() {
                String lk = "", cm = "";
                // only while this card still shows the video (fast scrolling drops stale work)
                if (vid.equals(curId)) {
                    try {
                        Yt.Info inf = Yt.info(vid);
                        if (inf.likes >= 0) lk = Ui.count(inf.likes);
                        else if (!inf.likesText.isEmpty()) lk = inf.likesText;
                    } catch (Exception ignored) { }
                    if (lk.isEmpty()) {
                        try {
                            Yt.Info w = Yt.webInfo(vid, Auth.nextInfo(c, vid));
                            lk = w.likesText;
                        } catch (Exception ignored) { }
                    }
                    try { cm = Comments.header(c, vid)[0]; } catch (Exception ignored) { }
                }
                final String fl = lk, fc = cm;
                synchronized (STATS_PENDING) { STATS_PENDING.remove(vid); }
                if (!fl.isEmpty() || !fc.isEmpty()) STATS.put(vid, new String[]{fl, fc});
                post(new Runnable() {
                    @Override public void run() {
                        if (!vid.equals(curId)) return;
                        likeText = fl; commentText = fc;
                        styleLike(Auth.ratingOf(getContext(), vid));
                        styleComment();
                    }
                });
            }
        });
    }

    private void styleSave(boolean on) {
        if (saveBtn == null) return;
        tint(saveBtn, on, on ? R.drawable.ic_saved : R.drawable.ic_save, on ? "Saved" : "Save");
    }

    private void styleSub(boolean on) {
        subBtn.setText(on ? "Subscribed" : "Subscribe");
        // dark button with light text (the old white one was too bright); subscribed = quieter grey text
        int fill = on ? Ui.surface : (Ui.dark ? 0xFF2A2A2A : 0xFF0F0F0F);
        subBtn.setTextColor(on ? Ui.muted : 0xFFFFFFFF);
        subBtn.setBackground(Ui.outline(fill, Ui.dark ? Ui.line : fill, 20));
    }

    /** want = 1 like, -1 dislike. Tapping the active one clears it. */
    private void rate(final String vid, final int want, final Listener l) {
        final Context c = getContext();
        if (!Auth.signedIn(c)) { l.onNeedLogin(); return; }
        final int prev = Auth.ratingOf(c, vid);
        final int next = prev == want ? 0 : want;
        final String action = next == 0 ? "removelike" : (next == 1 ? "like" : "dislike");
        Auth.saveRating(c, vid, next);
        styleLike(next);
        IO.execute(new Runnable() {
            @Override public void run() {
                try {
                    Auth.rate(c, vid, action);
                } catch (final Exception e) {
                    post(new Runnable() {
                        @Override public void run() {
                            Auth.saveRating(c, vid, prev);
                            if (vid.equals(curId)) styleLike(prev);
                            Toast.makeText(c, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void toggleSave(final String vid, final Listener l) {
        final Context c = getContext();
        if (!Auth.signedIn(c)) { l.onNeedLogin(); return; }
        final boolean prev = Auth.isSaved(c, vid);
        final boolean next = !prev;
        Auth.saveSaved(c, vid, next);
        styleSave(next);
        Toast.makeText(c, next ? "Saved to Watch later" : "Removed from Watch later", Toast.LENGTH_SHORT).show();
        IO.execute(new Runnable() {
            @Override public void run() {
                try {
                    Auth.watchLater(c, vid, next);
                } catch (final Exception e) {
                    post(new Runnable() {
                        @Override public void run() {
                            Auth.saveSaved(c, vid, prev);
                            if (vid.equals(curId)) styleSave(prev);
                            Toast.makeText(c, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void toggleSub(final String cid, final Listener l) {
        final Context c = getContext();
        if (!Auth.signedIn(c)) { l.onNeedLogin(); return; }
        final boolean prev = Auth.isSubscribed(c, cid);
        final boolean next = !prev;
        styleSub(next);
        IO.execute(new Runnable() {
            @Override public void run() {
                try {
                    Auth.subscribe(c, cid, next);
                } catch (final Exception e) {
                    post(new Runnable() {
                        @Override public void run() {
                            if (cid.equals(curChannel)) styleSub(prev);
                            Toast.makeText(c, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    /** Fills the "1.2M subscribers" line from a cache, fetching it once per channel in the background. */
    private void loadSubs(final String cid) {
        String known = SUBS.get(cid);
        if (known != null) { subLine.setText(known); subLine.setVisibility(known.isEmpty() ? View.GONE : View.VISIBLE); return; }
        subLine.setVisibility(View.GONE);
        synchronized (SUBS_PENDING) { if (!SUBS_PENDING.add(cid)) return; }
        final Context c = getContext().getApplicationContext();
        SUBS_IO.execute(new Runnable() {
            @Override public void run() {
                String txt = "";
                try { txt = Auth.channelSubs(c, cid); } catch (Exception ignored) { }
                final String fin = txt;
                synchronized (SUBS_PENDING) { SUBS_PENDING.remove(cid); }
                if (!fin.isEmpty()) SUBS.put(cid, fin);
                post(new Runnable() {
                    @Override public void run() {
                        if (cid.equals(curChannel) && !fin.isEmpty()) {
                            subLine.setText(fin);
                            subLine.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------ binding

    void bind(JSONObject it, final Listener l) {
        final String id = Yt.videoId(it.optString("url", it.optString("id", "")));
        final String t = it.optString("title", "Untitled video");
        final String a = Ui.firstNonEmpty(it.optString("uploaderName", ""), it.optString("uploader", ""),
                it.optString("author", ""));
        String th = Ui.firstNonEmpty(it.optString("thumbnail", ""), it.optString("thumb", ""));
        if (th.isEmpty() && id.length() == 11) th = "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg";
        final String thumbUrl = th;
        final String avUrl = Ui.firstNonEmpty(it.optString("uploaderAvatar", ""));

        curListener = l;
        clearVideo();
        curId = id;
        title.setText(t);
        StringBuilder m = new StringBuilder(feed ? "" : a);
        String ago = it.optString("uploadedDate", "");
        if (!ago.isEmpty() && !ago.equals("null")) { if (m.length() > 0) m.append("  ·  "); m.append(ago); }
        long v = it.optLong("views", -1);
        if (v >= 0) { if (m.length() > 0) m.append("  ·  "); m.append(Ui.count(v)).append(" views"); }
        meta.setText(m.toString());

        long d = it.optLong("duration", 0);
        live = d < 0;
        curDur = d;
        applyBadge();

        Glide.with(thumb).load(thumbUrl).override(640, 360).centerCrop()
                .placeholder(new ColorDrawable(Ui.surface2))
                .transition(DrawableTransitionOptions.withCrossFade(120)).into(thumb);

        final String chId = Yt.channelId(it.optString("uploaderUrl", ""));
        curChannel = chId;
        String av = it.optString("uploaderAvatar", "");
        if (av.equals("null")) av = "";
        if (!chId.isEmpty()) {
            if (!av.isEmpty()) AVATARS.put(chId, av);
            else if (AVATARS.containsKey(chId)) av = AVATARS.get(chId);
        }
        avatar.setBackground(Ui.oval(Ui.surface2));
        if (!av.isEmpty()) {
            Glide.with(avatar).load(av).override(96, 96).circleCrop().into(avatar);
        } else {
            Glide.with(avatar).clear(avatar);
            avatar.setImageDrawable(null);
            avatar.setBackground(Ui.gradientOval());
        }

        if (feed) {
            channelName.setText(a);
            if (!chId.isEmpty()) {
                subBtn.setVisibility(View.VISIBLE);
                styleSub(Auth.isSubscribed(getContext(), chId));
                subBtn.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View view) { toggleSub(chId, l); }
                });
                loadSubs(chId);
            } else {
                subBtn.setVisibility(View.GONE);
                subLine.setVisibility(View.GONE);
            }
            buildActions();
            loadStats(id);
            styleComment();
            styleLike(Auth.ratingOf(getContext(), id));
            styleSave(Auth.isSaved(getContext(), id));
            likeBtn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { rate(id, 1, l); }
            });
            dislikeBtn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { rate(id, -1, l); }
            });
            actionBar.getChildAt(2).setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { l.onComment(id); }
            });
            actionBar.getChildAt(3).setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { l.onOpen(id, t, a, thumbUrl, avUrl, true); }
            });
            final String chName = a;
            final String chAvatar = av;
            chanTap.setOnClickListener(!chId.isEmpty() ? new View.OnClickListener() {
                @Override public void onClick(View view) { l.onChannel(chId, chName, chAvatar); }
            } : null);
            avatar.setOnClickListener(!chId.isEmpty() ? new View.OnClickListener() {
                @Override public void onClick(View view) { l.onChannel(chId, chName, chAvatar); }
            } : null);
            actionBar.getChildAt(4).setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, t + "\n" + "https://youtu.be/" + id);
                    getContext().startActivity(Intent.createChooser(i, "Share"));
                }
            });
            saveBtn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { toggleSave(id, l); }
            });
            muteBtn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { l.onMuteToggle(); }
            });
        }

        if (!feed) {
            setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { l.onOpen(id, t, a, thumbUrl, avUrl, false); }
            });
        }
        more.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                PopupMenu pm = new PopupMenu(getContext(), view);
                pm.getMenu().add(0, 1, 0, "Play in background");
                if (feed) pm.getMenu().add(0, 5, 1, "Open full player");
                pm.getMenu().add(0, 4, 1, "Download");
                pm.getMenu().add(0, 2, 2, "Share");
                pm.getMenu().add(0, 3, 3, "Copy link");
                pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override public boolean onMenuItemClick(android.view.MenuItem mi) {
                        String link = "https://youtu.be/" + id;
                        if (mi.getItemId() == 1) {
                            l.onOpen(id, t, a, thumbUrl, avUrl, true);
                        } else if (mi.getItemId() == 5) {
                            l.onOpen(id, t, a, thumbUrl, avUrl, false);
                        } else if (mi.getItemId() == 4) {
                            l.onDownload(id, t);
                        } else if (mi.getItemId() == 2) {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("text/plain");
                            i.putExtra(Intent.EXTRA_TEXT, t + "\n" + link);
                            getContext().startActivity(Intent.createChooser(i, "Share"));
                        } else {
                            ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", link));
                            Toast.makeText(getContext(), "Link copied", Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    }
                });
                pm.show();
            }
        });
    }
}
