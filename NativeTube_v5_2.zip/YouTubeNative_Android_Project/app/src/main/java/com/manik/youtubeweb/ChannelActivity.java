package com.manik.youtubeweb;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A channel's own page: logo, name, subscribers, Subscribe button and all its videos (newest first). */
public class ChannelActivity extends Activity implements VideoCardView.Listener {
    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    private String channelId = "", name = "", avatarUrl = "";
    private Yt.Chan chan;
    private boolean loading = false, subscribed = false, failed = false;
    private org.schabi.newpipe.extractor.Page nextPage;

    private final List<JSONObject> videos = new ArrayList<>();
    private RecyclerView rv;
    private LinearLayoutManager lm;
    private Adapter adapter;

    private TextView nameV, subsV, subBtn, descV, topTitle;
    private ImageView avatarV;
    private View header;
    private ProgressBar spinner;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        Yt.init(Ui.prefs(this).getString("region", "US"));
        Net.setCookie(Auth.cookie(this));
        channelId = nz(getIntent().getStringExtra("channel_id"));
        name = nz(getIntent().getStringExtra("name"));
        avatarUrl = nz(getIntent().getStringExtra("avatar"));
        subscribed = Auth.isSubscribed(this, channelId);

        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        if (!Ui.dark) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        // top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(12), Ui.dp(4));
        ImageView back = Ui.icon(this, R.drawable.ic_back, Ui.fg, 24);
        back.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        topTitle = Ui.text(this, name, 17, true, Ui.fg);
        topTitle.setMaxLines(1);
        topTitle.setEllipsize(TextUtils.TruncateAt.END);
        bar.addView(topTitle, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        header = buildHeader();
        adapter = new Adapter();
        rv = new RecyclerView(this);
        lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);
        rv.setAdapter(adapter);
        rv.setItemAnimator(null);
        rv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView r, int dx, int dy) {
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 4) loadMore();
            }
        });
        root.addView(rv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        bindHeader();
        loadFirst();
    }

    @Override protected void onDestroy() {
        pool.shutdownNow();
        super.onDestroy();
    }

    private static String nz(String s) { return s == null ? "" : s; }

    // ------------------------------------------------------------------ header

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        h.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(12));
        h.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));

        avatarV = new ImageView(this);
        avatarV.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarV.setBackground(Ui.gradientOval());
        h.addView(avatarV, new LinearLayout.LayoutParams(Ui.dp(76), Ui.dp(76)));

        nameV = Ui.text(this, name, 21, true, Ui.fg);
        nameV.setGravity(Gravity.CENTER);
        nameV.setPadding(0, Ui.dp(10), 0, 0);
        h.addView(nameV);

        subsV = Ui.text(this, "", 12.5f, false, Ui.muted);
        subsV.setGravity(Gravity.CENTER);
        subsV.setPadding(0, Ui.dp(3), 0, Ui.dp(10));
        h.addView(subsV);

        subBtn = Ui.text(this, "Subscribe", 13.5f, true, 0xFFFFFFFF);
        subBtn.setPadding(Ui.dp(26), Ui.dp(9), Ui.dp(26), Ui.dp(9));
        subBtn.setOnClickListener(v -> toggleSubscribe());
        h.addView(subBtn);

        descV = Ui.text(this, "", 12.5f, false, Ui.muted);
        descV.setMaxLines(3);
        descV.setEllipsize(TextUtils.TruncateAt.END);
        descV.setGravity(Gravity.CENTER);
        descV.setPadding(0, Ui.dp(12), 0, 0);
        descV.setVisibility(View.GONE);
        h.addView(descV);

        View line = new View(this);
        line.setBackgroundColor(Ui.line);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.topMargin = Ui.dp(14);
        h.addView(line, lp);
        TextView vt = Ui.text(this, "Videos", 14, true, Ui.fg);
        vt.setPadding(0, Ui.dp(12), 0, 0);
        vt.setGravity(Gravity.START);
        h.addView(vt, new LinearLayout.LayoutParams(-1, -2));
        return h;
    }

    private void bindHeader() {
        nameV.setText(name);
        topTitle.setText(name);
        if (!avatarUrl.isEmpty()) Glide.with(avatarV).load(avatarUrl).override(240, 240).circleCrop().into(avatarV);
        if (chan != null) {
            if (chan.subs >= 0) subsV.setText(Ui.count(chan.subs) + " subscribers");
            if (!chan.desc.isEmpty()) { descV.setText(chan.desc); descV.setVisibility(View.VISIBLE); }
        }
        styleSub();
    }

    private void styleSub() {
        subBtn.setText(subscribed ? "Subscribed" : "Subscribe");
        subBtn.setTextColor(subscribed ? Ui.muted : 0xFFFFFFFF);
        int fill = subscribed ? Ui.surface : (Ui.dark ? 0xFF2A2A2A : 0xFF0F0F0F);
        subBtn.setBackground(Ui.outline(fill, Ui.dark ? Ui.line : fill, 20));
        subBtn.setVisibility(channelId.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void toggleSubscribe() {
        if (!Auth.signedIn(this)) { onNeedLogin(); return; }
        final boolean want = !subscribed;
        subscribed = want;
        styleSub();
        pool.execute(() -> {
            try { Auth.subscribe(this, channelId, want); }
            catch (final Exception e) {
                runOnUiThread(() -> {
                    subscribed = !want;
                    styleSub();
                    Toast.makeText(this, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ------------------------------------------------------------------ loading

    private void loadFirst() {
        if (channelId.isEmpty()) { failed = true; adapter.notifyDataSetChanged(); return; }
        loading = true;
        pool.execute(() -> {
            Yt.Chan c = null;
            String err = null;
            try { c = Yt.channel(channelId); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
            final Yt.Chan fc = c;
            final String fe = err;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                loading = false;
                if (fc == null) {
                    failed = true;
                    Toast.makeText(this, "Couldn't load channel: " + fe, Toast.LENGTH_LONG).show();
                } else {
                    chan = fc;
                    if (!fc.name.isEmpty()) name = fc.name;
                    if (!fc.avatar.isEmpty()) avatarUrl = fc.avatar;
                    nextPage = fc.next;
                    for (int i = 0; i < fc.items.length(); i++) {
                        JSONObject o = fc.items.optJSONObject(i);
                        if (o != null) videos.add(o);
                    }
                    bindHeader();
                }
                adapter.notifyDataSetChanged();
            });
        });
    }

    private void loadMore() {
        if (loading || chan == null || nextPage == null || chan.tab == null) return;
        loading = true;
        final Yt.Chan c = chan;
        final org.schabi.newpipe.extractor.Page token = nextPage;
        pool.execute(() -> {
            Yt.Page p = null;
            try { p = Yt.channelMore(c, token); } catch (Exception ignored) { }
            final Yt.Page fp = p;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                loading = false;
                if (fp == null) { nextPage = null; adapter.notifyDataSetChanged(); return; }
                int from = videos.size();
                java.util.Set<String> seen = new java.util.HashSet<>();
                for (JSONObject o : videos) seen.add(Yt.videoId(o.optString("url", "")));
                for (JSONObject o : Yt.playable(fp.items, seen)) videos.add(o);
                nextPage = fp.next;
                adapter.notifyItemRangeInserted(from + 1, videos.size() - from);
                adapter.notifyItemChanged(videos.size() + 1);
            });
        });
    }

    // ------------------------------------------------------------------ list

    private final class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemCount() { return 2 + videos.size(); }

        @Override public int getItemViewType(int p) { return p == 0 ? 0 : (p <= videos.size() ? 1 : 2); }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) {
            View v;
            if (type == 0) {
                if (header.getParent() instanceof ViewGroup) ((ViewGroup) header.getParent()).removeView(header);
                v = header;
            } else if (type == 1) {
                v = new VideoCardView(ChannelActivity.this);
                v.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            } else {
                FrameLayoutHolder f = new FrameLayoutHolder(ChannelActivity.this);
                v = f;
            }
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int p) {
            int type = getItemViewType(p);
            if (type == 1) {
                ((VideoCardView) h.itemView).bind(videos.get(p - 1), ChannelActivity.this);
            } else if (type == 2) {
                ((FrameLayoutHolder) h.itemView).show(loading || nextPage != null,
                    failed ? "Couldn't load this channel. Go back and try again." : (videos.isEmpty() && !loading ? "No videos found" : ""));
            }
        }
    }

    /** Bottom row: spinner while more videos load, or a short message. */
    private static final class FrameLayoutHolder extends LinearLayout {
        private final ProgressBar bar;
        private final TextView msg;

        FrameLayoutHolder(android.content.Context c) {
            super(c);
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
            setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            setPadding(0, Ui.dp(18), 0, Ui.dp(28));
            bar = new ProgressBar(c);
            addView(bar, new LinearLayout.LayoutParams(Ui.dp(26), Ui.dp(26)));
            msg = Ui.text(c, "", 13, false, Ui.muted);
            msg.setGravity(Gravity.CENTER);
            addView(msg);
        }

        void show(boolean spin, String text) {
            bar.setVisibility(spin ? View.VISIBLE : View.GONE);
            msg.setText(text);
            msg.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    // ------------------------------------------------------------------ card callbacks (plain video rows)

    @Override public void onOpen(String id, String title, String author, String thumb, String av, boolean audio) {
        if (id == null || id.isEmpty()) return;
        Ui.saveHistory(this, id, title, author, thumb);
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", title);
        in.putExtra("uploader", author);
        in.putExtra("thumbnail", thumb);
        in.putExtra("avatar", av);
        if (audio) in.putExtra("start_audio", true);
        startActivity(in);
    }

    @Override public void onDownload(String id, String title) { Downloads.start(this, id, title); }

    @Override public void onNeedLogin() {
        new android.app.AlertDialog.Builder(this,
                Ui.dark ? android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK : android.app.AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Sign in required")
            .setMessage("Open the You tab on the home screen and sign in with Google to subscribe.")
            .setPositiveButton("OK", null)
            .show();
    }
}
