package com.manik.youtubeweb;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

/** Shared list of running downloads (read by the Downloads screen) and the saved list of finished ones. */
final class DlStore {
    static final int QUEUED = 0, RUNNING = 1, SAVING = 2, FAILED = 3;

    static final class Task {
        final long id;
        String name = "", title = "", vid = "", tag = "", mime = "", u1 = "", u2 = "";
        int kind;
        volatile int state = QUEUED;
        volatile int pct;
        volatile long bytes, total, speed, size;
        volatile boolean cancel;
        volatile String err = "";
        Task(long id) { this.id = id; }
        boolean active() { return state == QUEUED || state == RUNNING || state == SAVING; }
    }

    static final class Done {
        String title = "", name = "", vid = "", uri = "", mime = "", tag = "";
        long size, time;
        boolean video = true;
    }

    static final List<Task> TASKS = new CopyOnWriteArrayList<>();
    private static final AtomicLong IDS = new AtomicLong(1);

    private DlStore() {}

    static Task add() {
        Task t = new Task(IDS.getAndIncrement());
        TASKS.add(t);
        return t;
    }

    static int activeCount() {
        int n = 0;
        for (Task t : TASKS) if (t.active()) n++;
        return n;
    }

    // ------------------------------------------------------------------ finished downloads (saved in settings)

    private static final String KEY = "dl_done";

    static synchronized List<Done> loadDone(Context c) {
        List<Done> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Ui.prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                Done d = new Done();
                d.title = o.optString("title");
                d.name = o.optString("name");
                d.vid = o.optString("vid");
                d.uri = o.optString("uri");
                d.mime = o.optString("mime");
                d.tag = o.optString("tag");
                d.size = o.optLong("size");
                d.time = o.optLong("time");
                d.video = o.optBoolean("video", true);
                if (!d.uri.isEmpty()) out.add(d);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static void save(Context c, List<Done> l) {
        JSONArray a = new JSONArray();
        try {
            for (Done d : l) {
                JSONObject o = new JSONObject();
                o.put("title", d.title).put("name", d.name).put("vid", d.vid).put("uri", d.uri).put("mime", d.mime)
                    .put("tag", d.tag).put("size", d.size).put("time", d.time).put("video", d.video);
                a.put(o);
            }
        } catch (Exception ignored) { }
        SharedPreferences.Editor e = Ui.prefs(c).edit();
        e.putString(KEY, a.toString()).apply();
    }

    static synchronized void addDone(Context c, Done d) {
        List<Done> l = loadDone(c);
        l.add(0, d);
        save(c, l);
    }

    static synchronized void removeDone(Context c, String uri) {
        List<Done> l = loadDone(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).uri.equals(uri)) { l.remove(i); break; }
        save(c, l);
    }

    static int doneCount(Context c) { return loadDone(c).size(); }
}
