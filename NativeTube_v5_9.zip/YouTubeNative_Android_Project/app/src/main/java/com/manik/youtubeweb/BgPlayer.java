package com.manik.youtubeweb;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * "Background" button on a video card: plays only the sound, right away, without opening the video page.
 * The audio lives in the same PlaybackService as the full player (notification, lock-screen controls, mini player).
 */
final class BgPlayer {
    private BgPlayer() {}

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static ListenableFuture<MediaController> future;
    private static MediaController controller;
    private static int gen = 0;
    private static volatile long startPos = 0L;

    private static final class Cand {
        final String url;
        final boolean post;
        Cand(String url, boolean post) { this.url = url; this.post = post; }
    }

    /** Keeps a controller connected so the playback service shows its notification / lock-screen controls. */
    private static void connect(final Context app) {
        if (controller != null && controller.isConnected()) return;
        if (future != null && !future.isDone()) return;
        try {
            SessionToken token = new SessionToken(app, new ComponentName(app, PlaybackService.class));
            future = new MediaController.Builder(app, token).buildAsync();
            future.addListener(new Runnable() {
                @Override public void run() {
                    try { controller = future.get(); } catch (Exception e) { controller = null; }
                }
            }, ContextCompat.getMainExecutor(app));
        } catch (Exception ignored) { }
    }

    static void start(Context ctx, String id, String title, String author,
                      String thumb, String avatar, Runnable onStarted) {
        start(ctx, id, title, author, thumb, avatar, 0L, onStarted);
    }

    /** Starts the sound from startMs, so it continues exactly where the video on the card was. */
    static void start(final Context ctx, final String id, final String title, final String author,
                      final String thumb, final String avatar, final long startMs, final Runnable onStarted) {
        final Context app = ctx.getApplicationContext();
        startPos = Math.max(0L, startMs);
        final int g = ++gen;
        PlaybackService.curId = id;
        PlaybackService.curTitle = title;
        PlaybackService.curUploader = author;
        PlaybackService.curThumb = thumb;
        PlaybackService.curAvatar = avatar;
        PlaybackService.curAudio = true;
        PlaybackService.bgAllowed = true;
        try { app.startService(new Intent(app, PlaybackService.class)); } catch (Exception ignored) { }
        connect(app);
        IO.execute(new Runnable() {
            @Override public void run() {
                final List<Cand> cands = new ArrayList<>();
                try {
                    Yt.Info info = Yt.info(id);
                    List<Yt.AS> a = new ArrayList<>(info.audio);
                    Collections.sort(a, new Comparator<Yt.AS>() {
                        @Override public int compare(Yt.AS x, Yt.AS y) {
                            boolean xm = "m4a".equals(x.suffix), ym = "m4a".equals(y.suffix);
                            if (xm != ym) return xm ? -1 : 1;
                            return Integer.compare(y.bitrate, x.bitrate);
                        }
                    });
                    for (Yt.AS s : a) { cands.add(new Cand(s.url, false)); cands.add(new Cand(s.url, true)); }
                    // single-file video streams also carry sound: last resort
                    for (Yt.VS v : info.muxed) { cands.add(new Cand(v.url, false)); cands.add(new Cand(v.url, true)); }
                } catch (Exception ignored) { }
                MAIN.post(new Runnable() {
                    @Override public void run() {
                        if (g != gen) return;
                        if (cands.isEmpty()) { fail(app); return; }
                        waitForPlayer(app, g, id, title, author, thumb, cands, onStarted, 0);
                    }
                });
            }
        });
    }

    private static void fail(Context app) {
        Toast.makeText(app, "Couldn't start background play", Toast.LENGTH_LONG).show();
        PlaybackService.clearCurrent();
    }

    /** The service creates its player a moment after it is started. */
    private static void waitForPlayer(final Context app, final int g, final String id, final String title,
                                      final String author, final String thumb, final List<Cand> cands,
                                      final Runnable onStarted, final int tries) {
        if (g != gen) return;
        final ExoPlayer exo = PlaybackService.exo;
        if (exo == null) {
            if (tries > 30) { fail(app); return; }
            MAIN.postDelayed(new Runnable() {
                @Override public void run() {
                    waitForPlayer(app, g, id, title, author, thumb, cands, onStarted, tries + 1);
                }
            }, 150);
            return;
        }
        final int[] idx = {0};
        final Player.Listener[] holder = new Player.Listener[1];
        holder[0] = new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    exo.removeListener(holder[0]);
                    if (onStarted != null) onStarted.run();
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                if (g != gen) { exo.removeListener(holder[0]); return; }
                idx[0]++;
                if (idx[0] >= cands.size()) { exo.removeListener(holder[0]); fail(app); return; }
                play(app, exo, cands.get(idx[0]), id, title, author, thumb);
            }
        };
        try { exo.stop(); } catch (Exception ignored) { }
        exo.addListener(holder[0]);
        play(app, exo, cands.get(0), id, title, author, thumb);
        if (onStarted != null) onStarted.run();
    }

    private static void play(Context app, ExoPlayer exo, Cand c, String id, String title, String author, String thumb) {
        try {
            Net.postMode = c.post;
            MediaMetadata.Builder md = new MediaMetadata.Builder().setTitle(title).setArtist(author);
            if (thumb != null && !thumb.isEmpty()) md.setArtworkUri(Uri.parse(thumb));
            MediaItem item = new MediaItem.Builder().setUri(c.url).setMediaId(String.valueOf(id))
                .setMediaMetadata(md.build()).build();
            androidx.media3.exoplayer.source.MediaSource src =
                new ProgressiveMediaSource.Factory(Net.dataSourceFactory(app)).createMediaSource(item);
            if (startPos > 0) exo.setMediaSource(src, startPos);
            else exo.setMediaSource(src);
            exo.prepare();
            exo.setPlayWhenReady(true);
        } catch (Exception e) {
            Toast.makeText(app, "Couldn't start background play", Toast.LENGTH_LONG).show();
        }
    }
}
