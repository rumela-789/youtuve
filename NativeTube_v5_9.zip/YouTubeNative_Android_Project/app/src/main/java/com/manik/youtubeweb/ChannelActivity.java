package com.manik.youtubeweb;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A channel's own page: logo, name, subscribers, a centred Subscribe button, an "Auto play" switch (off by default)
 * and all its videos (newest first). The videos are the same cards as on the home page: tap one to play it right
 * there, or switch Auto play on and the video on screen plays by itself while you scroll.
 */
public class ChannelActivity extends Activity implements VideoCardView.Listener {
    private static final int RC_LOGIN = 41;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private FeedPlayer feedPlayer;
    private Switch autoplaySw;
    private boolean autoplay = false, resumed = false;
    private final Runnable autoplayRun = new Runnable() { @Override public void run() { updateAutoplay(); } };

    private String channelId = "", name = "", avatarUrl = "";
    private Yt.Chan chan;
    private boolean loading = false, subscribed = false, failed = false;
    private org.schabi.newpipe.extractor.Page nextPage;

    private final List<JSONObject> videos = new ArrayList<>();
    private RecyclerView rv;
    private LinearLayoutManager lm;
    private Adapter adapter;

    private TextView nameV, subsV, subBtn, descV, topTitle;
    private ImageView avatarV;
    private View header;
    private ProgressBar spinner;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        Yt.init(Ui.prefs(this).getString("region", "BD"));
        Net.setCookie(Auth.cookie(this));
        channelId = nz(getIntent().getStringExtra("channel_id"));
        name = nz(getIntent().getStringExtra("name"));
        avatarUrl = nz(getIntent().getStringExtra("avatar"));
        subscribed = Auth.isSubscribed(this, channelId);
        feedPlayer = new FeedPlayer(this);
        autoplay = Ui.prefs(this).getBoolean("channel_autoplay", false);      // off until the person turns it on

        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        if (!Ui.dark) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        // top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(12), Ui.dp(4));
        ImageView back = Ui.icon(this, R.drawable.ic_back, Ui.fg, 24);
        back.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        topTitle = Ui.text(this, name, 17, true, Ui.fg);
        topTitle.setMaxLines(1);
        topTitle.setEllipsize(TextUtils.TruncateAt.END);
        bar.addView(topTitle, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        header = buildHeader();
        adapter = new Adapter();
        rv = new RecyclerView(this);
        lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);
        rv.setAdapter(adapter);
        rv.setItemAnimator(null);
        rv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrollStateChanged(RecyclerView r, int state) {
                if (state == RecyclerView.SCROLL_STATE_IDLE) scheduleAutoplay(40);
            }
            @Override public void onScrolled(RecyclerView r, int dx, int dy) {
                if (dy != 0) scheduleAutoplay(180);
                if (dy > 0 && lm.findLastVisibleItemPosition() >= adapter.getItemCount() - 4) loadMore();
            }
        });
        root.addView(rv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        bindHeader();
        loadFirst();
    }

    @Override protected void onStart() {
        super.onStart();
        PlaybackService.activityStarted();
    }

    @Override protected void onStop() {
        PlaybackService.activityStopped();
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        scheduleAutoplay(250);
    }

    @Override protected void onPause() {
        resumed = false;
        if (rv != null) rv.removeCallbacks(autoplayRun);
        feedPlayer.release();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (feedPlayer != null) feedPlayer.release();
        pool.shutdownNow();
        super.onDestroy();
    }

    private static String nz(String s) { return s == null ? "" : s; }

    // ------------------------------------------------------------------ header

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        h.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(12));
        h.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));

        avatarV = new ImageView(this);
        avatarV.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarV.setBackground(Ui.gradientOval());
        h.addView(avatarV, new LinearLayout.LayoutParams(Ui.dp(76), Ui.dp(76)));

        nameV = Ui.text(this, name, 21, true, Ui.fg);
        nameV.setGravity(Gravity.CENTER);
        nameV.setPadding(0, Ui.dp(10), 0, 0);
        h.addView(nameV);

        subsV = Ui.text(this, "", 12.5f, false, Ui.muted);
        subsV.setGravity(Gravity.CENTER);
        subsV.setPadding(0, Ui.dp(3), 0, Ui.dp(10));
        h.addView(subsV);

        subBtn = Ui.text(this, "Subscribe", 14, true, 0xFFFFFFFF);
        subBtn.setGravity(Gravity.CENTER);
        subBtn.setOnClickListener(v -> toggleSubscribe());
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(Ui.dp(210), Ui.dp(42));
        sbp.gravity = Gravity.CENTER_HORIZONTAL;
        h.addView(subBtn, sbp);

        // Auto play: videos on this channel play by themselves while scrolling (like the home page). Off by default.
        LinearLayout apRow = new LinearLayout(this);
        apRow.setGravity(Gravity.CENTER_VERTICAL);
        apRow.setPadding(Ui.dp(18), Ui.dp(4), Ui.dp(12), Ui.dp(4));
        apRow.setBackground(Ui.rect(Ui.surface, 22));
        apRow.addView(Ui.text(this, "Auto play", 14, true, Ui.fg), new LinearLayout.LayoutParams(0, -2, 1));
        autoplaySw = new Switch(this);
        int[][] sw = {{android.R.attr.state_checked}, {}};
        autoplaySw.setThumbTintList(new ColorStateList(sw, new int[]{0xFFFFFFFF, 0xFFBDBDBD}));
        autoplaySw.setTrackTintList(new ColorStateList(sw, new int[]{Ui.link, 0xFF606060}));
        autoplaySw.setChecked(autoplay);
        autoplaySw.setOnCheckedChangeListener((b, on) -> {
            autoplay = on;
            Ui.prefs(this).edit().putBoolean("channel_autoplay", on).apply();
            if (!on) feedPlayer.stop();
            scheduleAutoplay(100);
        });
        apRow.addView(autoplaySw);
        LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(Ui.dp(210), -2);
        apLp.gravity = Gravity.CENTER_HORIZONTAL;
        apLp.topMargin = Ui.dp(10);
        h.addView(apRow, apLp);

        descV = Ui.text(this, "", 12.5f, false, Ui.muted);
        descV.setMaxLines(3);
        descV.setEllipsize(TextUtils.TruncateAt.END);
        descV.setGravity(Gravity.CENTER);
        descV.setPadding(0, Ui.dp(12), 0, 0);
        descV.setVisibility(View.GONE);
        h.addView(descV);

        View line = new View(this);
        line.setBackgroundColor(Ui.line);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.topMargin = Ui.dp(14);
        h.addView(line, lp);
        TextView vt = Ui.text(this, "Videos", 14, true, Ui.fg);
        vt.setPadding(0, Ui.dp(12), 0, 0);
        vt.setGravity(Gravity.START);
        h.addView(vt, new LinearLayout.LayoutParams(-1, -2));
        return h;
    }

    private void bindHeader() {
        nameV.setText(name);
        topTitle.setText(name);
        if (!avatarUrl.isEmpty()) Glide.with(avatarV).load(avatarUrl).override(240, 240).circleCrop().into(avatarV);
        if (chan != null) {
            if (chan.subs >= 0) subsV.setText(Ui.count(chan.subs) + " subscribers");
            if (!chan.desc.isEmpty()) { descV.setText(chan.desc); descV.setVisibility(View.VISIBLE); }
        }
        styleSub();
    }

    private void styleSub() {
        subBtn.setText(subscribed ? "Subscribed" : "Subscribe");
        subBtn.setTextColor(subscribed ? Ui.muted : 0xFFFFFFFF);
        int fill = subscribed ? Ui.surface : (Ui.dark ? 0xFF2A2A2A : 0xFF0F0F0F);
        subBtn.setBackground(Ui.outline(fill, Ui.dark ? Ui.line : fill, 20));
        subBtn.setVisibility(channelId.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void toggleSubscribe() {
        if (!Auth.signedIn(this)) { onNeedLogin(); return; }
        final boolean want = !subscribed;
        subscribed = want;
        styleSub();
        pool.execute(() -> {
            try { Auth.subscribe(this, channelId, want); }
            catch (final Exception e) {
                runOnUiThread(() -> {
                    subscribed = !want;
                    styleSub();
                    Toast.makeText(this, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ------------------------------------------------------------------ loading

    private void loadFirst() {
        if (channelId.isEmpty()) { failed = true; adapter.notifyDataSetChanged(); return; }
        loading = true;
        pool.execute(() -> {
            Yt.Chan c = null;
            String err = null;
            try { c = Yt.channel(channelId); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
            final Yt.Chan fc = c;
            final String fe = err;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                loading = false;
                if (fc == null) {
                    failed = true;
                    Toast.makeText(this, "Couldn't load channel: " + fe, Toast.LENGTH_LONG).show();
                } else {
                    chan = fc;
                    if (!fc.name.isEmpty()) name = fc.name;
                    if (!fc.avatar.isEmpty()) avatarUrl = fc.avatar;
                    nextPage = fc.next;
                    for (int i = 0; i < fc.items.length(); i++) {
                        JSONObject o = fc.items.optJSONObject(i);
                        if (o != null) videos.add(o);
                    }
                    bindHeader();
                }
                adapter.notifyDataSetChanged();
                scheduleAutoplay(300);
            });
        });
    }

    private void loadMore() {
        if (loading || chan == null || nextPage == null || chan.tab == null) return;
        loading = true;
        final Yt.Chan c = chan;
        final org.schabi.newpipe.extractor.Page token = nextPage;
        pool.execute(() -> {
            Yt.Page p = null;
            try { p = Yt.channelMore(c, token); } catch (Exception ignored) { }
            final Yt.Page fp = p;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                loading = false;
                if (fp == null) { nextPage = null; adapter.notifyDataSetChanged(); return; }
                int from = videos.size();
                java.util.Set<String> seen = new java.util.HashSet<>();
                for (JSONObject o : videos) seen.add(Yt.videoId(o.optString("url", "")));
                for (JSONObject o : Yt.playable(fp.items, seen)) videos.add(o);
                nextPage = fp.next;
                adapter.notifyItemRangeInserted(from + 1, videos.size() - from);
                adapter.notifyItemChanged(videos.size() + 1);
                scheduleAutoplay(200);
            });
        });
    }

    // ------------------------------------------------------------------ list

    private final class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemCount() { return 2 + videos.size(); }

        @Override public int getItemViewType(int p) { return p == 0 ? 0 : (p <= videos.size() ? 1 : 2); }

        @Override public void onViewDetachedFromWindow(RecyclerView.ViewHolder h) {
            if (h.itemView instanceof VideoCardView) feedPlayer.stopIfHost((VideoCardView) h.itemView);
        }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) {
            View v;
            if (type == 0) {
                if (header.getParent() instanceof ViewGroup) ((ViewGroup) header.getParent()).removeView(header);
                v = header;
            } else if (type == 1) {
                v = new VideoCardView(ChannelActivity.this, true);
                v.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            } else {
                FrameLayoutHolder f = new FrameLayoutHolder(ChannelActivity.this);
                v = f;
            }
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int p) {
            int type = getItemViewType(p);
            if (type == 1) {
                feedPlayer.stopIfHost((VideoCardView) h.itemView);
                ((VideoCardView) h.itemView).bind(videos.get(p - 1), ChannelActivity.this);
            } else if (type == 2) {
                ((FrameLayoutHolder) h.itemView).show(loading || nextPage != null,
                    failed ? "Couldn't load this channel. Go back and try again." : (videos.isEmpty() && !loading ? "No videos found" : ""));
            }
        }
    }

    /** Bottom row: spinner while more videos load, or a short message. */
    private static final class FrameLayoutHolder extends LinearLayout {
        private final ProgressBar bar;
        private final TextView msg;

        FrameLayoutHolder(android.content.Context c) {
            super(c);
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
            setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            setPadding(0, Ui.dp(18), 0, Ui.dp(28));
            bar = new ProgressBar(c);
            addView(bar, new LinearLayout.LayoutParams(Ui.dp(26), Ui.dp(26)));
            msg = Ui.text(c, "", 13, false, Ui.muted);
            msg.setGravity(Gravity.CENTER);
            addView(msg);
        }

        void show(boolean spin, String text) {
            bar.setVisibility(spin ? View.VISIBLE : View.GONE);
            msg.setText(text);
            msg.setVisibility(text.isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    // ------------------------------------------------------------------ autoplay (same behaviour as the home page)

    private void scheduleAutoplay(long delay) {
        if (rv == null) return;
        rv.removeCallbacks(autoplayRun);
        rv.postDelayed(autoplayRun, delay);
    }

    private boolean autoplayAllowed() {
        if (!autoplay) return false;
        ExoPlayer e = PlaybackService.exo;
        if (e != null && e.getPlayWhenReady() && e.getPlaybackState() != Player.STATE_IDLE
                && e.getPlaybackState() != Player.STATE_ENDED) return false;     // background sound is playing
        return true;
    }

    private void updateAutoplay() {
        if (!resumed) { feedPlayer.stop(); return; }
        int first = lm.findFirstVisibleItemPosition(), last = lm.findLastVisibleItemPosition();
        if (autoplay && first >= 0) {
            for (int p = Math.max(1, last - 1); p <= last + 3 && p <= videos.size(); p++)
                feedPlayer.prefetch(Yt.videoId(videos.get(p - 1).optString("url", "")));
        }
        // a video the person started by tapping keeps playing while it is still mostly on screen
        VideoCardView held = feedPlayer.host();
        if (feedPlayer.isManual() && held != null) {
            int[] hb = held.visibleBox();
            if (hb != null && hb[0] >= 35) return;
        }
        if (!autoplayAllowed()) { feedPlayer.stop(); return; }
        if (first < 0) return;
        android.graphics.Rect rr = new android.graphics.Rect();
        if (!rv.getGlobalVisibleRect(rr)) return;
        int mid = (rr.top + rr.bottom) / 2;
        VideoCardView best = null;
        int bestDist = Integer.MAX_VALUE;
        for (int p = first; p <= last; p++) {
            View v = lm.findViewByPosition(p);
            if (!(v instanceof VideoCardView)) continue;
            VideoCardView c = (VideoCardView) v;
            if (!c.canAutoplay()) continue;
            int[] vb = c.visibleBox();
            if (vb == null || vb[0] < 50) continue;
            int dist = Math.abs(vb[1] - mid);
            if (dist < bestDist) { bestDist = dist; best = c; }
        }
        if (best == null) { feedPlayer.stop(); return; }
        feedPlayer.play(best, best.videoId());
    }

    // ------------------------------------------------------------------ card callbacks

    @Override public void onVideoTap(VideoCardView card, String id) {
        if (card == feedPlayer.host()) feedPlayer.togglePause();
        else feedPlayer.playManual(card, id);
    }

    @Override public void onSeekBy(long deltaMs) { feedPlayer.seekBy(deltaMs); }

    @Override public void onSeekTo(float fraction) { feedPlayer.seekToFraction(fraction); }

    @Override public void onMuteToggle() { feedPlayer.toggleMute(); }

    @Override public void onComment(String id) {
        CommentSheet.show(this, id, this::onNeedLogin);
    }

    @Override public void onQuality(VideoCardView card, String id, int height) {
        feedPlayer.setQuality(card, id, height);
    }

    @Override public int currentQuality(String id) {
        return id != null && id.equals(feedPlayer.currentId()) ? feedPlayer.quality() : 0;
    }

    /** Background button: only the sound plays; the video page is NOT opened. */
    @Override public void onBackground(String id, String title, String author, String thumb, String av) {
        if (id == null || id.isEmpty()) return;
        long pos = id.equals(feedPlayer.currentId()) ? feedPlayer.position() : 0;
        feedPlayer.stop();
        Ui.saveHistory(this, id, title, author, thumb);
        Toast.makeText(this, "Playing in background", Toast.LENGTH_SHORT).show();
        BgPlayer.start(this, id, title, author, thumb, av, pos, null);
    }

    @Override public void onFullscreen(String id, String title, String author, String thumb, String av) {
        if (id == null || id.isEmpty()) return;
        boolean same = id.equals(feedPlayer.currentId());
        long pos = same ? feedPlayer.position() : 0;
        int q = same ? feedPlayer.quality() : 0;
        feedPlayer.stop();
        Ui.saveHistory(this, id, title, author, thumb);
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", title);
        in.putExtra("uploader", author);
        in.putExtra("thumbnail", thumb);
        in.putExtra("avatar", av);
        in.putExtra("start_full", true);
        in.putExtra("start_pos", pos);
        if (q > 0) in.putExtra("quality", String.valueOf(q));
        startActivity(in);
    }

    @Override public void onOpen(String id, String title, String author, String thumb, String av, boolean audio) {
        if (id == null || id.isEmpty()) return;
        feedPlayer.stop();
        Ui.saveHistory(this, id, title, author, thumb);
        Intent in = new Intent(this, PlayerActivity.class);
        in.putExtra("video_id", id);
        in.putExtra("title", title);
        in.putExtra("uploader", author);
        in.putExtra("thumbnail", thumb);
        in.putExtra("avatar", av);
        if (audio) in.putExtra("start_audio", true);
        startActivity(in);
    }

    @Override public void onDownload(String id, String title) { Downloads.start(this, id, title); }

    @Override public void onNeedLogin() {
        new android.app.AlertDialog.Builder(this,
                Ui.dark ? android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK : android.app.AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Sign in required")
            .setMessage("Sign in with your Google account to like, comment, subscribe and save videos.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Sign in", (d, w) -> startActivityForResult(new Intent(this, LoginActivity.class), RC_LOGIN))
            .show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOGIN && res == RESULT_OK) {
            Net.setCookie(Auth.cookie(this));
            subscribed = Auth.isSubscribed(this, channelId);
            styleSub();
            adapter.notifyDataSetChanged();
            pool.execute(() -> {
                try { Auth.refreshSubscriptions(this); } catch (Exception ignored) { }
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    subscribed = Auth.isSubscribed(this, channelId);
                    styleSub();
                    adapter.notifyDataSetChanged();
                });
            });
        }
    }
}
