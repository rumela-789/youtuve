package com.manik.youtubeweb;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * YouTube's own "Home" recommendations (the same list the official app / youtube.com shows).
 * Signed in: personalised to the account (watch history, subscriptions, likes).
 * Signed out: YouTube's generic home feed. Pages are loaded with the continuation token.
 */
final class OfficialFeed {
    private OfficialFeed() {}

    static Yt.Page fetch(Context c, String continuation) throws Exception {
        JSONObject body = new JSONObject();
        if (continuation == null || continuation.isEmpty()) body.put("browseId", "FEwhat_to_watch");
        else body.put("continuation", continuation);
        JSONObject res = Auth.postAny(c, "browse", body);
        JSONArray out = new JSONArray();
        collect(res, out, 0);
        String tok = findToken(res, 0);
        return new Yt.Page(out, null, tok);
    }

    // ------------------------------------------------------------ parsing

    private static void collect(Object node, JSONArray out, int depth) {
        if (depth > 40 || node == null) return;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject vr = o.optJSONObject("videoRenderer");
            if (vr != null) { add(out, fromVideoRenderer(vr)); return; }
            JSONObject lv = o.optJSONObject("lockupViewModel");
            if (lv != null) { add(out, fromLockup(lv)); return; }
            if (o.has("adSlotRenderer") || o.has("reelShelfRenderer") || o.has("shortsLockupViewModel")
                || o.has("reelItemRenderer")) return;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) collect(o.opt(it.next()), out, depth + 1);
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) collect(a.opt(i), out, depth + 1);
        }
    }

    private static void add(JSONArray out, JSONObject o) { if (o != null) out.put(o); }

    private static String findToken(Object node, int depth) {
        if (depth > 40 || node == null) return null;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject cir = o.optJSONObject("continuationItemRenderer");
            if (cir != null) {
                String t = deepToken(cir);
                if (t != null) return t;
            }
            java.util.Iterator<String> it = o.keys();
            String found = null;
            while (it.hasNext()) {
                String t = findToken(o.opt(it.next()), depth + 1);
                if (t != null) found = t;   // the last one is the "load more" at the bottom of the grid
            }
            return found;
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            String found = null;
            for (int i = 0; i < a.length(); i++) {
                String t = findToken(a.opt(i), depth + 1);
                if (t != null) found = t;
            }
            return found;
        }
        return null;
    }

    private static String deepToken(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject cc = o.optJSONObject("continuationCommand");
            if (cc != null && !cc.optString("token", "").isEmpty()) return cc.optString("token");
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String t = deepToken(o.opt(it.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = deepToken(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private static JSONObject make(String id, String title, String channel, String chId, String thumb,
                                   String avatar, long views, String when, long dur) throws Exception {
        if (id == null || !id.matches("[A-Za-z0-9_-]{11}") || title == null || title.isEmpty()) return null;
        JSONObject o = new JSONObject();
        o.put("url", "/watch?v=" + id);
        o.put("title", title);
        o.put("uploaderName", channel == null ? "" : channel);
        o.put("uploaderUrl", chId == null || chId.isEmpty() ? "" : "https://www.youtube.com/channel/" + chId);
        o.put("thumbnail", thumb == null || thumb.isEmpty() ? "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg" : thumb);
        o.put("uploaderAvatar", avatar == null ? "" : avatar);
        o.put("views", views);
        o.put("uploadedDate", when == null ? "" : when);
        o.put("duration", dur);
        return o;
    }

    private static JSONObject fromVideoRenderer(JSONObject v) {
        try {
            String id = v.optString("videoId", "");
            String title = Auth.textOf(v.opt("title"));
            String channel = Auth.textOf(v.opt("ownerText"));
            if (channel.isEmpty()) channel = Auth.textOf(v.opt("longBylineText"));
            String chId = firstChannelId(v.opt("ownerText"));
            if (chId.isEmpty()) chId = firstChannelId(v.opt("longBylineText"));
            String thumb = lastSource(v.optJSONObject("thumbnail"));
            String avatar = lastSource(v.optJSONObject("channelThumbnailSupportedRenderers"));
            long views = parseViews(Auth.textOf(v.opt("viewCountText")));
            String when = Auth.textOf(v.opt("publishedTimeText"));
            long dur;
            String lenText = Auth.textOf(v.opt("lengthText"));
            if (lenText.isEmpty()) {
                // live streams / premieres have no length
                dur = -1;
            } else dur = parseDuration(lenText);
            return make(id, title, channel, chId, thumb, avatar, views, when, dur);
        } catch (Exception e) {
            return null;
        }
    }

    private static JSONObject fromLockup(JSONObject lv) {
        try {
            String type = lv.optString("contentType", "");
            if (!type.equals("LOCKUP_CONTENT_TYPE_VIDEO")) return null;   // skips playlists, shorts, channels, mixes
            String id = lv.optString("contentId", "");
            JSONObject meta = lv.optJSONObject("metadata");
            JSONObject lm = meta == null ? null : meta.optJSONObject("lockupMetadataViewModel");
            if (lm == null) return null;
            JSONObject t = lm.optJSONObject("title");
            String title = t == null ? "" : t.optString("content", "");
            String channel = "", when = "";
            long views = -1;
            JSONObject cm = lm.optJSONObject("metadata");
            JSONObject cmv = cm == null ? null : cm.optJSONObject("contentMetadataViewModel");
            JSONArray rows = cmv == null ? null : cmv.optJSONArray("metadataRows");
            if (rows != null) {
                for (int r = 0; r < rows.length(); r++) {
                    JSONArray parts = rows.optJSONObject(r) == null ? null : rows.optJSONObject(r).optJSONArray("metadataParts");
                    if (parts == null) continue;
                    for (int p = 0; p < parts.length(); p++) {
                        JSONObject tx = parts.optJSONObject(p) == null ? null : parts.optJSONObject(p).optJSONObject("text");
                        String s = tx == null ? "" : tx.optString("content", "");
                        if (s.isEmpty()) continue;
                        String low = s.toLowerCase(Locale.US);
                        if (low.contains("view") || low.contains("watching")) views = parseViews(s);
                        else if (low.contains("ago") || low.contains("streamed") || low.contains("premiere")) when = s;
                        else if (channel.isEmpty() && r == 0) channel = s;
                    }
                }
            }
            String chId = findBrowseId(lm);
            String avatar = "";
            JSONObject img = lm.optJSONObject("image");
            if (img != null) avatar = firstUrlDeep(img, 0);
            JSONObject ci = lv.optJSONObject("contentImage");
            String thumb = ci == null ? "" : lastUrlDeep(ci, 0);
            long dur = -1;
            String badge = durationBadge(ci, 0);
            if (!badge.isEmpty()) {
                String low = badge.toLowerCase(Locale.US);
                dur = low.contains("live") ? -1 : parseDuration(badge);
            }
            return make(id, title, channel, chId, thumb, avatar, views, when, dur);
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------ helpers

    private static String durationBadge(Object node, int depth) {
        if (depth > 12 || node == null) return "";
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject b = o.optJSONObject("thumbnailBadgeViewModel");
            if (b != null) {
                String s = b.optString("text", "");
                if (!s.isEmpty()) return s;
            }
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String s = durationBadge(o.opt(it.next()), depth + 1);
                if (!s.isEmpty()) return s;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String s = durationBadge(a.opt(i), depth + 1);
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    private static String findBrowseId(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            String id = o.optString("browseId", "");
            if (id.matches("UC[A-Za-z0-9_-]{22}")) return id;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String s = findBrowseId(o.opt(it.next()));
                if (!s.isEmpty()) return s;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String s = findBrowseId(a.opt(i));
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    private static String firstChannelId(Object node) { return findBrowseId(node); }

    private static String lastSource(JSONObject o) {
        if (o == null) return "";
        return lastUrlDeep(o, 0);
    }

    private static String lastUrlDeep(Object node, int depth) {
        if (depth > 12 || node == null) return "";
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONArray th = o.optJSONArray("thumbnails");
            if (th == null) th = o.optJSONArray("sources");
            if (th != null && th.length() > 0) {
                String best = "";
                int bw = -1;
                for (int i = 0; i < th.length(); i++) {
                    JSONObject t = th.optJSONObject(i);
                    if (t == null) continue;
                    int w = t.optInt("width", 0);
                    if (w >= bw && !t.optString("url", "").isEmpty()) { bw = w; best = t.optString("url"); }
                }
                if (!best.isEmpty()) return best.startsWith("//") ? "https:" + best : best;
            }
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String s = lastUrlDeep(o.opt(it.next()), depth + 1);
                if (!s.isEmpty()) return s;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String s = lastUrlDeep(a.opt(i), depth + 1);
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    private static String firstUrlDeep(Object node, int depth) {
        if (depth > 12 || node == null) return "";
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONArray th = o.optJSONArray("sources");
            if (th != null && th.length() > 0 && th.optJSONObject(0) != null) {
                String u = th.optJSONObject(0).optString("url", "");
                if (!u.isEmpty()) return u.startsWith("//") ? "https:" + u : u;
            }
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String s = firstUrlDeep(o.opt(it.next()), depth + 1);
                if (!s.isEmpty()) return s;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String s = firstUrlDeep(a.opt(i), depth + 1);
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    /** "1:02:03" / "12:34" -> seconds. */
    static long parseDuration(String s) {
        if (s == null) return 0;
        Matcher m = Pattern.compile("(\\d+(?::\\d+)+)").matcher(s);
        if (!m.find()) return 0;
        String[] p = m.group(1).split(":");
        long t = 0;
        for (String x : p) t = t * 60 + Long.parseLong(x);
        return t;
    }

    /** "1.2M views" / "35,123 views" / "12K watching" -> number (-1 when unknown). */
    static long parseViews(String s) {
        if (s == null || s.isEmpty()) return -1;
        Matcher m = Pattern.compile("([\\d][\\d,\\.]*)\\s*([KkMmBb])?").matcher(s);
        if (!m.find()) return s.toLowerCase(Locale.US).contains("no views") ? 0 : -1;
        try {
            double v = Double.parseDouble(m.group(1).replace(",", ""));
            String u = m.group(2);
            if (u != null) {
                char ch = Character.toUpperCase(u.charAt(0));
                if (ch == 'K') v *= 1e3; else if (ch == 'M') v *= 1e6; else if (ch == 'B') v *= 1e9;
            }
            return (long) v;
        } catch (Exception e) {
            return -1;
        }
    }
}
