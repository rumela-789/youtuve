package com.manik.youtubeweb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import java.io.File;
import java.util.List;
import java.util.Locale;

/** Downloads screen: live progress cards for what is downloading, and the saved videos to play offline. */
public class DownloadsActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout list;
    private TextView tabActive, tabDone, summary;
    private boolean showDone = false;
    private String lastKey = "";
    private final java.util.HashMap<Long, Row> rows = new java.util.HashMap<>();

    private static final class Row {
        View root;
        TextView status, meta;
        RingView ring;
        View barFill;
        FrameLayout barBox;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh(false);
            handler.postDelayed(this, 500);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);

        // header
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(4), Ui.dp(8), Ui.dp(14), Ui.dp(4));
        ImageView back = Ui.icon(this, R.drawable.ic_back, Ui.fg, 24);
        back.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(Ui.dp(48), Ui.dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.text(this, "Downloads", 22, true, Ui.fg);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        titles.addView(t);
        summary = Ui.text(this, "", 12.5f, false, Ui.muted);
        titles.addView(summary);
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(head);

        // two pills: Downloading | Saved
        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(10));
        tabActive = pill("Downloading", () -> { showDone = false; lastKey = ""; refresh(true); });
        tabDone = pill("Saved", () -> { showDone = true; lastKey = ""; refresh(true); });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2);
        pl.rightMargin = Ui.dp(8);
        tabs.addView(tabActive, pl);
        tabs.addView(tabDone, new LinearLayout.LayoutParams(-2, -2));
        root.addView(tabs);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(14), 0, Ui.dp(14), Ui.dp(24));
        sv.addView(list, new FrameLayout.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        showDone = DlStore.activeCount() == 0 && DlStore.TASKS.isEmpty();
    }

    @Override protected void onResume() {
        super.onResume();
        lastKey = "";
        refresh(true);
        handler.postDelayed(tick, 500);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(tick);
        super.onPause();
    }

    private TextView pill(String label, final Runnable r) {
        TextView p = Ui.text(this, label, 13.5f, true, Ui.fg);
        p.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
        p.setOnClickListener(v -> r.run());
        return p;
    }

    private void stylePills(int active, int done) {
        tabActive.setText("Downloading" + (active > 0 ? " · " + active : ""));
        tabDone.setText("Saved" + (done > 0 ? " · " + done : ""));
        tabActive.setBackground(showDone ? Ui.rect(Ui.surface, 18) : Ui.gradient(18));
        tabActive.setTextColor(showDone ? Ui.fg : Ui.onAccent);
        tabDone.setBackground(showDone ? Ui.gradient(18) : Ui.rect(Ui.surface, 18));
        tabDone.setTextColor(showDone ? Ui.onAccent : Ui.fg);
    }

    // ------------------------------------------------------------------ list

    /** Rebuilds the list only when its structure changed; otherwise just updates numbers and bars. */
    private void refresh(boolean force) {
        List<DlStore.Task> tasks = DlStore.TASKS;
        List<DlStore.Done> done = DlStore.loadDone(this);
        int active = DlStore.activeCount();
        stylePills(active, done.size());
        String sp = active > 0 ? active + " downloading" : "Nothing downloading";
        summary.setText(sp + " · " + done.size() + " saved");

        StringBuilder key = new StringBuilder(showDone ? "D" : "A");
        if (showDone) { for (DlStore.Done d : done) key.append(d.uri).append('|'); }
        else { for (DlStore.Task t : tasks) key.append(t.id).append(':').append(t.state).append('|'); }
        String k = key.toString();
        if (force || !k.equals(lastKey)) {
            lastKey = k;
            rebuild(tasks, done);
        }
        if (!showDone) updateRows(tasks);
    }

    private void rebuild(List<DlStore.Task> tasks, List<DlStore.Done> done) {
        list.removeAllViews();
        rows.clear();
        if (showDone) {
            if (done.isEmpty()) { list.addView(empty("No saved videos yet", "Videos you download show up here and play offline, even without internet.")); return; }
            for (DlStore.Done d : done) list.addView(doneCard(d));
        } else {
            if (tasks.isEmpty()) { list.addView(empty("Nothing downloading", "Tap Download on any video. You will see its progress here.")); return; }
            for (DlStore.Task t : tasks) list.addView(taskCard(t));
        }
    }

    private View empty(String h, String d) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(Ui.dp(24), Ui.dp(90), Ui.dp(24), 0);
        ImageView ic = Ui.icon(this, R.drawable.ic_download, Ui.muted, 48);
        c.addView(ic, new LinearLayout.LayoutParams(Ui.dp(56), Ui.dp(56)));
        TextView a = Ui.text(this, h, 18, true, Ui.fg);
        a.setGravity(Gravity.CENTER);
        a.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        c.addView(a);
        TextView b = Ui.text(this, d, 13.5f, false, Ui.muted);
        b.setGravity(Gravity.CENTER);
        c.addView(b);
        return c;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(10), Ui.dp(12));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.surface2, Ui.surface});
        g.setCornerRadius(Ui.dp(20));
        g.setStroke(Ui.dp(1), Ui.line);
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Ui.dp(10);
        c.setLayoutParams(lp);
        return c;
    }

    private static String vidThumb(String vid) { return "https://i.ytimg.com/vi/" + vid + "/mqdefault.jpg"; }

    /** A running download: thumbnail inside a glowing progress ring, title, speed and a gradient bar. */
    private View taskCard(final DlStore.Task t) {
        LinearLayout c = card();
        FrameLayout box = new FrameLayout(this);
        ImageView th = new ImageView(this);
        th.setScaleType(ImageView.ScaleType.CENTER_CROP);
        th.setBackground(Ui.oval(Ui.surface2));
        th.setClipToOutline(true);
        th.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) { o.setOval(0, 0, v.getWidth(), v.getHeight()); }
        });
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(Ui.dp(52), Ui.dp(52), Gravity.CENTER);
        box.addView(th, tp);
        if (!t.vid.isEmpty()) Glide.with(this).load(vidThumb(t.vid)).override(160, 160).centerCrop().into(th);
        View dim = new View(this);
        dim.setBackground(Ui.oval(0x66000000));
        box.addView(dim, new FrameLayout.LayoutParams(Ui.dp(52), Ui.dp(52), Gravity.CENTER));
        RingView ring = new RingView(this);
        box.addView(ring, new FrameLayout.LayoutParams(Ui.dp(70), Ui.dp(70), Gravity.CENTER));
        c.addView(box, new LinearLayout.LayoutParams(Ui.dp(70), Ui.dp(70)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(Ui.dp(12), 0, Ui.dp(6), 0);
        TextView title = Ui.text(this, t.title, 14.5f, true, Ui.fg);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        mid.addView(title);
        TextView meta = Ui.text(this, "", 12, false, Ui.muted);
        meta.setPadding(0, Ui.dp(3), 0, Ui.dp(6));
        mid.addView(meta);
        FrameLayout bar = new FrameLayout(this);
        bar.setBackground(Ui.rect(Ui.line, 4));
        View fill = new View(this);
        GradientDrawable fg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFFF1744, 0xFFFF9100});
        fg.setCornerRadius(Ui.dp(4));
        fill.setBackground(fg);
        bar.addView(fill, new FrameLayout.LayoutParams(0, -1));
        mid.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(6)));
        TextView status = Ui.text(this, "", 12, true, Ui.link);
        status.setPadding(0, Ui.dp(6), 0, 0);
        mid.addView(status);
        c.addView(mid, new LinearLayout.LayoutParams(0, -2, 1));

        boolean failed = t.state == DlStore.FAILED;
        ImageView act = Ui.icon(this, failed ? R.drawable.ic_replay : R.drawable.ic_close, Ui.fg, 22);
        act.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        act.setOnClickListener(v -> {
            if (t.state == DlStore.FAILED) {
                DlStore.TASKS.remove(t);
                Downloads.enqueueAgain(this, t);
                lastKey = "";
            } else {
                t.cancel = true;
                if (t.state == DlStore.QUEUED) {
                    DlStore.TASKS.remove(t);
                    lastKey = "";
                }
                Toast.makeText(this, "Cancelling…", Toast.LENGTH_SHORT).show();
            }
            refresh(true);
        });
        c.addView(act, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));

        Row r = new Row();
        r.root = c; r.status = status; r.meta = meta; r.ring = ring; r.barFill = fill; r.barBox = bar;
        rows.put(t.id, r);
        if (failed) {
            c.setOnLongClickListener(v -> { DlStore.TASKS.remove(t); refresh(true); return true; });
        }
        return c;
    }

    private void updateRows(List<DlStore.Task> tasks) {
        for (DlStore.Task t : tasks) {
            Row r = rows.get(t.id);
            if (r == null) continue;
            int pct = Math.max(0, Math.min(100, t.pct));
            String q = t.tag.isEmpty() ? "" : t.tag + " · ";
            switch (t.state) {
                case DlStore.QUEUED:
                    r.ring.set(0, true);
                    r.meta.setText(q + "Waiting in queue");
                    r.status.setText("Queued");
                    r.status.setTextColor(Ui.muted);
                    setBar(r, 0);
                    break;
                case DlStore.RUNNING:
                    r.ring.set(pct, false);
                    String sizeTxt = t.total > 0 ? size(t.bytes) + " / " + size(t.total) : size(t.bytes);
                    r.meta.setText(q + sizeTxt);
                    String eta = "";
                    if (t.total > 0 && t.speed > 0) eta = " · " + etaText((t.total - t.bytes) / t.speed);
                    r.status.setText(pct + "%  ·  " + (t.speed > 0 ? size(t.speed) + "/s" : "starting…") + eta);
                    r.status.setTextColor(Ui.link);
                    setBar(r, pct);
                    break;
                case DlStore.SAVING:
                    r.ring.set(100, true);
                    r.meta.setText(q + "Almost done");
                    r.status.setText(t.kind == 1 ? "Merging video + sound…" : "Saving to your phone…");
                    r.status.setTextColor(Ui.link);
                    setBar(r, 99);
                    break;
                default:
                    r.ring.set(0, false);
                    r.meta.setText(q + "Failed");
                    r.status.setText(t.err.isEmpty() ? "Failed · tap ↻ to retry" : t.err + " · tap ↻ to retry");
                    r.status.setTextColor(0xFFFF5252);
                    setBar(r, 0);
                    break;
            }
        }
    }

    private void setBar(Row r, int pct) {
        int w = r.barBox.getWidth();
        if (w <= 0) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) r.barFill.getLayoutParams();
        int nw = w * pct / 100;
        if (lp.width != nw) { lp.width = nw; r.barFill.setLayoutParams(lp); }
    }

    // ------------------------------------------------------------------ saved videos

    private View doneCard(final DlStore.Done d) {
        LinearLayout c = card();
        FrameLayout box = new FrameLayout(this);
        ImageView th = new ImageView(this);
        th.setScaleType(ImageView.ScaleType.CENTER_CROP);
        th.setBackground(Ui.rect(Ui.surface2, 12));
        th.setClipToOutline(true);
        th.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(12)); }
        });
        box.addView(th, new FrameLayout.LayoutParams(-1, -1));
        // a frame taken from the saved file itself, so it also shows with no internet
        try { Glide.with(this).load(Uri.parse(d.uri)).override(320, 200).centerCrop().into(th); } catch (Exception ignored) { }
        ImageView play = Ui.icon(this, d.video ? R.drawable.ic_play : R.drawable.ic_music, Color.WHITE, 24);
        play.setBackground(Ui.oval(0x99000000));
        play.setPadding(Ui.dp(7), Ui.dp(7), Ui.dp(7), Ui.dp(7));
        box.addView(play, new FrameLayout.LayoutParams(Ui.dp(34), Ui.dp(34), Gravity.CENTER));
        c.addView(box, new LinearLayout.LayoutParams(Ui.dp(112), Ui.dp(70)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(Ui.dp(12), 0, Ui.dp(4), 0);
        TextView title = Ui.text(this, d.title.isEmpty() ? d.name : d.title, 14.5f, true, Ui.fg);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        mid.addView(title);
        String meta = (d.tag.isEmpty() ? "" : d.tag + " · ") + (d.size > 0 ? size(d.size) + " · " : "") + Ui.ago(d.time);
        TextView m = Ui.text(this, meta, 12, false, Ui.muted);
        m.setPadding(0, Ui.dp(4), 0, 0);
        mid.addView(m);
        TextView off = Ui.text(this, "Available offline", 11.5f, true, 0xFF2BA640);
        off.setPadding(0, Ui.dp(4), 0, 0);
        mid.addView(off);
        c.addView(mid, new LinearLayout.LayoutParams(0, -2, 1));

        ImageView del = Ui.icon(this, R.drawable.ic_close, Ui.muted, 20);
        del.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        del.setOnClickListener(v -> confirmDelete(d));
        c.addView(del, new LinearLayout.LayoutParams(Ui.dp(42), Ui.dp(42)));

        c.setOnClickListener(v -> {
            Intent in = new Intent(this, LocalPlayerActivity.class);
            in.putExtra("uri", d.uri);
            in.putExtra("title", d.title.isEmpty() ? d.name : d.title);
            in.putExtra("audio", !d.video);
            startActivity(in);
        });
        return c;
    }

    private void confirmDelete(final DlStore.Done d) {
        new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Delete this download?")
            .setMessage("The video file will be removed from your phone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete", (dlg, w) -> {
                boolean ok = deleteFile(d.uri);
                DlStore.removeDone(this, d.uri);
                if (!ok) Toast.makeText(this, "Removed from the list. If the file is still in your gallery, delete it there.", Toast.LENGTH_LONG).show();
                lastKey = "";
                refresh(true);
            }).show();
    }

    private boolean deleteFile(String uriStr) {
        try {
            Uri u = Uri.parse(uriStr);
            if ("content".equals(u.getScheme())) return getContentResolver().delete(u, null, null) > 0;
            if ("file".equals(u.getScheme()) && u.getPath() != null) return new File(u.getPath()).delete();
        } catch (Exception ignored) { }
        return false;
    }

    // ------------------------------------------------------------------ text helpers

    static String size(long b) {
        if (b >= 1024L * 1024 * 1024) return String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024));
        if (b >= 1024L * 1024) return String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024));
        return Math.max(0, b / 1024) + " KB";
    }

    static String etaText(long sec) {
        if (sec < 0) sec = 0;
        if (sec >= 3600) return (sec / 3600) + "h " + ((sec % 3600) / 60) + "m left";
        if (sec >= 60) return (sec / 60) + "m " + (sec % 60) + "s left";
        return sec + "s left";
    }

    /** Circular progress: a red-to-orange sweep around the thumbnail with the percentage in the middle. */
    static final class RingView extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), arc = new Paint(Paint.ANTI_ALIAS_FLAG),
            txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF box = new RectF();
        private int pct = 0;
        private boolean spin = false;
        private float angle = 0;

        RingView(android.content.Context c) {
            super(c);
            track.setStyle(Paint.Style.STROKE);
            track.setStrokeWidth(Ui.dp(4));
            track.setColor(Ui.line);
            arc.setStyle(Paint.Style.STROKE);
            arc.setStrokeWidth(Ui.dp(4));
            arc.setStrokeCap(Paint.Cap.ROUND);
            txt.setColor(Color.WHITE);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setTextSize(Ui.dp(12));
            txt.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void set(int p, boolean spinning) {
            if (p != pct || spinning != spin) { pct = p; spin = spinning; invalidate(); }
        }

        @Override protected void onDraw(Canvas cv) {
            float pad = Ui.dp(4);
            box.set(pad, pad, getWidth() - pad, getHeight() - pad);
            cv.drawOval(box, track);
            arc.setShader(new SweepGradient(getWidth() / 2f, getHeight() / 2f, new int[]{0xFFFF1744, 0xFFFF9100, 0xFFFF1744}, null));
            cv.save();
            cv.rotate(-90, getWidth() / 2f, getHeight() / 2f);
            if (spin) {
                angle = (angle + 7) % 360;
                cv.rotate(angle, getWidth() / 2f, getHeight() / 2f);
                cv.drawArc(box, 0, 90, false, arc);
                postInvalidateOnAnimation();
            }
            else cv.drawArc(box, 0, 360f * pct / 100f, false, arc);
            cv.restore();
            if (!spin) cv.drawText(pct + "%", getWidth() / 2f, getHeight() / 2f + Ui.dp(4), txt);
        }
    }
}
