package com.manik.youtubeweb;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

/** Plays a downloaded file straight from the phone: no internet, no YouTube. */
public class LocalPlayerActivity extends Activity {
    private ExoPlayer exo;
    private PlayerView pv;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.load(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF000000);
        getWindow().setNavigationBarColor(0xFF000000);
        String uri = getIntent().getStringExtra("uri");
        String title = getIntent().getStringExtra("title");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        pv = new PlayerView(this);
        pv.setControllerShowTimeoutMs(3000);
        root.addView(pv, new FrameLayout.LayoutParams(-1, -1));
        TextView t = Ui.text(this, title == null ? "" : title, 14, true, 0xFFFFFFFF);
        t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(Ui.dp(52), Ui.dp(14), Ui.dp(16), Ui.dp(10));
        t.setBackgroundColor(0x66000000);
        root.addView(t, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        ImageView back = Ui.icon(this, R.drawable.ic_back, 0xFFFFFFFF, 24);
        back.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(12));
        back.setOnClickListener(v -> finish());
        root.addView(back, new FrameLayout.LayoutParams(Ui.dp(48), Ui.dp(48), Gravity.TOP | Gravity.START));
        setContentView(root);
        if (uri == null) { finish(); return; }
        exo = new ExoPlayer.Builder(this).build();
        pv.setPlayer(exo);
        exo.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException e) {
                Toast.makeText(LocalPlayerActivity.this, "Couldn't play this file. It may have been deleted.", Toast.LENGTH_LONG).show();
            }
        });
        exo.setMediaItem(MediaItem.fromUri(Uri.parse(uri)));
        exo.prepare();
        exo.setPlayWhenReady(true);
    }

    @Override protected void onStop() {
        if (exo != null) exo.pause();
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (pv != null) pv.setPlayer(null);
        if (exo != null) { exo.release(); exo = null; }
        super.onDestroy();
    }
}
