package com.manik.youtubeweb;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.comments.CommentsInfo;
import org.schabi.newpipe.extractor.comments.CommentsInfoItem;
import org.schabi.newpipe.extractor.stream.Description;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * YouTube comments. Reading uses NewPipeExtractor; posting uses YouTube's own web API with the signed-in session
 * (the same call youtube.com makes when you press "Comment").
 */
final class Comments {
    private Comments() {}

    static final class C {
        String id = "", author = "", avatar = "", text = "", date = "", likes = "";
        boolean html, pinned, mine, liked;
        int replyCount, likeCount;
        Page replies;
    }

    static final class Res {
        final List<C> items = new ArrayList<>();
        Page next;
    }

    private static String nz(String s) { return s == null ? "" : s; }

    private static String watchUrl(String id) { return "https://www.youtube.com/watch?v=" + id; }

    private static void convert(List<CommentsInfoItem> in, Res out) {
        if (in == null) return;
        for (CommentsInfoItem it : in) {
            if (it == null) continue;
            C c = new C();
            c.id = nz(it.getCommentId());
            c.author = nz(it.getUploaderName());
            c.avatar = Yt.bestImage(it.getUploaderAvatars());
            Description d = it.getCommentText();
            if (d != null) { c.text = nz(d.getContent()); c.html = d.getType() == Description.HTML; }
            c.date = nz(it.getTextualUploadDate());
            int lk = it.getLikeCount();
            c.likes = lk > 0 ? Ui.count(lk) : "";
            c.likeCount = Math.max(0, lk);
            c.pinned = it.isPinned();
            c.replyCount = it.getReplyCount();
            c.replies = it.getReplies();
            out.items.add(c);
        }
    }

    static Res first(String videoId) throws Exception {
        CommentsInfo ci = CommentsInfo.getInfo(ServiceList.YouTube, watchUrl(videoId));
        Res r = new Res();
        convert(ci.getRelatedItems(), r);
        r.next = ci.getNextPage();
        return r;
    }

    /** Next page of comments, or the replies of one comment (pass that comment's replies page). */
    static Res more(String videoId, Page page) throws Exception {
        ListExtractor.InfoItemsPage<CommentsInfoItem> p =
            CommentsInfo.getMoreItems(ServiceList.YouTube, watchUrl(videoId), page);
        Res r = new Res();
        convert(p.getItems(), r);
        r.next = p.getNextPage();
        return r;
    }

    // ------------------------------------------------------------------ count + posting (YouTube web API)

    private static String commentsToken(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if ("comment-item-section".equals(o.optString("sectionIdentifier"))
                    || "comments-section".equals(o.optString("targetId"))
                    || "engagement-panel-comments-section".equals(o.optString("panelIdentifier"))) {
                String t = tokenIn(o);
                if (t != null) return t;
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = commentsToken(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = commentsToken(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private static String tokenIn(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject c = o.optJSONObject("continuationItemRenderer");
            if (c != null) {
                String t = firstString(c, "token");
                if (t != null) return t;
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = tokenIn(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = tokenIn(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private static String firstString(Object node, String key) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            Object v = o.opt(key);
            if (v instanceof String && !((String) v).isEmpty()) return (String) v;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String r = firstString(o.opt(it.next()), key);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String r = firstString(a.opt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static JSONObject findObj(Object node, String key) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject hit = o.optJSONObject(key);
            if (hit != null) return hit;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                JSONObject r = findObj(o.opt(it.next()), key);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                JSONObject r = findObj(a.opt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** Returns {countText, createCommentParams}; either can be empty/null (e.g. comments off, or signed out). */
    static String[] header(Context c, String videoId) throws Exception {
        return header(c, videoId, false);
    }

    /** Same as above; with seed = true the first page's like / reply / delete actions are remembered too. */
    static String[] header(Context c, String videoId, boolean seed) throws Exception {
        JSONObject next = Auth.nextInfo(c, videoId);
        String tok = commentsToken(next);
        if (tok == null) return new String[]{"", null};
        JSONObject res = Auth.postAny(c, "next", new JSONObject().put("continuation", tok));
        String params = firstString(res, "createCommentParams");
        String count = "";
        JSONObject hdr = findObj(res, "commentsHeaderRenderer");
        if (hdr != null) {
            count = Auth.textOf(hdr.opt("countText"));
            if (count.isEmpty()) {
                JSONObject cc = hdr.optJSONObject("commentCount");
                count = cc == null ? "" : Auth.textOf(cc);
            }
        }
        count = count.replaceAll("(?i)\\s*comments?\\s*", "").trim();
        if (seed) {
            VState s = state(videoId);
            synchronized (s.lock) {
                if (!s.seeded) {
                    s.seeded = true;
                    try { indexPage(res, s); } catch (Exception ignored) { }
                    s.next = pageToken(res);
                }
            }
        }
        return new String[]{count, params};
    }

    /** Posts a comment; returns its id when YouTube tells us (needed to delete it later). */
    static String post(Context c, String videoId, String text) throws Exception {
        String[] h = header(c, videoId);
        if (h[1] == null || h[1].isEmpty())
            throw new Exception("The comment box isn't available for this video (comments may be turned off).");
        JSONObject res = Auth.post(c, "comment/create_comment",
            new JSONObject().put("commentText", text).put("createCommentParams", h[1]));
        VState s = state(videoId);
        try { indexPage(res, s); } catch (Exception ignored) { }
        String id = firstString(res, "commentId");
        return id == null ? "" : id;
    }

    // ------------------------------------------------------------------ like / reply / delete
    //
    // NewPipeExtractor only lists comments. To act on one we need the one-time "action" strings YouTube puts next
    // to every comment in its own comments response, so those are read (lazily, page by page) and remembered.

    static final class Act {
        String like, unlike, reply, delete;
        boolean liked;
    }

    private static final class VState {
        final Map<String, Act> acts = new java.util.concurrent.ConcurrentHashMap<>();
        final Object lock = new Object();
        volatile String next;
        volatile boolean seeded;
    }

    private static final Map<String, VState> STATES = new LinkedHashMap<String, VState>(8, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, VState> e) { return size() > 6; }
    };

    private static synchronized VState state(String vid) {
        VState s = STATES.get(vid);
        if (s == null) { s = new VState(); STATES.put(vid, s); }
        return s;
    }

    private static synchronized void forget(String vid) { STATES.remove(vid); }

    /** Already-known actions of a comment (never touches the network). */
    static Act peek(String videoId, String commentId) {
        if (videoId == null || commentId == null || commentId.isEmpty()) return null;
        return state(videoId).acts.get(commentId);
    }

    /** Actions of a comment; reads further comment pages from YouTube until it is found (max ~20 pages). */
    static Act actionsFor(Context c, String videoId, String commentId, boolean fresh) throws Exception {
        if (commentId == null || commentId.isEmpty()) return null;
        if (fresh && peek(videoId, commentId) == null) forget(videoId);
        VState s = state(videoId);
        synchronized (s.lock) {
            Act a = s.acts.get(commentId);
            if (a != null) return a;
            if (!s.seeded) {
                s.seeded = true;
                s.next = commentsToken(Auth.nextInfo(c, videoId));
            }
            for (int i = 0; i < 20 && s.next != null && !s.acts.containsKey(commentId); i++) {
                JSONObject res = Auth.postAny(c, "next", new JSONObject().put("continuation", s.next));
                s.next = pageToken(res);
                indexPage(res, s);
            }
            return s.acts.get(commentId);
        }
    }

    private static void doAction(Context c, String action, String what) throws Exception {
        if (action == null || action.isEmpty())
            throw new Exception("YouTube didn't offer \"" + what + "\" for this comment");
        Auth.post(c, "comment/perform_comment_action", new JSONObject().put("actions", new JSONArray().put(action)));
    }

    static void like(Context c, Act a, boolean want) throws Exception {
        doAction(c, want ? a.like : a.unlike, want ? "like" : "remove like");
        a.liked = want;
    }

    static void delete(Context c, Act a) throws Exception {
        doAction(c, a.delete, "delete");
    }

    /** Replies to a comment; returns the new reply's id when known. */
    static String reply(Context c, Act a, String text) throws Exception {
        if (a.reply == null || a.reply.isEmpty()) throw new Exception("Replies aren't available for this comment");
        JSONObject res = Auth.post(c, "comment/create_comment_reply",
            new JSONObject().put("createReplyParams", a.reply).put("commentText", text));
        String id = firstString(res, "commentId");
        return id == null ? "" : id;
    }

    /** Is this comment written by the signed-in user? (author name / @handle, or YouTube offers Delete on it) */
    static boolean isMine(Context c, String videoId, C cm) {
        if (cm.mine) return true;
        Act a = peek(videoId, cm.id);
        if (a != null && a.delete != null && !a.delete.isEmpty()) return true;
        if (!Auth.signedIn(c)) return false;
        String au = norm(cm.author);
        if (au.isEmpty()) return false;
        return au.equals(norm(Ui.prefs(c).getString("acct_handle", "")))
            || au.equals(norm(Ui.prefs(c).getString("acct_name", "")));
    }

    private static String norm(String s) {
        return s == null ? "" : s.replace("@", "").trim().toLowerCase(java.util.Locale.ROOT);
    }

    // ---- reading the actions out of a comments response (old "commentRenderer" and new "commentViewModel" layouts)

    private static void indexPage(JSONObject res, VState s) {
        Map<String, JSONObject> byKey = new HashMap<>();
        JSONObject fu = res.optJSONObject("frameworkUpdates");
        JSONObject eb = fu == null ? null : fu.optJSONObject("entityBatchUpdate");
        JSONArray muts = eb == null ? null : eb.optJSONArray("mutations");
        if (muts != null) {
            for (int i = 0; i < muts.length(); i++) {
                JSONObject m = muts.optJSONObject(i);
                if (m == null) continue;
                String ek = m.optString("entityKey", "");
                JSONObject payload = m.optJSONObject("payload");
                if (payload == null) continue;
                Iterator<String> it = payload.keys();
                while (it.hasNext()) {
                    JSONObject inner = payload.optJSONObject(it.next());
                    if (inner == null) continue;
                    String k = inner.optString("key", "");
                    if (!k.isEmpty()) byKey.put(k, inner);
                    if (!ek.isEmpty()) byKey.put(ek, inner);
                }
            }
        }
        walkIndex(res, byKey, s);
    }

    private static void walkIndex(Object node, Map<String, JSONObject> byKey, VState s) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            String cid = o.optString("commentId", "");
            if (cid.length() > 10 && !s.acts.containsKey(cid)) {
                Act a = null;
                if (o.has("actionButtons")) a = legacyAct(o);
                else if (o.has("toolbarSurfaceKey") || o.has("toolbarStateKey")) a = vmAct(o, byKey);
                if (a != null) s.acts.put(cid, a);
            }
            Iterator<String> it = o.keys();
            while (it.hasNext()) walkIndex(o.opt(it.next()), byKey, s);
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) walkIndex(arr.opt(i), byKey, s);
        }
    }

    private static String actionIn(Object node) {
        if (node == null) return null;
        JSONObject pe = findObj(node, "performCommentActionEndpoint");
        if (pe == null) return null;
        String a = pe.optString("action", "");
        return a.isEmpty() ? null : a;
    }

    private static Act legacyAct(JSONObject o) {
        Act a = new Act();
        JSONObject ab = o.optJSONObject("actionButtons");
        JSONObject like = ab == null ? null : findObj(ab, "likeButton");
        JSONObject tb = like == null ? null : like.optJSONObject("toggleButtonRenderer");
        if (tb != null) {
            a.liked = tb.optBoolean("isToggled", false);
            a.like = actionIn(tb.opt("defaultServiceEndpoint"));
            a.unlike = actionIn(tb.opt("toggledServiceEndpoint"));
        }
        a.reply = ab == null ? null : firstString(ab, "createReplyParams");
        a.delete = findDeleteAction(o.opt("actionMenu"));
        return a;
    }

    private static Act vmAct(JSONObject o, Map<String, JSONObject> byKey) {
        Act a = new Act();
        JSONObject tool = byKey.get(o.optString("toolbarSurfaceKey", ""));
        JSONObject st = byKey.get(o.optString("toolbarStateKey", ""));
        JSONObject surf = byKey.get(o.optString("commentSurfaceKey", ""));
        if (tool != null) {
            a.like = actionIn(tool.opt("likeCommand"));
            a.unlike = actionIn(tool.opt("unlikeCommand"));
            a.reply = firstString(tool, "createReplyParams");
            a.delete = findDeleteAction(tool);
        }
        if (st != null) a.liked = "TOOLBAR_LIKE_STATE_LIKED".equals(st.optString("likeState", ""));
        if (a.delete == null && surf != null) a.delete = findDeleteAction(surf);
        if (a.delete == null) a.delete = findDeleteAction(o);
        return a;
    }

    private static boolean looksDelete(JSONObject x) {
        JSONObject ic = x.optJSONObject("icon");
        String icon = ic == null ? "" : ic.optString("iconType", "");
        if (icon.contains("DELETE") || icon.contains("TRASH")) return true;
        String[] keys = {"text", "title", "label"};
        for (String k : keys) {
            Object v = x.opt(k);
            String t = v instanceof String ? (String) v : Auth.textOf(v);
            if (t.equalsIgnoreCase("delete")) return true;
        }
        return false;
    }

    private static String findDeleteAction(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if (looksDelete(o)) {
                String a = actionIn(o);
                if (a != null) return a;
            }
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String r = findDeleteAction(o.opt(it.next()));
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                String r = findDeleteAction(arr.opt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    /** Token of the next page of top-level comments (the last item of a "continuationItems" list). */
    private static String pageToken(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONArray items = o.optJSONArray("continuationItems");
            if (items != null && items.length() > 0) {
                JSONObject last = items.optJSONObject(items.length() - 1);
                if (last != null && last.has("continuationItemRenderer")) {
                    String t = tokenIn(last);
                    if (t != null) return t;
                }
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = pageToken(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                String t = pageToken(arr.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }
}
