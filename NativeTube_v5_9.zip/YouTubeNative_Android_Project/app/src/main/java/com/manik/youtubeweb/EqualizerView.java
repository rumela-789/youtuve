package com.manik.youtubeweb;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Small animated sound bars: shown on the mini player while only the audio plays (background play). */
final class EqualizerView extends View {
    private static final int BARS = 5;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private boolean playing = true;

    EqualizerView(Context c) {
        super(c);
        paint.setColor(0xFFFFFFFF);
    }

    void setPlaying(boolean p) {
        playing = p;
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float gap = w * 0.08f;
        float bw = (w - gap * (BARS - 1)) / BARS;
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < BARS; i++) {
            float f = playing
                ? (float) (0.35 + 0.65 * Math.abs(Math.sin(t * (2.4 + i * 0.9) + i * 1.7)))
                : 0.18f;
            float bh = h * f;
            float x = i * (bw + gap);
            rect.set(x, h - bh, x + bw, h);
            c.drawRoundRect(rect, bw / 2, bw / 2, paint);
        }
        if (playing) postInvalidateOnAnimation();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (playing) postInvalidateOnAnimation();
    }
}
