package com.manik.youtubeweb;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Shared theme colours (YouTube's own palette) and small view helpers. */
final class Ui {
    static boolean dark = true;
    static int bg, surface, surface2, fg, muted, line, accent, accent2, onAccent, invBg, invFg, link;
    static float density = 2f;

    private Ui() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("native_settings", Context.MODE_PRIVATE);
    }

    static void load(Context c) {
        density = c.getResources().getDisplayMetrics().density;
        SharedPreferences p = prefs(c);
        String theme = p.getString("theme2", "midnight");
        boolean sysDark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (theme.equals("system")) theme = sysDark ? "midnight" : "light";
        dark = !theme.equals("light");
        if (theme.equals("amoled")) {
            bg = 0xFF000000; surface = 0xFF1A1A1A; surface2 = 0xFF1A1A1A; line = 0xFF303030;
        } else if (theme.equals("light")) {
            bg = 0xFFFFFFFF; surface = 0xFFF2F2F2; surface2 = 0xFFE5E5E5; line = 0xFFE0E0E0;
        } else {
            bg = 0xFF0F0F0F; surface = 0xFF272727; surface2 = 0xFF272727; line = 0xFF3F3F3F;
        }
        fg = dark ? 0xFFF1F1F1 : 0xFF0F0F0F;
        muted = dark ? 0xFFAAAAAA : 0xFF606060;
        accent = 0xFFFF0000;          // YouTube red
        accent2 = 0xFFFF0000;
        onAccent = 0xFFFFFFFF;
        invBg = dark ? 0xFFF1F1F1 : 0xFF0F0F0F;   // selected chip / Subscribe button
        invFg = dark ? 0xFF0F0F0F : 0xFFFFFFFF;
        link = dark ? 0xFF3EA6FF : 0xFF065FD4;
    }

    static int dp(float v) { return (int) (v * density + .5f); }

    /** Link / value colour (YouTube's blue). */
    static int accentText() { return link; }

    static TextView text(Context c, String s, float sp, boolean bold, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    static GradientDrawable rect(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    static GradientDrawable outline(int fill, int stroke, float radiusDp) {
        GradientDrawable d = rect(fill, radiusDp);
        d.setStroke(Math.max(1, dp(1)), stroke);
        return d;
    }

    static GradientDrawable gradient(float radiusDp) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{accent, accent2});
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    /** Neutral grey circle used behind avatars. */
    static GradientDrawable gradientOval() {
        return oval(0xFF606060);
    }

    static GradientDrawable oval(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    static ImageView icon(Context c, int res, int color, float sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return v;
    }

    private static String one(double v) {
        String s = String.format(Locale.US, "%.1f", v);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    static String count(long n) {
        if (n >= 1_000_000_000L) return one(n / 1e9) + "B";
        if (n >= 1_000_000L) return one(n / 1e6) + "M";
        if (n >= 1_000L) return one(n / 1e3) + "K";
        return String.valueOf(n);
    }

    /** "33,175" -> "33.2K", "1,000" -> "1K"; text that is not a plain number is left as it is. */
    static String compactCount(String s) {
        if (s == null) return "";
        String t = s.trim();
        if (!t.matches("[0-9][0-9,.\\s]*")) return t;
        try { return count(Long.parseLong(t.replaceAll("[^0-9]", ""))); } catch (Exception e) { return t; }
    }

    static String duration(long sec) {
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        return String.format(Locale.US, "%d:%02d", m, s);
    }

    static String ago(long millis) {
        long s = Math.max(0, (System.currentTimeMillis() - millis) / 1000);
        if (s < 3600) return Math.max(1, s / 60) + " minutes ago";
        if (s < 86400) return (s / 3600) + (s / 3600 == 1 ? " hour ago" : " hours ago");
        if (s < 86400L * 30) return (s / 86400) + (s / 86400 == 1 ? " day ago" : " days ago");
        if (s < 86400L * 365) return (s / (86400L * 30)) + (s / (86400L * 30) == 1 ? " month ago" : " months ago");
        return (s / (86400L * 365)) + (s / (86400L * 365) == 1 ? " year ago" : " years ago");
    }

    static String firstNonEmpty(String... values) {
        for (String v : values) if (v != null && !v.isEmpty() && !v.equals("null")) return v;
        return "";
    }

    static void saveHistory(Context c, String id, String title, String author, String thumb) {
        if (id == null || id.isEmpty()) return;
        try {
            SharedPreferences p = prefs(c);
            JSONArray old = new JSONArray(p.getString("watch_history", "[]"));
            JSONArray next = new JSONArray();
            JSONObject e = new JSONObject();
            e.put("id", id);
            e.put("title", title == null ? "" : title);
            e.put("author", author == null ? "" : author);
            e.put("thumb", thumb == null ? "" : thumb);
            e.put("time", System.currentTimeMillis());
            next.put(e);
            for (int i = 0; i < old.length() && next.length() < 100; i++) {
                JSONObject x = old.optJSONObject(i);
                if (x != null && !id.equals(x.optString("id"))) next.put(x);
            }
            p.edit().putString("watch_history", next.toString()).apply();
        } catch (Exception ignored) { }
    }
}
