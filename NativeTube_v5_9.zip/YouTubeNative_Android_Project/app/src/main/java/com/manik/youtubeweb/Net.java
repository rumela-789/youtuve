package com.manik.youtubeweb;

import android.content.Context;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.ResolvingDataSource;
import androidx.media3.datasource.TransferListener;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/** Shared HTTP clients: one for API calls, one for the media player, plus the extractor's Downloader. */
final class Net {
    static final String UA_WEB = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
        + "Chrome/131.0.0.0 Mobile Safari/537.36";
    private static final String UA_ANDROID = "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip";
    private static final String UA_ANDROID_VR = "com.google.android.apps.youtube.vr.oculus/1.62.27 "
        + "(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip";
    private static final String UA_IOS = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)";

    static final OkHttpClient HTTP = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS).build();

    private static final OkHttpClient PLAYER_HTTP = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true).build();

    /** Download client: HTTP/1.1 so each parallel range uses its own connection (YouTube throttles per connection). */
    private static final OkHttpClient DL_HTTP = new OkHttpClient.Builder()
        .protocols(java.util.Collections.singletonList(okhttp3.Protocol.HTTP_1_1))
        .dispatcher(newDlDispatcher())
        .connectionPool(new okhttp3.ConnectionPool(16, 5, TimeUnit.MINUTES))
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true).build();

    private static okhttp3.Dispatcher newDlDispatcher() {
        okhttp3.Dispatcher d = new okhttp3.Dispatcher();
        d.setMaxRequests(32);
        d.setMaxRequestsPerHost(32);
        return d;
    }


    // ------------------------------------------------------------------ measured connection speed

    /** Watches real playback traffic and keeps a smoothed estimate of the connection speed (bits per second). */
    private static final class Bw implements TransferListener {
        private long bytes = 0, activeMs = 0, last = 0;
        private volatile long est = 0;
        @Override public void onTransferInitializing(DataSource s, DataSpec d, boolean isNetwork) { }
        @Override public void onTransferStart(DataSource s, DataSpec d, boolean isNetwork) { }
        @Override public void onTransferEnd(DataSource s, DataSpec d, boolean isNetwork) { }
        @Override public synchronized void onBytesTransferred(DataSource s, DataSpec d, boolean isNetwork, int n) {
            if (!isNetwork || n <= 0) return;
            long now = android.os.SystemClock.elapsedRealtime();
            if (last != 0 && now - last < 800) activeMs += now - last;
            bytes += n;
            last = now;
            if (activeMs >= 1200) {
                long bps = bytes * 8000L / activeMs;
                est = est == 0 ? bps : (long) (est * 0.6 + bps * 0.4);
                bytes = 0;
                activeMs = 0;
            }
        }
    }

    static final Bw BW = new Bw();

    /** Speed measured while playing (bits/s); falls back to the last saved value, 0 when unknown. */
    static long bps(Context c) {
        long e = BW.est;
        if (e > 0) return e;
        return Ui.prefs(c).getLong("bw_est", 0);
    }

    static void saveBps(Context c) {
        long e = BW.est;
        if (e > 0) Ui.prefs(c).edit().putLong("bw_est", e).apply();
    }

    /** Quality "Auto" turns into: the best height this connection can carry smoothly (never above cap). */
    static int autoHeight(Context c, int cap) {
        long b = bps(c);
        int h;
        if (b <= 0) h = 480;
        else if (b < 450_000) h = 144;
        else if (b < 900_000) h = 240;
        else if (b < 1_600_000) h = 360;
        else if (b < 3_000_000) h = 480;
        else h = 720;
        if (Ui.prefs(c).getBoolean("datasaver", false)) h = Math.min(h, 360);
        return Math.min(h, cap);
    }

    /** One step lower than h (used when playback keeps stalling). 0 = already at the lowest. */
    static int stepDown(int h) {
        if (h > 720) return 720;
        if (h > 480) return 480;
        if (h > 360) return 360;
        if (h > 240) return 240;
        if (h > 144) return 144;
        return 0;
    }

    private static DataSource.Factory dsf;
    private static volatile String sessionCookie = "";
    /** Signed-in cookies on extractor requests would invalidate the (visitor-bound) poToken, so they stay off. */
    private static final boolean ATTACH_SESSION = false;
    /** When true, googlevideo requests are sent as POST with a 2-byte body (how YouTube's own clients fetch media). */
    static volatile boolean postMode = false;

    static void setCookie(String c) { sessionCookie = c == null ? "" : c; }

    private Net() {}

    /** Tells a data source whether googlevideo requests must be sent as POST (see postMode). */
    interface Flag { boolean get(); }

    /** Data source for ExoPlayer. Picks the User-Agent that matches the YouTube client the stream URL was made for. */
    static synchronized DataSource.Factory dataSourceFactory(Context c) {
        if (dsf == null) {
            dsf = make(c, new Flag() { @Override public boolean get() { return postMode; } });
        }
        return dsf;
    }

    /** A separate data source with its own POST flag (used by the inline feed player so it never disturbs the main player). */
    static DataSource.Factory independentFactory(Context c, Flag post) {
        return make(c, post);
    }

    private static DataSource.Factory make(Context c, final Flag post) {
        OkHttpDataSource.Factory ok = new OkHttpDataSource.Factory(PLAYER_HTTP).setTransferListener(BW);
        DefaultDataSource.Factory def = new DefaultDataSource.Factory(c.getApplicationContext(), ok);
        return new ResolvingDataSource.Factory(def, new ResolvingDataSource.Resolver() {
            @Override public DataSpec resolveDataSpec(DataSpec spec) throws IOException {
                String u = spec.uri.toString();
                if (!u.contains("googlevideo.com") && !u.contains("youtube.com")) return spec;
                if (post.get() && u.contains("googlevideo.com") && u.contains("videoplayback")) {
                    spec = spec.buildUpon().setHttpMethod(DataSpec.HTTP_METHOD_POST)
                        .setHttpBody(new byte[]{0x78, 0}).build();
                }
                Map<String, String> h = new HashMap<>(spec.httpRequestHeaders);
                applyHeaders(u, h);
                return spec.withRequestHeaders(h);
            }
        });
    }

    private static void applyHeaders(String u, Map<String, String> h) {
        if (u.contains("c=ANDROID_VR")) h.put("User-Agent", UA_ANDROID_VR);
        else if (u.contains("c=ANDROID")) h.put("User-Agent", UA_ANDROID);
        else if (u.contains("c=IOS")) h.put("User-Agent", UA_IOS);
        else {
            h.put("User-Agent", UA_WEB);
            h.put("Origin", "https://www.youtube.com");
            h.put("Referer", "https://www.youtube.com/");
        }
    }

    /** Opens one byte range of a media URL for downloading (caller must close the response). */
    static okhttp3.Response openRange(String url, boolean post, long from, long to) throws IOException {
        Map<String, String> h = new HashMap<>();
        applyHeaders(url, h);
        okhttp3.Request.Builder rb = new okhttp3.Request.Builder().url(url);
        for (Map.Entry<String, String> e : h.entrySet()) rb.header(e.getKey(), e.getValue());
        rb.header("Range", "bytes=" + from + "-" + to);
        if (post && url.contains("googlevideo.com") && url.contains("videoplayback")) {
            rb.post(RequestBody.create(new byte[]{0x78, 0}, (MediaType) null));
        } else {
            rb.get();
        }
        return DL_HTTP.newCall(rb.build()).execute();
    }

    private static boolean isYoutubeHost(String url) {
        try {
            String h = java.net.URI.create(url).getHost();
            return h != null && (h.equals("youtube.com") || h.endsWith(".youtube.com"));
        } catch (Exception e) { return false; }
    }

    private static boolean isWebClientBody(byte[] body) {
        String s = new String(body, java.nio.charset.StandardCharsets.UTF_8);
        return java.util.regex.Pattern.compile("\"clientName\"\\s*:\\s*\"(WEB|MWEB|TVHTML5)[A-Z_0-9]*\"")
            .matcher(s).find();
    }

    /** HTTP layer used by NewPipeExtractor. */
    static final class Dl extends Downloader {
        static final Dl INSTANCE = new Dl();

        @Override public Response execute(Request request) throws IOException, ReCaptchaException {
            String method = request.httpMethod();
            String url = request.url();
            byte[] data = request.dataToSend();
            RequestBody body = null;
            if (data != null) body = RequestBody.create(data, (MediaType) null);
            else if (method.equals("POST") || method.equals("PUT") || method.equals("PATCH"))
                body = RequestBody.create(new byte[0], (MediaType) null);
            okhttp3.Request.Builder rb = new okhttp3.Request.Builder().url(url).method(method, body)
                .header("User-Agent", UA_WEB);
            String existingCookie = "";
            for (Map.Entry<String, List<String>> e : request.headers().entrySet()) {
                String name = e.getKey();
                // Let OkHttp negotiate and transparently decode gzip itself.
                if (name == null || name.equalsIgnoreCase("Accept-Encoding")) continue;
                if (name.equalsIgnoreCase("Cookie")) { existingCookie = String.join("; ", e.getValue()); continue; }
                rb.removeHeader(name);
                for (String v : e.getValue()) rb.addHeader(name, v);
            }
            String cookie = existingCookie;
            String session = sessionCookie;
            if (ATTACH_SESSION && !session.isEmpty() && isYoutubeHost(url)) {
                // Signed-in requests are not subject to the anonymous "confirm you're not a bot" block.
                cookie = existingCookie.isEmpty() ? session : existingCookie + "; " + session;
                if (url.contains("/youtubei/v1/") && data != null && isWebClientBody(data)) {
                    try {
                        rb.header("Authorization", Auth.authHeader(session));
                        rb.header("X-Goog-AuthUser", "0");
                        rb.header("X-Origin", "https://www.youtube.com");
                        rb.header("Origin", "https://www.youtube.com");
                    } catch (Exception ignored) { }
                }
            }
            if (!cookie.isEmpty()) rb.header("Cookie", cookie);
            try (okhttp3.Response r = HTTP.newCall(rb.build()).execute()) {
                if (r.code() == 429) throw new ReCaptchaException("Rate limited / captcha requested", url);
                ResponseBody rbody = r.body();
                String text = rbody == null ? null : rbody.string();
                return new Response(r.code(), r.message(), r.headers().toMultimap(), text, r.request().url().toString());
            }
        }
    }
}
