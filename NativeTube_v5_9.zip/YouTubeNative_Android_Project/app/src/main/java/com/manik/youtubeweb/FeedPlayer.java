package com.manik.youtubeweb;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.TextureView;
import android.view.ViewGroup;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.CacheWriter;
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MergingMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plays the feed video that is on screen, right inside its card, muted and looping (like Facebook).
 * One small player is shared by all cards and moves to whichever card is most visible.
 */
final class FeedPlayer {
    private static final int T_PROG = 0, T_MERGED = 1, T_HLS = 2;

    private static final class Cand {
        final int type;
        final String v, a;
        Cand(int type, String v, String a) { this.type = type; this.v = v; this.a = a; }
    }

    private static final AudioAttributes AA = new AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build();

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final DataSource.Factory factory;
    private final ExecutorService warmIo = Executors.newFixedThreadPool(2);
    private final java.util.Set<String> prefetching = new java.util.HashSet<>();
    private final java.util.Set<String> preloaded = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
    private volatile boolean post = false;

    private ExoPlayer exo;
    private TextureView tv;
    private VideoCardView host;
    private String curId = "";
    private int gen = 0;
    private boolean muted;
    private boolean manual = false;
    private List<Cand> cands = new ArrayList<>();
    private int candIdx = 0;
    // quality picked by the person for the video that is playing (0 = automatic), and where to continue from
    private int forceH = 0;
    private String forceId = "";
    private long resumeAt = 0, seekOnStart = 0;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (exo == null || host == null) return;
            long d = exo.getDuration();
            if (d > 0) host.setPosition(exo.getCurrentPosition(), d);
            main.postDelayed(this, 300);
        }
    };

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onRenderedFirstFrame() {
            if (host == null) return;
            host.onVideoShown(muted);
            main.removeCallbacks(tick);
            main.post(tick);
        }
        @Override public void onVideoSizeChanged(VideoSize vs) {
            if (host == null || tv == null || vs.height <= 0) return;
            host.fitVideo(tv, vs.width * vs.pixelWidthHeightRatio / vs.height);
        }
        @Override public void onPlayerError(PlaybackException error) { onError(); }
        @Override public void onPlaybackStateChanged(int state) {
            if (host == null) return;
            if (state == Player.STATE_BUFFERING) host.setLoading(true);
            else if (state == Player.STATE_READY) host.setLoading(false);
        }
    };

    // ---- pre-loaded first seconds of upcoming videos (so they start the moment they scroll into view)
    private static SimpleCache cache;
    private static final long PRELOAD_VIDEO = 700L * 1024, PRELOAD_AUDIO = 300L * 1024;
    private DataSource.Factory cachedFactory;

    private static synchronized SimpleCache cache(Context c) {
        if (cache == null) {
            cache = new SimpleCache(new java.io.File(c.getCacheDir(), "feed_preload"),
                new LeastRecentlyUsedCacheEvictor(120L * 1024 * 1024), new StandaloneDatabaseProvider(c));
        }
        return cache;
    }

    private DataSource.Factory cached() {
        if (cachedFactory == null) {
            cachedFactory = new CacheDataSource.Factory().setCache(cache(app)).setUpstreamDataSourceFactory(factory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);
        }
        return cachedFactory;
    }

    private boolean preloadAllowed() {
        String mode = Ui.prefs(app).getString("feed_autoplay", "always");
        if (mode.equals("off")) return false;
        if (mode.equals("wifi")) {
            android.net.ConnectivityManager cm =
                (android.net.ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null || cm.isActiveNetworkMetered()) return false;
        }
        return true;
    }

    private void preloadBytes(String url, long bytes) {
        try {
            DataSpec spec = new DataSpec.Builder().setUri(url).setPosition(0).setLength(bytes).build();
            CacheDataSource ds = (CacheDataSource) cached().createDataSource();
            new CacheWriter(ds, spec, null, null).cache();
        } catch (Exception ignored) { }
    }

    FeedPlayer(Context c) {
        app = c.getApplicationContext();
        muted = Ui.prefs(app).getBoolean("feed_muted", true);
        factory = Net.independentFactory(app, new Net.Flag() {
            @Override public boolean get() { return post; }
        });
    }

    boolean isMuted() { return muted; }

    /** The quality saved in settings / picked earlier (0 = Auto). */
    private int savedHeight() {
        String q = Ui.prefs(app).getString("quality", "auto");
        try { return "auto".equals(q) ? 0 : Integer.parseInt(q); } catch (Exception e) { return 0; }
    }

    /** Quality chosen for the video that is playing now (0 = automatic). */
    int quality() { return forceH; }

    String currentId() { return curId; }

    long position() { return exo == null ? 0 : Math.max(0, exo.getCurrentPosition()); }

    /** Plays this card's video at a chosen height (0 = automatic), continuing from where it is. */
    void setQuality(VideoCardView card, String id, int height) {
        long pos = (card == host && id.equals(curId)) ? position() : 0;
        stop();
        forceId = id;
        forceH = height;
        // sticky: every next video (here and in the full player) uses this quality until it is changed again
        Ui.prefs(app).edit().putString("quality", height > 0 ? String.valueOf(height) : "auto").apply();
        resumeAt = pos;
        start(card, id, true);
    }

    /** Plays this card's video again from posMs (used when background play is switched off). */
    void playManualFrom(VideoCardView card, String id, long posMs) {
        stop();
        forceId = id;
        forceH = savedHeight();
        resumeAt = Math.max(0L, posMs);
        start(card, id, true);
    }

    VideoCardView host() { return host; }

    // ------------------------------------------------------------------ control

    /** Autoplay: the most visible card. */
    void play(VideoCardView card, String id) { start(card, id, false); }

    /** The person tapped a card: play it even when autoplay is off. */
    void playManual(VideoCardView card, String id) { start(card, id, true); }

    boolean isManual() { return manual; }

    private void start(final VideoCardView card, final String id, boolean byTap) {
        if (card == host && id.equals(curId)) return;
        stop();
        if (!id.equals(forceId)) { forceId = id; forceH = savedHeight(); resumeAt = 0; }
        seekOnStart = resumeAt;
        resumeAt = 0;
        manual = byTap;
        host = card;
        curId = id;
        card.setLoading(true);
        final int g = ++gen;
        io.execute(new Runnable() {
            @Override public void run() {
                Yt.Info info = null;
                try { info = Yt.info(id); } catch (Exception ignored) { }
                final Yt.Info fi = info;
                main.post(new Runnable() {
                    @Override public void run() {
                        if (g != gen) return;
                        if (fi == null) { if (host != null) host.setLoading(false); return; }
                        begin(fi);
                    }
                });
            }
        });
    }

    /** Warms the stream data of videos that are about to scroll in, so they start the moment they are on screen. */
    void prefetch(final String id) {
        if (id == null || id.length() != 11 || preloaded.contains(id)) return;
        synchronized (prefetching) {
            if (prefetching.size() >= 6 || !prefetching.add(id)) return;
        }
        warmIo.execute(new Runnable() {
            @Override public void run() {
                try {
                    Yt.Info info = Yt.info(id);
                    if (!info.live && preloadAllowed()) {
                        List<Cand> cs = candidates(info);
                        if (!cs.isEmpty() && cs.get(0).type != T_HLS) {
                            preloadBytes(cs.get(0).v, PRELOAD_VIDEO);
                            if (cs.get(0).a != null) preloadBytes(cs.get(0).a, PRELOAD_AUDIO);
                        }
                    }
                    preloaded.add(id);
                } catch (Exception ignored) { }
                synchronized (prefetching) { prefetching.remove(id); }
            }
        });
    }

    // ---- controls shown on the card

    boolean isPaused() { return exo != null && !exo.getPlayWhenReady(); }

    void togglePause() {
        if (exo == null || host == null) return;
        boolean play = !exo.getPlayWhenReady();
        exo.setPlayWhenReady(play);
        host.setPaused(!play);
        if (tv != null) tv.setKeepScreenOn(play);
    }

    /** Jump forward / back by delta milliseconds. */
    void seekBy(long delta) {
        if (exo == null || host == null) return;
        long d = exo.getDuration();
        if (d <= 0) return;
        long t = Math.max(0, Math.min(d - 300, exo.getCurrentPosition() + delta));
        exo.seekTo(t);
        host.setPosition(t, d);
    }

    void seekToFraction(float f) {
        if (exo == null) return;
        long d = exo.getDuration();
        if (d <= 0) return;
        exo.seekTo((long) (d * Math.max(0f, Math.min(1f, f))));
    }

    /** Stops playback and gives the card back its thumbnail. */
    void stop() {
        gen++;
        main.removeCallbacks(tick);
        if (exo != null) {
            try {
                exo.stop();
                exo.clearMediaItems();
                if (tv != null) exo.clearVideoTextureView(tv);
            } catch (Exception ignored) { }
        }
        if (tv != null && tv.getParent() != null) ((ViewGroup) tv.getParent()).removeView(tv);
        if (host != null) host.clearVideo();
        host = null;
        curId = "";
        manual = false;
        cands = new ArrayList<>();
        candIdx = 0;
        post = false;
    }

    void stopIfHost(VideoCardView card) {
        if (card == host) stop();
    }

    void release() {
        stop();
        if (exo != null) {
            exo.removeListener(listener);
            exo.release();
            exo = null;
        }
        tv = null;
    }

    void toggleMute() {
        muted = !muted;
        Ui.prefs(app).edit().putBoolean("feed_muted", muted).apply();
        if (exo != null) {
            exo.setVolume(muted ? 0f : 1f);
            exo.setAudioAttributes(AA, !muted);
        }
        if (host != null) host.updateMute(muted);
    }

    // ------------------------------------------------------------------ playback

    private void ensurePlayer() {
        if (exo != null) return;
        exo = new ExoPlayer.Builder(app)
            .setLoadControl(new DefaultLoadControl.Builder().setBufferDurationsMs(3000, 20000, 500, 1500).build())
            .setAudioAttributes(AA, false)
            .build();
        exo.setRepeatMode(Player.REPEAT_MODE_ONE);
        exo.setVolume(muted ? 0f : 1f);
        exo.setTrackSelectionParameters(exo.getTrackSelectionParameters().buildUpon().setMaxVideoSize(854, 480).build());
        exo.addListener(listener);
    }

    private static boolean isAvc(Yt.VS v) { return v.codec != null && v.codec.startsWith("avc"); }

    private static int codecRank(Yt.VS v) {
        String c = v.codec == null ? "" : v.codec;
        if (c.startsWith("avc")) return 0;
        if (c.startsWith("av01")) return 2;
        return 1;
    }

    /** Streams of exactly the chosen height: a single file when there is one, else video + audio merged. */
    private List<Cand> qualityCandidates(Yt.Info d, int want) {
        List<Cand> out = new ArrayList<>();
        // the saved quality may not exist for this video: use the closest one at or below it (else the lowest above)
        int h = 0, lowAbove = Integer.MAX_VALUE;
        for (Yt.VS m : d.muxed) {
            if (m.height <= want) h = Math.max(h, m.height); else lowAbove = Math.min(lowAbove, m.height);
        }
        for (Yt.VS v : d.videoOnly) {
            if (v.height <= want) h = Math.max(h, v.height); else lowAbove = Math.min(lowAbove, v.height);
        }
        if (h == 0 && lowAbove != Integer.MAX_VALUE) h = lowAbove;
        for (Yt.VS m : d.muxed) {
            if (m.height == h) { out.add(new Cand(T_PROG, m.url, null)); break; }
        }
        Yt.VS vo = null;
        for (Yt.VS v : d.videoOnly) {
            if (v.height != h) continue;
            if (vo == null || codecRank(v) < codecRank(vo)) vo = v;
        }
        Yt.AS au = null;
        for (Yt.AS a : d.audio) {
            boolean m4a = "m4a".equals(a.suffix) || "mp4".equals(a.suffix);
            if (m4a && (au == null || a.bitrate > au.bitrate)) au = a;
        }
        if (vo != null && au != null) out.add(new Cand(T_MERGED, vo.url, au.url));
        return out;
    }

    private List<Cand> candidates(Yt.Info d) {
        List<Cand> out = new ArrayList<>();
        if (forceH > 0 && d.id != null && d.id.equals(forceId)) out.addAll(qualityCandidates(d, forceH));
        // one single-file stream (has sound): small and fast to start
        Yt.VS best = null, low = null;
        final int auto = Net.autoHeight(app, 480);
        for (Yt.VS v : d.muxed) {
            if (v.height <= auto) { if (best == null || v.height > best.height) best = v; }
            else if (low == null || v.height < low.height) low = v;
        }
        Yt.VS m = best != null ? best : low;
        // otherwise a small video-only + audio pair merged by the player
        Yt.VS vo = null;
        for (Yt.VS v : d.videoOnly) {
            if (!isAvc(v) || v.height > auto) continue;
            if (vo == null || v.height > vo.height) vo = v;
        }
        Yt.AS au = null;
        for (Yt.AS a : d.audio) {
            boolean m4a = "m4a".equals(a.suffix) || "mp4".equals(a.suffix);
            if (m4a && (au == null || a.bitrate < au.bitrate)) au = a;
        }
        Cand single = m != null ? new Cand(T_PROG, m.url, null) : null;
        Cand pair = (vo != null && au != null) ? new Cand(T_MERGED, vo.url, au.url) : null;
        // slow connection: when the single file is bigger than the speed allows, the small pair goes first
        boolean pairFirst = pair != null && (single == null || (m != null && m.height > auto));
        if (pairFirst) { out.add(pair); if (single != null) out.add(single); }
        else { if (single != null) out.add(single); if (pair != null) out.add(pair); }
        if (!d.hls.isEmpty()) out.add(new Cand(T_HLS, d.hls, null));
        return out;
    }

    private void begin(Yt.Info info) {
        if (host == null) return;
        cands = candidates(info);
        candIdx = 0;
        post = false;
        if (cands.isEmpty()) { host.setLoading(false); return; }
        ensurePlayer();
        if (tv == null) tv = new TextureView(app);
        tv.setKeepScreenOn(true);   // the screen stays on while the video plays
        if (tv.getParent() != null) ((ViewGroup) tv.getParent()).removeView(tv);
        host.attachVideo(tv);
        exo.setVideoTextureView(tv);
        exo.setVolume(muted ? 0f : 1f);
        exo.setAudioAttributes(AA, !muted);
        exo.setTrackSelectionParameters(exo.getTrackSelectionParameters().buildUpon()
            .setMaxVideoSize(forceH > 0 ? 4096 : 854, forceH > 0 ? 2304 : 480).build());
        prepare();
    }

    private void prepare() {
        if (exo == null || candIdx >= cands.size()) return;
        Cand c = cands.get(candIdx);
        try {
            MediaSource ms;
            if (c.type == T_HLS) {
                ms = new HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(c.v));
            } else {
                ProgressiveMediaSource.Factory pf = new ProgressiveMediaSource.Factory(cached());
                if (c.type == T_MERGED) {
                    ms = new MergingMediaSource(pf.createMediaSource(MediaItem.fromUri(c.v)),
                        pf.createMediaSource(MediaItem.fromUri(c.a)));
                } else {
                    ms = pf.createMediaSource(MediaItem.fromUri(c.v));
                }
            }
            if (seekOnStart > 0) exo.setMediaSource(ms, seekOnStart);
            else exo.setMediaSource(ms);
            exo.prepare();
            exo.setPlayWhenReady(true);
        } catch (Exception e) {
            onError();
        }
    }

    /** Current stream failed: retry it the way YouTube's own apps ask for media (POST), then try the next one. */
    private void onError() {
        if (cands.isEmpty() || candIdx >= cands.size()) return;
        Cand c = cands.get(candIdx);
        if (!post && c.type != T_HLS) {
            post = true;
        } else {
            post = false;
            candIdx++;
        }
        if (candIdx >= cands.size()) {
            // nothing worked: quietly leave the thumbnail in place
            if (host != null) { host.setLoading(false); host.clearVideo(); }
            if (exo != null) exo.stop();
            return;
        }
        prepare();
    }
}
