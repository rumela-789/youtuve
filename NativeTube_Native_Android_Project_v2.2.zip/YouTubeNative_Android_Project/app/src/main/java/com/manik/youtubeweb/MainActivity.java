package com.manik.youtubeweb;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import com.bumptech.glide.Glide;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private LinearLayout root, list;
    private EditText search;
    private TextView status;
    private SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private int bg, fg;
    private YoutubeApiClient api() { return new YoutubeApiClient(prefs.getString("api", "https://pipedapi.ducks.party")); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("native_settings", MODE_PRIVATE);
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 701);
        }
        applyTheme();
        build();
        loadHome();
    }
    private void applyTheme() {
        boolean dark = prefs.getString("theme", "system").equals("dark") ||
            (prefs.getString("theme", "system").equals("system") && (getResources().getConfiguration().uiMode & 0x30) == 0x20);
        bg = dark ? Color.rgb(18,18,18) : Color.WHITE;
        fg = dark ? Color.WHITE : Color.BLACK;
    }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(fg);
        if (bold) t.setTypeface(null, 1); return t;
    }
    private void build() {
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(14),dp(8),dp(14),dp(8)); root.setBackgroundColor(bg);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("NativeTube",22,true); top.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        Button settings = new Button(this); settings.setText("⚙"); settings.setOnClickListener(v -> openSettings()); top.addView(settings);
        root.addView(top);
        LinearLayout row = new LinearLayout(this);
        search = new EditText(this); search.setSingleLine(true); search.setTextColor(fg); search.setHintTextColor(fg); search.setHint("Search videos");
        row.addView(search,new LinearLayout.LayoutParams(0,dp(52),1));
        Button go = new Button(this); go.setText("Search"); go.setOnClickListener(v -> doSearch()); row.addView(go); root.addView(row);
        status = text("Search videos to get started",13,false); root.addView(status);
        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this); list.setOrientation(1); scroll.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private void loadHome() {
        list.removeAllViews();
        addMessage("Explore videos · NativeTube");
        status.setText("Loading recommendations…");
        io.execute(() -> {
            try {
                JSONArray items = api().trending("US");
                runOnUiThread(() -> renderItems(items, "Trending"));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("Trending unavailable. Search for a video or change API instance in Settings.");
                    list.removeAllViews();
                    addMessage("Welcome to NativeTube");
                    addMessage("Search videos above. The selected API must support Piped-compatible trending, search and stream endpoints.");
                });
            }
        });
    }
    private void doSearch() {
        String q=search.getText().toString().trim(); if(q.isEmpty()) return;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);
        status.setText("Searching…"); list.removeAllViews();
        io.execute(() -> {
            try {
                JSONArray items=api().search(q);
                runOnUiThread(() -> renderItems(items, "Search"));
            } catch(Exception e){runOnUiThread(()->status.setText("Search failed: "+e.getMessage()+" — change API instance in Settings."));}
        });
    }
    private void renderItems(JSONArray items, String source) {
        list.removeAllViews();
        if (items == null || items.length() == 0) {
            status.setText("No videos returned. Try another API instance in Settings.");
            return;
        }
        status.setText(items.length() + " " + source.toLowerCase() + " videos");
        for (int i=0; i<items.length(); i++) {
            JSONObject item=items.optJSONObject(i); if(item==null) continue;
            String title=item.optString("title","Untitled");
            String url=item.optString("url", item.optString("id", ""));
            String id=YoutubeApiClient.videoId(url);
            String author=item.optString("uploaderName", item.optString("uploader", ""));
            String duration=item.optString("duration", "");
            String thumb=item.optString("thumbnail", "");
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(6),dp(9),dp(6),dp(9));
            card.setBackgroundColor(bg);
            ImageView image=new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(132),dp(78));
            card.addView(image,ip);
            if(!thumb.isEmpty()) Glide.with(this).load(thumb).centerCrop().into(image);
            LinearLayout details=new LinearLayout(this); details.setOrientation(1); details.setPadding(dp(10),0,0,0);
            TextView t=text(title,15,true); details.addView(t);
            TextView sub=text(author + (duration.isEmpty()?"":"  •  "+duration),11,false); details.addView(sub);
            LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL);
            Button bgBtn=new Button(this); bgBtn.setText("♫ Background"); bgBtn.setTextSize(9);
            bgBtn.setOnClickListener(v -> {
                if(id.isEmpty()){Toast.makeText(this,"Video ID unavailable",Toast.LENGTH_SHORT).show();return;}
                if(!prefs.getBoolean("background_play",true)){Toast.makeText(this,"Enable Background Play in Settings",Toast.LENGTH_SHORT).show();return;}
                Intent in=new Intent(this,PlayerActivity.class); in.putExtra("video_id",id);in.putExtra("title",title);in.putExtra("uploader",author);in.putExtra("start_audio",true);startActivity(in);
            });
            Button filterBtn=new Button(this); boolean filtered=prefs.getBoolean("filter_"+id,false);
            filterBtn.setText(filtered?"Filter ON":"Filter"); filterBtn.setTextSize(9);
            filterBtn.setOnClickListener(v->{boolean n=!prefs.getBoolean("filter_"+id,false);prefs.edit().putBoolean("filter_"+id,n).apply();filterBtn.setText(n?"Filter ON":"Filter");Toast.makeText(this,"Saved per-video preference. Actual ad filtering depends on API/provider support.",Toast.LENGTH_LONG).show();});
            controls.addView(bgBtn); controls.addView(filterBtn); details.addView(controls);
            card.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            card.setOnClickListener(v->{if(id.isEmpty()){Toast.makeText(this,"Invalid video ID",Toast.LENGTH_SHORT).show();return;}Intent in=new Intent(this,PlayerActivity.class);in.putExtra("video_id",id);in.putExtra("title",title);in.putExtra("uploader",author);startActivity(in);});
            list.addView(card);
            View divider=new View(this);divider.setBackgroundColor(fg==Color.WHITE?0xff444444:0xffdddddd);list.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }
    private void addMessage(String s){ TextView t=text(s,14,false); t.setPadding(0,dp(12),0,dp(12)); list.addView(t); }
    private void openSettings() {
        String[] themes={"System","Light","Dark"};
        String current=prefs.getString("theme","system");
        new android.app.AlertDialog.Builder(this).setTitle("Settings")
            .setItems(new String[]{"Background Play: "+(prefs.getBoolean("background_play",true)?"ON":"OFF"),
                "Ad filter preference: "+(prefs.getBoolean("adblock",false)?"ON":"OFF"),
                "Theme: "+current,"API instance","About / limitations"},(d,which)->{
                if(which==0){boolean n=!prefs.getBoolean("background_play",true);prefs.edit().putBoolean("background_play",n).apply();openSettings();}
                if(which==1){boolean n=!prefs.getBoolean("adblock",false);prefs.edit().putBoolean("adblock",n).apply();openSettings();}
                if(which==2)new android.app.AlertDialog.Builder(this).setTitle("Theme").setItems(themes,(x,k)->{prefs.edit().putString("theme",new String[]{"system","light","dark"}[k]).apply();recreate();}).show();
                if(which==3)editApi();
                if(which==4)new android.app.AlertDialog.Builder(this).setTitle("About").setMessage("Native Android UI and Media3 playback. Search/stream metadata is supplied by a configurable Piped-compatible API. Ad filtering is provider-dependent and not guaranteed; likes/dislikes, comments, subscriptions and account sign-in are not implemented in this starter build.").setPositiveButton("OK",null).show();
            }).show();
    }
    private void editApi(){
        EditText e=new EditText(this);e.setSingleLine(true);e.setText(prefs.getString("api","https://pipedapi.ducks.party"));
        new android.app.AlertDialog.Builder(this).setTitle("Piped-compatible API base URL").setView(e)
            .setPositiveButton("Save",(d,w)->prefs.edit().putString("api",e.getText().toString().trim()).apply())
            .setNegativeButton("Cancel",null).show();
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onBackPressed(){new android.app.AlertDialog.Builder(this).setTitle("Exit NativeTube?").setMessage("Are you sure you want to close the app?").setNegativeButton("Stay",null).setPositiveButton("Exit",(d,w)->finish()).show();}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
