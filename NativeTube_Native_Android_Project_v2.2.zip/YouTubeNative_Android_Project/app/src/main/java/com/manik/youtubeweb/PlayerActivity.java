package com.manik.youtubeweb;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.media3.common.MediaItem;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PlayerActivity extends Activity {
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private PlayerView playerView;
    private LinearLayout root;
    private TextView info;
    private String videoId,title,uploader;
    private JSONObject streamInfo;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("native_settings",MODE_PRIVATE);
        videoId=getIntent().getStringExtra("video_id");title=getIntent().getStringExtra("title");uploader=getIntent().getStringExtra("uploader");
        build();
        connectController();
        loadStreams();
    }
    private void build(){
        String theme=prefs.getString("theme","system");
        boolean dark=theme.equals("dark") || (theme.equals("system") && (getResources().getConfiguration().uiMode & 0x30)==0x20);
        int bg=dark?0xff121212:Color.WHITE,fg=dark?Color.WHITE:Color.BLACK;
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(bg);
        playerView=new PlayerView(this);playerView.setUseController(true);
        root.addView(playerView,new LinearLayout.LayoutParams(-1,dp(235)));
        TextView name=new TextView(this);name.setText(title==null?"Video":title);name.setTextColor(fg);name.setTextSize(18);name.setPadding(dp(14),dp(12),dp(14),dp(4));name.setTypeface(null,1);root.addView(name);
        TextView channel=new TextView(this);channel.setText(uploader==null?"":uploader);channel.setTextColor(fg);channel.setPadding(dp(14),0,dp(14),dp(8));root.addView(channel);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);actions.setPadding(dp(8),dp(4),dp(8),dp(4));
        Button like=new Button(this);like.setText("Like");like.setEnabled(false);actions.addView(like);
        Button dislike=new Button(this);dislike.setText("Dislike");dislike.setEnabled(false);actions.addView(dislike);
        Button background=new Button(this);background.setText("Play in background");background.setTextSize(10);actions.addView(background);
        Button ads=new Button(this);boolean filterOn=prefs.getBoolean("filter_"+videoId,false);ads.setText(filterOn?"Filter ON":"Filter");ads.setTextSize(10);ads.setOnClickListener(v->{boolean n=!prefs.getBoolean("filter_"+videoId,false);prefs.edit().putBoolean("filter_"+videoId,n).apply();ads.setText(n?"Filter ON":"Filter");Toast.makeText(this,"Per-video filter preference saved. Actual ad filtering depends on API/provider support.",Toast.LENGTH_LONG).show();});actions.addView(ads);
        background.setOnClickListener(v->{
            if(!prefs.getBoolean("background_play",true)){
                Toast.makeText(this,"Enable Background Play in Settings first.",Toast.LENGTH_LONG).show();
                return;
            }
            prefs.edit().putBoolean("background_for_"+videoId,true).apply();playAudioOnly();
        });
        root.addView(actions);
        info=new TextView(this);info.setTextColor(fg);info.setTextSize(13);info.setPadding(dp(14),dp(12),dp(14),dp(12));root.addView(info);
        setContentView(root);
    }
    private void connectController(){
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{
            try{controller=controllerFuture.get();playerView.setPlayer(controller);}
            catch(Exception e){runOnUiThread(()->info.setText("Player service connection failed: "+e.getMessage()));}
        },getMainExecutor());
    }
    private void loadStreams(){
        info.setText("Loading native stream…");
        io.execute(()->{
            try{
                String base=prefs.getString("api","https://pipedapi.adminforge.de");
                JSONObject data=new YoutubeApiClient(base).streams(videoId);
                streamInfo=data;
                runOnUiThread(()->{
                    info.setText(data.optString("description","")+"\n\nStreams loaded. Use Play in background for audio-only playback.");
                    if(getIntent().getBooleanExtra("start_audio",false)) playAudioOnly(); else playVideo();
                });
            }catch(Exception e){runOnUiThread(()->info.setText("Could not load stream: "+e.getMessage()+"\nTry changing API instance in Settings."));}
        });
    }
    private String selectVideoUrl(){
        JSONArray arr=streamInfo==null?null:streamInfo.optJSONArray("videoStreams");
        if(arr==null)return null;
        for(int i=0;i<arr.length();i++){JSONObject s=arr.optJSONObject(i);if(s!=null&&!s.optBoolean("videoOnly",false)){String u=s.optString("url","");if(!u.isEmpty())return u;}}
        for(int i=0;i<arr.length();i++){JSONObject s=arr.optJSONObject(i);if(s!=null){String u=s.optString("url","");if(!u.isEmpty())return u;}}
        return null;
    }
    private String selectAudioUrl(){
        JSONArray arr=streamInfo==null?null:streamInfo.optJSONArray("audioStreams");
        if(arr==null||arr.length()==0)return null;
        JSONObject s=arr.optJSONObject(0);return s==null?null:s.optString("url",null);
    }
    private void playVideo(){String url=selectVideoUrl();if(url==null){info.setText("No compatible video stream returned by this API.");return;}play(url);}
    private void playAudioOnly(){String url=selectAudioUrl();if(url==null){Toast.makeText(this,"Audio-only stream unavailable for this video.",Toast.LENGTH_LONG).show();return;}play(url);Toast.makeText(this,"Background audio started. You can lock the screen.",Toast.LENGTH_LONG).show();}
    private void play(String url){
        if(controller==null){info.setText("Connecting player…");new android.os.Handler(getMainLooper()).postDelayed(()->play(url),400);return;}
        MediaItem item=new MediaItem.Builder().setUri(url).setMediaId(videoId).setMediaMetadata(new androidx.media3.common.MediaMetadata.Builder().setTitle(title).setArtist(uploader).build()).build();
        controller.setMediaItem(item);controller.prepare();controller.play();
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onDestroy(){
        if(playerView!=null)playerView.setPlayer(null);
        if(controllerFuture!=null)MediaController.releaseFuture(controllerFuture);
        controller=null;io.shutdownNow();super.onDestroy();
    }
}
