NativeTube — Native Android YouTube client prototype (v2.2)
===========================================================

এই প্রজেক্টটি Android WebView ব্যবহার করে না। UI native Android Views এবং playback AndroidX Media3 ExoPlayer + MediaSessionService দিয়ে তৈরি।

এই সংস্করণে
------------
- Native home/search screen এবং Piped-compatible API-এর trending feed
- ভিডিও thumbnail, title, channel ও duration
- Native ExoPlayer video playback
- আলাদা audio-only background playback action; MediaSession notification controls
- System / Light / Dark theme
- Settings-এ Background Play ও per-video ad-filter preference
- প্রতিটি video card-এ Background ও Filter preference controls
- Back চাপলে Home থেকে বের হওয়ার আগে confirmation
- API base URL নিজের মতো বদলানোর Settings
- GitHub Actions workflow দিয়ে debug APK build

সীমাবদ্ধতা — গুরুত্বপূর্ণ
-----------------------
1. এটি YouTube-এর official app নয় এবং Google account sign-in করে না।
2. Like/Dislike, comments, subscriptions, playlists ও sync করা watch history এখনো নেই।
3. Filter preference শুধু local setting। YouTube-এর বিজ্ঞাপন ব্লক করার নিশ্চয়তা দেয় না; YouTube বিজ্ঞাপন ও ভিডিও একই delivery domain ব্যবহার করতে পারে। API/provider নিজে filtering না করলে অ্যাপ সেটি জোর করে করতে পারে না।
4. Background playback-এর জন্য API-তে audio-only stream থাকতে হবে। Android-এর battery policy, manufacturer restrictions এবং API stream expiry-এর কারণে সব ফোনে/সব ভিডিওতে ফল এক নাও হতে পারে।
5. Search/trending/stream API instance-এর availability ও response schema-এর ওপর নির্ভরশীল। Default endpoint কাজ না করলে Settings > API instance থেকে একটি সচল Piped-compatible API দিতে হবে। Public instance যেকোনো সময় বন্ধ/সীমাবদ্ধ হতে পারে।
6. Age-restricted, private, members-only, region-locked বা live stream ভিডিও চলবে এমন নিশ্চয়তা নেই।

Build / APK
-----------
এই পরিবেশে Android SDK/Gradle build tool নেই, তাই APK compile বা real-device test করা সম্ভব হয়নি। Source project-টি GitHub Actions build workflow-সহ দেওয়া হয়েছে।

1. ZIP extract করে সব ফাইল GitHub repository-র main branch-এ push করুন।
2. GitHub repository > Actions > Build Native Android APK > Run workflow চালান (অথবা main-এ push করুন)।
3. Workflow সফল হলে NativeTube-debug-apk artifact থেকে app-debug.apk ডাউনলোড করুন।
4. Android ফোনে APK install করে প্রথমে Search, video playback, তারপর Background Play এবং screen-off playback পরীক্ষা করুন। Android 13+ এ notification permission দিন।

Build settings
--------------
- JDK 17
- Gradle 8.11.1 (GitHub Actions workflow setup করে)
- Android Gradle Plugin 8.10.1
- compileSdk 36 / minSdk 23 / targetSdk 35
- AndroidX Media3 1.11.1

Project source: app/src/main/java/com/manik/youtubeweb/
No WebView source or WebView dependency is included.

ব্যবহারের আগে সংশ্লিষ্ট API/provider-এর শর্তাবলী, YouTube-এর শর্তাবলী এবং স্থানীয় আইন মেনে চলুন।

Build compatibility fix (v2.2)
------------------------------
- Media3 1.11.1 requires compileSdk 36; this project now uses compileSdk 36.
- Android Gradle Plugin upgraded to 8.10.1, which supports API 36.
- Gradle 8.11.1 and JDK 17 remain configured.
