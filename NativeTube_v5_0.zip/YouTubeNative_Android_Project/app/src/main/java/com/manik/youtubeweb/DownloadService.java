package com.manik.youtubeweb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Free, direct video / audio download. Streams are fetched straight from YouTube's servers in chunks (no middle
 * server, no limits). HD videos come as separate video + audio files, which are merged on the phone into one MP4.
 * Runs as a foreground service so a download keeps going if you leave the app.
 */
public class DownloadService extends Service {
    private static final String CHANNEL = "downloads";
    private static final int FG_ID = 9100;
    private static int doneId = 9200;
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static int active = 0; // touched on the main thread only

    private final Handler main = new Handler(Looper.getMainLooper());
    private NotificationManager nm;
    private long lastNotify = 0;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        ensureChannel();
        if (in == null || in.getStringExtra("u1") == null) {
            if (active == 0) stopSelf();
            return START_NOT_STICKY;
        }
        final String name = in.getStringExtra("name");
        final int kind = in.getIntExtra("kind", 0);
        final String u1 = in.getStringExtra("u1");
        final String u2 = in.getStringExtra("u2");
        final String mime = in.getStringExtra("mime");
        active++;
        Notification n = progressNotification(name, 0, true);
        if (Build.VERSION.SDK_INT >= 29) startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(FG_ID, n);
        EX.execute(new Runnable() {
            @Override public void run() { work(name, kind, u1, u2, mime); }
        });
        return START_NOT_STICKY;
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private Notification.Builder builder() {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
    }

    private Notification progressNotification(String name, int pct, boolean indeterminate) {
        return builder().setSmallIcon(R.drawable.ic_notif).setContentTitle("Downloading")
            .setContentText(name).setOngoing(true).setOnlyAlertOnce(true)
            .setProgress(100, Math.max(0, Math.min(100, pct)), indeterminate).build();
    }

    private void notifyProgress(String name, int pct, boolean indeterminate, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastNotify < 700) return;
        lastNotify = now;
        if (nm != null) nm.notify(FG_ID, progressNotification(name, pct, indeterminate));
    }

    // ------------------------------------------------------------------ the job

    private void work(final String name, int kind, String u1, String u2, String mime) {
        File dir = getCacheDir();
        File t1 = new File(dir, "dl_" + System.nanoTime() + ".part");
        File t2 = null, merged = null;
        Uri result = null;
        String err = null;
        try {
            if (kind == 1) {
                t2 = new File(dir, "dl_" + System.nanoTime() + ".part");
                fetch(u1, t1, name, 0, 45);
                fetch(u2, t2, name, 45, 90);
                notifyProgress(name, 95, true, true);
                merged = new File(dir, "dl_" + System.nanoTime() + ".mp4");
                mux(t1, t2, merged);
                result = publish(merged, name, mime, true);
            } else {
                fetch(u1, t1, name, 0, 97);
                result = publish(t1, name, mime, kind != 2);
            }
        } catch (Exception e) {
            err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        } finally {
            t1.delete();
            if (t2 != null) t2.delete();
            if (merged != null) merged.delete();
        }
        final Uri fu = result;
        final String fe = err;
        final String fm = mime;
        main.post(new Runnable() {
            @Override public void run() { finish(name, fm, fu, fe); }
        });
    }

    private void finish(String name, String mime, Uri uri, String err) {
        active = Math.max(0, active - 1);
        if (err == null) {
            Toast.makeText(this, "Download complete", Toast.LENGTH_SHORT).show();
            Notification.Builder b = builder().setSmallIcon(R.drawable.ic_notif).setContentTitle("Download complete")
                .setContentText(name).setAutoCancel(true);
            if (uri != null && "content".equals(uri.getScheme())) {
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri, mime);
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
                b.setContentIntent(PendingIntent.getActivity(this, doneId, view, fl));
            }
            if (nm != null) nm.notify(doneId++, b.build());
        } else {
            Toast.makeText(this, "Download failed: " + err, Toast.LENGTH_LONG).show();
            Notification n = builder().setSmallIcon(R.drawable.ic_notif).setContentTitle("Download failed")
                .setContentText(name).setAutoCancel(true).build();
            if (nm != null) nm.notify(doneId++, n);
        }
        if (active == 0) {
            stopForeground(true);
            stopSelf();
        }
    }

    // ------------------------------------------------------------------ fetching

    private static final int WORKERS = 8;                 // parallel connections per file
    private static final long CHUNK = 2L * 1024 * 1024;   // size of each range request (safe for YouTube's throttling)
    private static final ExecutorService POOL = Executors.newCachedThreadPool();

    /** Opens one range, retrying and (until a method has worked) alternating GET / POST. Caller closes the response. */
    private static okhttp3.Response open(String url, boolean[] post, boolean locked, long from, long to) throws IOException {
        IOException last = null;
        for (int attempt = 0; attempt < 4; attempt++) {
            try {
                okhttp3.Response x = Net.openRange(url, post[0], from, to);
                int code = x.code();
                if (code == 206 || (code == 200 && from == 0)) return x;
                x.close();
                last = new IOException("Server answered " + code);
            } catch (IOException e) {
                last = e;
            }
            if (!locked) post[0] = !post[0];
            try { Thread.sleep(300L * (attempt + 1)); }
            catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new IOException("Cancelled"); }
        }
        throw last == null ? new IOException("Download failed") : last;
    }

    /** Reads a response body fully into the file at the given offset; returns the number of bytes written. */
    private static long drain(okhttp3.Response resp, java.nio.channels.FileChannel ch, long offset, byte[] buf)
            throws IOException {
        okhttp3.ResponseBody body = resp.body();
        if (body == null) throw new IOException("Empty response");
        InputStream in = body.byteStream();
        long pos = offset;
        int n;
        while ((n = in.read(buf)) > 0) {
            ByteBuffer bb = ByteBuffer.wrap(buf, 0, n);
            while (bb.hasRemaining()) pos += ch.write(bb, pos);
        }
        return pos - offset;
    }

    /**
     * Downloads one URL into dest. The first request finds the size, then the rest is pulled by several
     * connections at once (each taking the next 2 MB range) and written straight to its place in the file.
     * Progress is mapped onto p0..p1 percent.
     */
    private void fetch(final String url, File dest, final String name, final int p0, final int p1) throws IOException {
        final java.util.concurrent.atomic.AtomicLong done = new java.util.concurrent.atomic.AtomicLong();
        final boolean[] post = {false};
        try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(dest, "rw")) {
            final java.nio.channels.FileChannel ch = raf.getChannel();
            // 1) first range: learns the total size and which method (GET/POST) the server accepts
            long total = -1;
            boolean whole = false;
            try (okhttp3.Response r = open(url, post, false, 0, CHUNK - 1)) {
                if (r.code() == 206) {
                    String cr = r.header("Content-Range");
                    if (cr != null && cr.indexOf('/') > 0) {
                        try { total = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim()); }
                        catch (NumberFormatException ignored) { }
                    }
                } else {
                    whole = true; // server ignored Range: it is sending the entire file
                    okhttp3.ResponseBody b = r.body();
                    if (b != null && b.contentLength() > 0) total = b.contentLength();
                }
                byte[] buf = new byte[128 * 1024];
                long got = drain(r, ch, 0, buf);
                if (got == 0) throw new IOException("Connection stalled");
                done.addAndGet(got);
                if (whole) return;
                if (total < 0) {
                    // unknown size: fall back to simple sequential chunks
                    sequential(url, ch, post[0], got, name, p0, p1, done);
                    return;
                }
            }
            if (total <= CHUNK) return;
            final long size = total;
            final boolean usePost = post[0];
            final java.util.concurrent.atomic.AtomicLong next = new java.util.concurrent.atomic.AtomicLong(CHUNK);
            final java.util.concurrent.atomic.AtomicBoolean failed = new java.util.concurrent.atomic.AtomicBoolean(false);
            raf.setLength(size);
            int chunks = (int) ((size - CHUNK + CHUNK - 1) / CHUNK);
            int workers = Math.max(1, Math.min(WORKERS, chunks));
            java.util.List<java.util.concurrent.Future<Void>> fs = new java.util.ArrayList<>();
            for (int w = 0; w < workers; w++) {
                fs.add(POOL.submit(new java.util.concurrent.Callable<Void>() {
                    @Override public Void call() throws Exception {
                        byte[] buf = new byte[128 * 1024];
                        boolean[] pm = {usePost};
                        while (!failed.get()) {
                            long from = next.getAndAdd(CHUNK);
                            if (from >= size) break;
                            long to = Math.min(from + CHUNK - 1, size - 1);
                            long want = to - from + 1;
                            IOException last = null;
                            boolean ok = false;
                            for (int attempt = 0; attempt < 4 && !ok && !failed.get(); attempt++) {
                                try (okhttp3.Response r = open(url, pm, true, from, to)) {
                                    long got = drain(r, ch, from, buf);
                                    if (got == want) { ok = true; done.addAndGet(got); }
                                    else last = new IOException("Connection dropped");
                                } catch (IOException e) {
                                    last = e;
                                }
                            }
                            if (!ok) { failed.set(true); throw last == null ? new IOException("Download failed") : last; }
                        }
                        return null;
                    }
                }));
            }
            // 2) wait, reporting progress
            IOException err = null;
            for (java.util.concurrent.Future<Void> f : fs) {
                while (!f.isDone()) {
                    int pct = p0 + (int) ((p1 - p0) * Math.min(1.0, done.get() / (double) size));
                    notifyProgress(name, pct, false, false);
                    try { Thread.sleep(250); }
                    catch (InterruptedException ie) { failed.set(true); Thread.currentThread().interrupt(); throw new IOException("Cancelled"); }
                }
                try { f.get(); }
                catch (java.util.concurrent.ExecutionException e) {
                    Throwable c = e.getCause();
                    if (err == null) err = c instanceof IOException ? (IOException) c : new IOException(String.valueOf(c));
                } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new IOException("Cancelled"); }
            }
            if (err != null) throw err;
            if (done.get() < size) throw new IOException("Download incomplete");
        }
    }

    /** Fallback when the server doesn't tell the file size: plain one-after-another ranges. */
    private void sequential(String url, java.nio.channels.FileChannel ch, boolean usePost, long start, String name,
                            int p0, int p1, java.util.concurrent.atomic.AtomicLong done) throws IOException {
        boolean[] pm = {usePost};
        byte[] buf = new byte[128 * 1024];
        long pos = start;
        while (true) {
            try (okhttp3.Response r = open(url, pm, true, pos, pos + CHUNK - 1)) {
                long got = drain(r, ch, pos, buf);
                pos += got;
                notifyProgress(name, 0, true, false);
                if (got < CHUNK) break;
            }
        }
    }

    // ------------------------------------------------------------------ merging video + audio into one MP4

    private static int findTrack(MediaExtractor ex, String prefix) {
        for (int i = 0; i < ex.getTrackCount(); i++) {
            String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if (m != null && m.startsWith(prefix)) return i;
        }
        return -1;
    }

    private static void mux(File video, File audio, File out) throws IOException {
        MediaExtractor ve = new MediaExtractor();
        MediaExtractor ae = new MediaExtractor();
        MediaMuxer mm = null;
        boolean started = false;
        try {
            ve.setDataSource(video.getAbsolutePath());
            ae.setDataSource(audio.getAbsolutePath());
            int vt = findTrack(ve, "video/");
            int at = findTrack(ae, "audio/");
            if (vt < 0 || at < 0) throw new IOException("Couldn't read the downloaded streams. Try a lower quality.");
            mm = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int vi = mm.addTrack(ve.getTrackFormat(vt));
            int ai = mm.addTrack(ae.getTrackFormat(at));
            ve.selectTrack(vt);
            ae.selectTrack(at);
            mm.start();
            started = true;
            copySamples(ve, mm, vi);
            copySamples(ae, mm, ai);
        } catch (IllegalArgumentException | IllegalStateException e) {
            throw new IOException("Couldn't merge video and audio. Try a lower quality.");
        } finally {
            try { if (mm != null) { if (started) mm.stop(); mm.release(); } } catch (Exception ignored) { }
            ve.release();
            ae.release();
        }
    }

    private static void copySamples(MediaExtractor ex, MediaMuxer mm, int track) {
        ByteBuffer buf = ByteBuffer.allocate(4 * 1024 * 1024);
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        while (true) {
            buf.clear();
            int n = ex.readSampleData(buf, 0);
            if (n < 0) break;
            bi.offset = 0;
            bi.size = n;
            bi.presentationTimeUs = ex.getSampleTime();
            bi.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
            mm.writeSampleData(track, buf, bi);
            ex.advance();
        }
    }

    // ------------------------------------------------------------------ saving into Movies/YouTube (or Music/YouTube)

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[512 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
        out.flush();
    }

    private Uri publish(File src, String name, String mime, boolean video) throws IOException {
        String folder = video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_MUSIC;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, folder + "/YouTube");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri coll = video ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            Uri uri = cr.insert(coll, cv);
            if (uri == null) throw new IOException("Couldn't create the file");
            try (OutputStream o = cr.openOutputStream(uri); FileInputStream in = new FileInputStream(src)) {
                if (o == null) throw new IOException("Couldn't open the file for writing");
                copy(in, o);
            } catch (IOException e) {
                cr.delete(uri, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, done, null, null);
            return uri;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(folder), "YouTube");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Couldn't create the folder (allow storage permission)");
        File dst = new File(dir, name);
        try (FileInputStream in = new FileInputStream(src); FileOutputStream o = new FileOutputStream(dst)) {
            copy(in, o);
        }
        MediaScannerConnection.scanFile(this, new String[]{dst.getAbsolutePath()}, new String[]{mime}, null);
        return Uri.fromFile(dst);
    }
}
