package com.manik.youtubeweb;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.TextureView;
import android.view.ViewGroup;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MergingMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plays the feed video that is on screen, right inside its card, muted and looping (like Facebook).
 * One small player is shared by all cards and moves to whichever card is most visible.
 */
final class FeedPlayer {
    private static final int T_PROG = 0, T_MERGED = 1, T_HLS = 2;

    private static final class Cand {
        final int type;
        final String v, a;
        Cand(int type, String v, String a) { this.type = type; this.v = v; this.a = a; }
    }

    private static final AudioAttributes AA = new AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build();

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final DataSource.Factory factory;
    private volatile boolean post = false;

    private ExoPlayer exo;
    private TextureView tv;
    private VideoCardView host;
    private String curId = "";
    private int gen = 0;
    private boolean muted;
    private List<Cand> cands = new ArrayList<>();
    private int candIdx = 0;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (exo == null || host == null) return;
            long d = exo.getDuration();
            if (d > 0) host.setProgress(exo.getCurrentPosition() / (float) d);
            main.postDelayed(this, 400);
        }
    };

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onRenderedFirstFrame() {
            if (host == null) return;
            host.onVideoShown(muted);
            main.removeCallbacks(tick);
            main.post(tick);
        }
        @Override public void onVideoSizeChanged(VideoSize vs) {
            if (host == null || tv == null || vs.height <= 0) return;
            host.fitVideo(tv, vs.width * vs.pixelWidthHeightRatio / vs.height);
        }
        @Override public void onPlayerError(PlaybackException error) { onError(); }
    };

    FeedPlayer(Context c) {
        app = c.getApplicationContext();
        muted = Ui.prefs(app).getBoolean("feed_muted", true);
        factory = Net.independentFactory(app, new Net.Flag() {
            @Override public boolean get() { return post; }
        });
    }

    boolean isMuted() { return muted; }

    VideoCardView host() { return host; }

    // ------------------------------------------------------------------ control

    void play(final VideoCardView card, final String id) {
        if (card == host && id.equals(curId)) return;
        stop();
        host = card;
        curId = id;
        final int g = ++gen;
        io.execute(new Runnable() {
            @Override public void run() {
                Yt.Info info = null;
                try { info = Yt.info(id); } catch (Exception ignored) { }
                final Yt.Info fi = info;
                main.post(new Runnable() {
                    @Override public void run() {
                        if (g != gen || fi == null || fi.live) return;
                        begin(fi);
                    }
                });
            }
        });
    }

    /** Stops playback and gives the card back its thumbnail. */
    void stop() {
        gen++;
        main.removeCallbacks(tick);
        if (exo != null) {
            try {
                exo.stop();
                exo.clearMediaItems();
                if (tv != null) exo.clearVideoTextureView(tv);
            } catch (Exception ignored) { }
        }
        if (tv != null && tv.getParent() != null) ((ViewGroup) tv.getParent()).removeView(tv);
        if (host != null) host.clearVideo();
        host = null;
        curId = "";
        cands = new ArrayList<>();
        candIdx = 0;
        post = false;
    }

    void stopIfHost(VideoCardView card) {
        if (card == host) stop();
    }

    void release() {
        stop();
        if (exo != null) {
            exo.removeListener(listener);
            exo.release();
            exo = null;
        }
        tv = null;
    }

    void toggleMute() {
        muted = !muted;
        Ui.prefs(app).edit().putBoolean("feed_muted", muted).apply();
        if (exo != null) {
            exo.setVolume(muted ? 0f : 1f);
            exo.setAudioAttributes(AA, !muted);
        }
        if (host != null) host.updateMute(muted);
    }

    // ------------------------------------------------------------------ playback

    private void ensurePlayer() {
        if (exo != null) return;
        exo = new ExoPlayer.Builder(app)
            .setLoadControl(new DefaultLoadControl.Builder().setBufferDurationsMs(2500, 10000, 500, 1000).build())
            .setAudioAttributes(AA, false)
            .build();
        exo.setRepeatMode(Player.REPEAT_MODE_ONE);
        exo.setVolume(muted ? 0f : 1f);
        exo.setTrackSelectionParameters(exo.getTrackSelectionParameters().buildUpon().setMaxVideoSize(854, 480).build());
        exo.addListener(listener);
    }

    private static boolean isAvc(Yt.VS v) { return v.codec != null && v.codec.startsWith("avc"); }

    private List<Cand> candidates(Yt.Info d) {
        List<Cand> out = new ArrayList<>();
        // one single-file stream (has sound), about 360-480p: small and fast to start
        Yt.VS best = null, low = null;
        for (Yt.VS v : d.muxed) {
            if (v.height <= 480) { if (best == null || v.height > best.height) best = v; }
            else if (low == null || v.height < low.height) low = v;
        }
        Yt.VS m = best != null ? best : low;
        if (m != null) out.add(new Cand(T_PROG, m.url, null));
        // otherwise a small video-only + audio pair merged by the player
        Yt.VS vo = null;
        for (Yt.VS v : d.videoOnly) {
            if (!isAvc(v) || v.height > 480) continue;
            if (vo == null || v.height > vo.height) vo = v;
        }
        Yt.AS au = null;
        for (Yt.AS a : d.audio) {
            boolean m4a = "m4a".equals(a.suffix) || "mp4".equals(a.suffix);
            if (m4a && (au == null || a.bitrate < au.bitrate)) au = a;
        }
        if (vo != null && au != null) out.add(new Cand(T_MERGED, vo.url, au.url));
        if (!d.hls.isEmpty()) out.add(new Cand(T_HLS, d.hls, null));
        return out;
    }

    private void begin(Yt.Info info) {
        if (host == null) return;
        cands = candidates(info);
        candIdx = 0;
        post = false;
        if (cands.isEmpty()) return;
        ensurePlayer();
        if (tv == null) tv = new TextureView(app);
        if (tv.getParent() != null) ((ViewGroup) tv.getParent()).removeView(tv);
        host.attachVideo(tv);
        exo.setVideoTextureView(tv);
        exo.setVolume(muted ? 0f : 1f);
        exo.setAudioAttributes(AA, !muted);
        prepare();
    }

    private void prepare() {
        if (exo == null || candIdx >= cands.size()) return;
        Cand c = cands.get(candIdx);
        try {
            MediaSource ms;
            if (c.type == T_HLS) {
                ms = new HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(c.v));
            } else {
                ProgressiveMediaSource.Factory pf = new ProgressiveMediaSource.Factory(factory);
                if (c.type == T_MERGED) {
                    ms = new MergingMediaSource(pf.createMediaSource(MediaItem.fromUri(c.v)),
                        pf.createMediaSource(MediaItem.fromUri(c.a)));
                } else {
                    ms = pf.createMediaSource(MediaItem.fromUri(c.v));
                }
            }
            exo.setMediaSource(ms);
            exo.prepare();
            exo.setPlayWhenReady(true);
        } catch (Exception e) {
            onError();
        }
    }

    /** Current stream failed: retry it the way YouTube's own apps ask for media (POST), then try the next one. */
    private void onError() {
        if (cands.isEmpty() || candIdx >= cands.size()) return;
        Cand c = cands.get(candIdx);
        if (!post && c.type != T_HLS) {
            post = true;
        } else {
            post = false;
            candIdx++;
        }
        if (candIdx >= cands.size()) {
            // nothing worked: quietly leave the thumbnail in place
            if (host != null) host.clearVideo();
            if (exo != null) exo.stop();
            return;
        }
        prepare();
    }
}
