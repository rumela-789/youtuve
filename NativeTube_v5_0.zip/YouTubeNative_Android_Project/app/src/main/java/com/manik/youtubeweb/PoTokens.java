package com.manik.youtubeweb;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.services.youtube.PoTokenProvider;
import org.schabi.newpipe.extractor.services.youtube.PoTokenResult;
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamExtractor;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Proof-of-origin tokens ("poToken"), generated on the phone by running YouTube's own BotGuard script in a hidden
 * WebView. This is what lets YouTube treat the app like a real browser instead of blocking the IP as a bot.
 * Port of NewPipe's PoTokenWebView (GPL-3.0 project; algorithm by LuanRT/BgUtils).
 */
final class PoTokens implements PoTokenProvider {
    static final PoTokens INSTANCE = new PoTokens();

    private static final String GOOGLE_API_KEY = "AIzaSyDyT5W0Jh49F30Pqqtyfdf7pDLFKLJoAnw";
    private static final String REQUEST_KEY = "O43z0dpjhgX20SCx4KAo";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        + "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.3";
    private static final MediaType PROTO_JSON = MediaType.parse("application/json+protobuf");

    private Context app;
    private final Object lock = new Object();
    private Gen gen;
    private String visitorData, streamingPot;
    private volatile boolean webViewBroken = false;

    private PoTokens() {}

    static void install(Context c) {
        INSTANCE.app = c.getApplicationContext();
        YoutubeStreamExtractor.setPoTokenProvider(INSTANCE);
    }

    /** Prepares the generator in the background so the first video starts faster. */
    static void warmUp() {
        new Thread(() -> {
            try { INSTANCE.ensure(false); } catch (Throwable ignored) { }
        }).start();
    }

    // ------------------------------------------------------------------ PoTokenProvider

    @Override public PoTokenResult getWebClientPoToken(String videoId) {
        if (app == null || webViewBroken) return null;
        try {
            return make(videoId, false);
        } catch (Throwable t) {
            return null; // the extractor will try without a poToken
        }
    }

    @Override public PoTokenResult getWebEmbedClientPoToken(String videoId) { return null; }
    @Override public PoTokenResult getAndroidClientPoToken(String videoId) { return null; }
    @Override public PoTokenResult getIosClientPoToken(String videoId) { return null; }

    private PoTokenResult make(String videoId, boolean forceRecreate) throws Exception {
        Gen g;
        String vd, sp;
        boolean recreated;
        synchronized (lock) {
            recreated = ensure(forceRecreate);
            g = gen; vd = visitorData; sp = streamingPot;
        }
        String player;
        try {
            player = g.mint(videoId);
        } catch (Exception e) {
            if (recreated) throw e;
            return make(videoId, true);
        }
        return new PoTokenResult(vd, player, sp);
    }

    /** @return true if the generator was (re)created. */
    private boolean ensure(boolean force) throws Exception {
        synchronized (lock) {
            if (gen != null && !force && !gen.expired()) return false;
            if (gen != null) { final Gen old = gen; new Handler(Looper.getMainLooper()).post(old::close); }
            gen = null;
            String vd = fetchVisitorData();
            Gen g = Gen.create(app);
            String sp = g.mint(vd); // the streaming poToken must be minted once, first
            gen = g;
            visitorData = vd;
            streamingPot = sp;
            return true;
        }
    }

    private static String clientVersion() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return "2." + f.format(new Date(System.currentTimeMillis() - 6L * 24 * 3600 * 1000)) + ".00.00";
    }

    private static String fetchVisitorData() throws Exception {
        JSONObject body = new JSONObject().put("context", new JSONObject().put("client",
            new JSONObject().put("clientName", "WEB").put("clientVersion", clientVersion())
                .put("hl", "en").put("gl", "US")));
        Request r = new Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/visitor_id?prettyPrint=false")
            .header("User-Agent", UA).header("Origin", "https://www.youtube.com")
            .header("X-Goog-Api-Format-Version", "1")
            .post(RequestBody.create(body.toString(), MediaType.parse("application/json"))).build();
        try (Response resp = Net.HTTP.newCall(r).execute()) {
            if (!resp.isSuccessful() || resp.body() == null) throw new Exception("visitor_id HTTP " + resp.code());
            JSONObject o = new JSONObject(resp.body().string());
            JSONObject rc = o.optJSONObject("responseContext");
            String vd = rc == null ? "" : rc.optString("visitorData", "");
            if (vd.isEmpty()) throw new Exception("no visitorData");
            return vd;
        }
    }

    // ------------------------------------------------------------------ helpers (ported)

    private static byte[] ytBase64(String s) {
        return Base64.decode(s.replace('-', '+').replace('_', '/').replace('.', '='), Base64.DEFAULT);
    }

    private static String u8Literal(byte[] b) {
        StringBuilder sb = new StringBuilder("new Uint8Array([");
        for (int i = 0; i < b.length; i++) { if (i > 0) sb.append(','); sb.append(b[i] & 0xFF); }
        return sb.append("])").toString();
    }

    private static String firstString(JSONArray a) {
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) if (a.opt(i) instanceof String) return a.optString(i);
        return null;
    }

    private static String parseChallenge(String raw) throws Exception {
        JSONArray scrambled = new JSONArray(raw);
        JSONArray cd;
        if (scrambled.length() > 1 && scrambled.opt(1) instanceof String) {
            byte[] b = ytBase64(scrambled.getString(1));
            for (int i = 0; i < b.length; i++) b[i] = (byte) (b[i] + 97);
            cd = new JSONArray(new String(b, StandardCharsets.UTF_8));
        } else {
            cd = scrambled.getJSONArray(1);
        }
        JSONObject interp = new JSONObject();
        String script = firstString(cd.optJSONArray(1)), url = firstString(cd.optJSONArray(2));
        if (script != null) interp.put("privateDoNotAccessOrElseSafeScriptWrappedValue", script);
        if (url != null) interp.put("privateDoNotAccessOrElseTrustedResourceUrlWrappedValue", url);
        return new JSONObject().put("messageId", cd.getString(0)).put("interpreterJavascript", interp)
            .put("interpreterHash", cd.getString(3)).put("program", cd.getString(4))
            .put("globalName", cd.getString(5)).put("clientExperimentsStateBlob", cd.getString(7)).toString();
    }

    private static String post(String url, String data) throws Exception {
        Request r = new Request.Builder().url(url).header("User-Agent", UA).header("Accept", "application/json")
            .header("x-goog-api-key", GOOGLE_API_KEY).header("x-user-agent", "grpc-web-javascript/0.1")
            .post(RequestBody.create(data.getBytes(StandardCharsets.UTF_8), PROTO_JSON)).build();
        try (Response resp = Net.HTTP.newCall(r).execute()) {
            if (resp.code() != 200 || resp.body() == null) throw new Exception("BotGuard HTTP " + resp.code());
            return resp.body().string();
        }
    }

    // ------------------------------------------------------------------ the WebView that runs BotGuard

    private static final class Pending {
        final CountDownLatch latch = new CountDownLatch(1);
        volatile String result;
        volatile String error;
    }

    static final class Gen {
        private WebView wv;
        private final Handler main = new Handler(Looper.getMainLooper());
        private final CountDownLatch initLatch = new CountDownLatch(1);
        private volatile String initError;
        private volatile long expiresAt = 0;
        private final List<Object[]> pending = new ArrayList<>(); // {identifier, Pending}

        static Gen create(final Context ctx) throws Exception {
            final Gen g = new Gen();
            final String html;
            try (InputStream in = ctx.getAssets().open("po_token.html")) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                html = bo.toString("UTF-8");
            }
            boolean ok = g.main.post(() -> {
                try { g.start(ctx, html); } catch (Throwable t) { g.fail(String.valueOf(t)); }
            });
            if (!ok) throw new Exception("main thread unavailable");
            if (!g.initLatch.await(45, TimeUnit.SECONDS)) { g.close(); throw new Exception("poToken init timeout"); }
            if (g.initError != null) { g.close(); throw new Exception(g.initError); }
            return g;
        }

        private void fail(String e) {
            if (initError == null && initLatch.getCount() > 0) initError = e;
            initLatch.countDown();
            synchronized (pending) {
                for (Object[] p : pending) { ((Pending) p[1]).error = e; ((Pending) p[1]).latch.countDown(); }
                pending.clear();
            }
        }

        private void start(Context ctx, String html) {
            wv = new WebView(ctx);
            WebSettings s = wv.getSettings();
            s.setJavaScriptEnabled(true);
            if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(false);
            s.setUserAgentString(UA);
            s.setBlockNetworkLoads(true);
            wv.addJavascriptInterface(this, "PoTokenWebView");
            wv.setWebChromeClient(new WebChromeClient() {
                @Override public boolean onConsoleMessage(ConsoleMessage m) {
                    if (m.message().contains("Uncaught")) {
                        INSTANCE.webViewBroken = m.message().contains("SyntaxError");
                        fail("WebView error: " + m.message());
                    }
                    return super.onConsoleMessage(m);
                }
            });
            wv.loadDataWithBaseURL("https://www.youtube.com",
                html.replaceFirst("</script>", "\nPoTokenWebView.downloadAndRunBotguard()</script>"),
                "text/html", "utf-8", null);
        }

        @JavascriptInterface public void downloadAndRunBotguard() {
            new Thread(() -> {
                try {
                    String raw = post("https://www.youtube.com/api/jnn/v1/Create", "[ \"" + REQUEST_KEY + "\" ]");
                    final String data = parseChallenge(raw);
                    main.post(() -> wv.evaluateJavascript(
                        "try { data = " + data + "\n"
                        + "runBotGuard(data).then(function (result) {\n"
                        + "  this.webPoSignalOutput = result.webPoSignalOutput\n"
                        + "  PoTokenWebView.onRunBotguardResult(result.botguardResponse)\n"
                        + "}, function (error) {\n"
                        + "  PoTokenWebView.onJsInitializationError(error + \"\\n\" + error.stack)\n"
                        + "})\n"
                        + "} catch (error) {\n"
                        + "  PoTokenWebView.onJsInitializationError(error + \"\\n\" + error.stack)\n"
                        + "}", null));
                } catch (Throwable t) { fail(String.valueOf(t)); }
            }).start();
        }

        @JavascriptInterface public void onJsInitializationError(String error) { fail(error); }

        @JavascriptInterface public void onRunBotguardResult(final String botguardResponse) {
            new Thread(() -> {
                try {
                    String raw = post("https://www.youtube.com/api/jnn/v1/GenerateIT",
                        "[ \"" + REQUEST_KEY + "\", \"" + botguardResponse + "\" ]");
                    JSONArray a = new JSONArray(raw);
                    final String u8 = u8Literal(ytBase64(a.getString(0)));
                    final long ttl = a.getLong(1);
                    main.post(() -> wv.evaluateJavascript("this.integrityToken = " + u8, v -> {
                        expiresAt = System.currentTimeMillis() + Math.max(60, ttl - 600) * 1000L;
                        initLatch.countDown();
                    }));
                } catch (Throwable t) { fail(String.valueOf(t)); }
            }).start();
        }

        boolean expired() { return System.currentTimeMillis() > expiresAt; }

        /** Blocking: returns the poToken (YouTube base64) for [identifier]. Must not be called on the main thread. */
        String mint(final String identifier) throws Exception {
            final Pending p = new Pending();
            synchronized (pending) { pending.add(new Object[]{identifier, p}); }
            final String lit = JSONObject.quote(identifier);
            final String u8 = u8Literal(identifier.getBytes(StandardCharsets.UTF_8));
            boolean ok = main.post(() -> wv.evaluateJavascript(
                "try {\n identifier = " + lit + "\n u8Identifier = " + u8 + "\n"
                + " poTokenU8 = obtainPoToken(webPoSignalOutput, integrityToken, u8Identifier)\n"
                + " poTokenU8String = \"\"\n"
                + " for (i = 0; i < poTokenU8.length; i++) { if (i != 0) poTokenU8String += \",\"; poTokenU8String += poTokenU8[i] }\n"
                + " PoTokenWebView.onObtainPoTokenResult(identifier, poTokenU8String)\n"
                + "} catch (error) {\n PoTokenWebView.onObtainPoTokenError(identifier, error + \"\\n\" + error.stack)\n}", null));
            if (!ok) throw new Exception("main thread unavailable");
            if (!p.latch.await(25, TimeUnit.SECONDS)) throw new Exception("poToken timeout");
            if (p.error != null) throw new Exception(p.error);
            return p.result;
        }

        private Pending pop(String identifier) {
            synchronized (pending) {
                for (int i = 0; i < pending.size(); i++) {
                    if (pending.get(i)[0].equals(identifier)) return (Pending) pending.remove(i)[1];
                }
            }
            return null;
        }

        @JavascriptInterface public void onObtainPoTokenError(String identifier, String error) {
            Pending p = pop(identifier);
            if (p != null) { p.error = error; p.latch.countDown(); }
        }

        @JavascriptInterface public void onObtainPoTokenResult(String identifier, String u8) {
            Pending p = pop(identifier);
            if (p == null) return;
            try {
                String[] parts = u8.split(",");
                byte[] b = new byte[parts.length];
                for (int i = 0; i < parts.length; i++) b[i] = (byte) Integer.parseInt(parts[i].trim());
                p.result = Base64.encodeToString(b, Base64.NO_WRAP).replace('+', '-').replace('/', '_');
            } catch (Exception e) {
                p.error = String.valueOf(e);
            }
            p.latch.countDown();
        }

        void close() {
            main.post(() -> {
                try {
                    if (wv != null) { wv.loadUrl("about:blank"); wv.onPause(); wv.removeAllViews(); wv.destroy(); wv = null; }
                } catch (Throwable ignored) { }
            });
        }
    }
}
