package com.manik.youtubeweb;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.ListExtractor;
import org.schabi.newpipe.extractor.Page;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.comments.CommentsInfo;
import org.schabi.newpipe.extractor.comments.CommentsInfoItem;
import org.schabi.newpipe.extractor.stream.Description;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * YouTube comments. Reading uses NewPipeExtractor; posting uses YouTube's own web API with the signed-in session
 * (the same call youtube.com makes when you press "Comment").
 */
final class Comments {
    private Comments() {}

    static final class C {
        String id = "", author = "", avatar = "", text = "", date = "", likes = "";
        boolean html, pinned, mine;
        int replyCount;
        Page replies;
    }

    static final class Res {
        final List<C> items = new ArrayList<>();
        Page next;
    }

    private static String nz(String s) { return s == null ? "" : s; }

    private static String watchUrl(String id) { return "https://www.youtube.com/watch?v=" + id; }

    private static void convert(List<CommentsInfoItem> in, Res out) {
        if (in == null) return;
        for (CommentsInfoItem it : in) {
            if (it == null) continue;
            C c = new C();
            c.id = nz(it.getCommentId());
            c.author = nz(it.getUploaderName());
            c.avatar = Yt.bestImage(it.getUploaderAvatars());
            Description d = it.getCommentText();
            if (d != null) { c.text = nz(d.getContent()); c.html = d.getType() == Description.HTML; }
            c.date = nz(it.getTextualUploadDate());
            int lk = it.getLikeCount();
            c.likes = lk > 0 ? Ui.count(lk) : "";
            c.pinned = it.isPinned();
            c.replyCount = it.getReplyCount();
            c.replies = it.getReplies();
            out.items.add(c);
        }
    }

    static Res first(String videoId) throws Exception {
        CommentsInfo ci = CommentsInfo.getInfo(ServiceList.YouTube, watchUrl(videoId));
        Res r = new Res();
        convert(ci.getRelatedItems(), r);
        r.next = ci.getNextPage();
        return r;
    }

    /** Next page of comments, or the replies of one comment (pass that comment's replies page). */
    static Res more(String videoId, Page page) throws Exception {
        ListExtractor.InfoItemsPage<CommentsInfoItem> p =
            CommentsInfo.getMoreItems(ServiceList.YouTube, watchUrl(videoId), page);
        Res r = new Res();
        convert(p.getItems(), r);
        r.next = p.getNextPage();
        return r;
    }

    // ------------------------------------------------------------------ count + posting (YouTube web API)

    private static String commentsToken(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            if ("comment-item-section".equals(o.optString("sectionIdentifier"))
                    || "comments-section".equals(o.optString("targetId"))
                    || "engagement-panel-comments-section".equals(o.optString("panelIdentifier"))) {
                String t = tokenIn(o);
                if (t != null) return t;
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = commentsToken(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = commentsToken(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private static String tokenIn(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject c = o.optJSONObject("continuationItemRenderer");
            if (c != null) {
                String t = firstString(c, "token");
                if (t != null) return t;
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String t = tokenIn(o.opt(keys.next()));
                if (t != null) return t;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String t = tokenIn(a.opt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private static String firstString(Object node, String key) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            Object v = o.opt(key);
            if (v instanceof String && !((String) v).isEmpty()) return (String) v;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String r = firstString(o.opt(it.next()), key);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String r = firstString(a.opt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static JSONObject findObj(Object node, String key) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject hit = o.optJSONObject(key);
            if (hit != null) return hit;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                JSONObject r = findObj(o.opt(it.next()), key);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                JSONObject r = findObj(a.opt(i), key);
                if (r != null) return r;
            }
        }
        return null;
    }

    /** Returns {countText, createCommentParams}; either can be empty/null (e.g. comments off, or signed out). */
    static String[] header(Context c, String videoId) throws Exception {
        JSONObject next = Auth.nextInfo(c, videoId);
        String tok = commentsToken(next);
        if (tok == null) return new String[]{"", null};
        JSONObject res = Auth.postAny(c, "next", new JSONObject().put("continuation", tok));
        String params = firstString(res, "createCommentParams");
        String count = "";
        JSONObject hdr = findObj(res, "commentsHeaderRenderer");
        if (hdr != null) {
            count = Auth.textOf(hdr.opt("countText"));
            if (count.isEmpty()) {
                JSONObject cc = hdr.optJSONObject("commentCount");
                count = cc == null ? "" : Auth.textOf(cc);
            }
        }
        count = count.replaceAll("(?i)\\s*comments?\\s*", "").trim();
        return new String[]{count, params};
    }

    static void post(Context c, String videoId, String text) throws Exception {
        String[] h = header(c, videoId);
        if (h[1] == null || h[1].isEmpty())
            throw new Exception("The comment box isn't available for this video (comments may be turned off).");
        Auth.post(c, "comment/create_comment",
            new JSONObject().put("commentText", text).put("createCommentParams", h[1]));
    }
}
