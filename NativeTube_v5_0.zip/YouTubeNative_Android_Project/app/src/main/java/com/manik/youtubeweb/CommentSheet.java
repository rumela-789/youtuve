package com.manik.youtubeweb;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.Html;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import org.schabi.newpipe.extractor.Page;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Comments bottom sheet that can be opened straight from a feed card (read, scroll, reply list and post). */
final class CommentSheet {
    private final Activity act;
    private final String videoId;
    private final Runnable needLogin;
    private final SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final List<Comments.C> cmts = new ArrayList<>();
    private Page next;
    private boolean loading = true, failed = false, closed = false;
    private String count = "";
    private Dialog dlg;
    private LinearLayout list;
    private ScrollView scroll;
    private TextView countTv;

    private CommentSheet(Activity a, String id, Runnable needLogin) {
        this.act = a;
        this.videoId = id;
        this.needLogin = needLogin;
        this.prefs = Ui.prefs(a);
    }

    static void show(Activity a, String videoId, Runnable needLogin) {
        if (videoId == null || videoId.isEmpty()) return;
        new CommentSheet(a, videoId, needLogin).open();
    }

    private void ui(Runnable r) {
        if (closed || act.isFinishing()) return;
        act.runOnUiThread(r);
    }

    // ------------------------------------------------------------------ loading

    private void load() {
        loading = true;
        failed = false;
        pool.execute(new Runnable() {
            @Override public void run() {
                Comments.Res r = null;
                String[] h = null;
                boolean bad = false;
                try { r = Comments.first(videoId); } catch (Exception e) { bad = true; }
                try { h = Comments.header(act, videoId); } catch (Exception ignored) { }
                final Comments.Res fr = r;
                final String[] fh = h;
                final boolean fb = bad;
                ui(new Runnable() {
                    @Override public void run() {
                        loading = false;
                        failed = fb;
                        if (fr != null) { cmts.addAll(fr.items); next = fr.next; }
                        if (fh != null) count = fh[0];
                        refresh();
                    }
                });
            }
        });
    }

    private void loadMore() {
        if (loading || next == null) return;
        loading = true;
        final Page pg = next;
        pool.execute(new Runnable() {
            @Override public void run() {
                Comments.Res r = null;
                try { r = Comments.more(videoId, pg); } catch (Exception ignored) { }
                final Comments.Res fr = r;
                ui(new Runnable() {
                    @Override public void run() {
                        loading = false;
                        if (fr != null) { cmts.addAll(fr.items); next = fr.next; } else { next = null; }
                        refresh();
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------ UI

    private void open() {
        final Dialog d = new Dialog(act);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(Ui.bg);
        float r = Ui.dp(16);
        bgd.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bgd);

        LinearLayout head = new LinearLayout(act);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(16), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        head.addView(Ui.text(act, "Comments", 17, true, Ui.fg));
        countTv = Ui.text(act, "", 14, false, Ui.muted);
        countTv.setPadding(Ui.dp(8), 0, 0, 0);
        head.addView(countTv);
        head.addView(new View(act), new LinearLayout.LayoutParams(0, 1, 1));
        ImageView x = Ui.icon(act, R.drawable.ic_close, Ui.fg, 22);
        x.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        x.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); }
        });
        head.addView(x, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        box.addView(head);
        View d1 = new View(act);
        d1.setBackgroundColor(Ui.line);
        box.addView(d1, new LinearLayout.LayoutParams(-1, 1));

        scroll = new ScrollView(act);
        list = new LinearLayout(act);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(16));
        scroll.addView(list);
        scroll.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override public void onScrollChange(View v, int sx, int sy, int ox, int oy) {
                View c = scroll.getChildAt(0);
                if (c != null && c.getBottom() - (scroll.getHeight() + sy) < Ui.dp(240)) loadMore();
            }
        });
        box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        View d2 = new View(act);
        d2.setBackgroundColor(Ui.line);
        box.addView(d2, new LinearLayout.LayoutParams(-1, 1));
        LinearLayout in = new LinearLayout(act);
        in.setGravity(Gravity.CENTER_VERTICAL);
        in.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        final boolean signed = Auth.signedIn(act);
        View me = avatarView(signed ? prefs.getString("acct_photo", "") : "", signed ? prefs.getString("acct_name", "") : "", 34);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(34));
        mp.rightMargin = Ui.dp(10);
        in.addView(me, mp);
        final EditText field = new EditText(act);
        field.setHint(signed ? "Add a comment…" : "Sign in to comment");
        field.setHintTextColor(Ui.muted);
        field.setTextColor(Ui.fg);
        field.setTextSize(14.5f);
        field.setMaxLines(4);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        field.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        field.setBackground(Ui.rect(Ui.surface, 20));
        if (!signed) {
            field.setFocusable(false);
            field.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { askLogin(d); }
            });
        }
        in.addView(field, new LinearLayout.LayoutParams(0, -2, 1));
        final ImageView send = Ui.icon(act, R.drawable.ic_send, Ui.link, 22);
        send.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        send.setContentDescription("Post comment");
        send.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!Auth.signedIn(act)) { askLogin(d); return; }
                final String text = field.getText().toString().trim();
                if (text.isEmpty()) return;
                send.setEnabled(false);
                send.setAlpha(0.4f);
                pool.execute(new Runnable() {
                    @Override public void run() {
                        String err = null;
                        try { Comments.post(act, videoId, text); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
                        final String fe = err;
                        ui(new Runnable() {
                            @Override public void run() {
                                send.setEnabled(true);
                                send.setAlpha(1f);
                                if (fe != null) {
                                    Toast.makeText(act, "Couldn't post comment: " + fe, Toast.LENGTH_LONG).show();
                                    return;
                                }
                                field.setText("");
                                InputMethodManager imm = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE);
                                if (imm != null) imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
                                Comments.C c = new Comments.C();
                                c.author = prefs.getString("acct_name", "You");
                                c.avatar = prefs.getString("acct_photo", "");
                                c.text = text;
                                c.date = "just now";
                                c.mine = true;
                                cmts.add(0, c);
                                refresh();
                                scroll.post(new Runnable() { @Override public void run() { scroll.scrollTo(0, 0); } });
                                Toast.makeText(act, "Comment posted", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }
        });
        in.addView(send, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        box.addView(in);

        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int) (act.getResources().getDisplayMetrics().heightPixels * 0.78f));
            w.setGravity(Gravity.BOTTOM);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            w.setDimAmount(0.55f);
        }
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface di) {
                closed = true;
                pool.shutdownNow();
            }
        });
        dlg = d;
        refresh();
        d.show();
        load();
    }

    private void askLogin(Dialog d) {
        d.dismiss();
        if (needLogin != null) needLogin.run();
    }

    private CharSequence commentText(Comments.C c) {
        if (c.html) return Build.VERSION.SDK_INT >= 24 ? Html.fromHtml(c.text, 0) : Html.fromHtml(c.text);
        return c.text;
    }

    private void refresh() {
        if (list == null) return;
        countTv.setText(count);
        list.removeAllViews();
        if (cmts.isEmpty()) {
            String m = loading ? "Loading comments…"
                : (failed ? "Couldn't load comments (they may be turned off)." : "No comments yet. Be the first!");
            TextView t = Ui.text(act, m, 14, false, Ui.muted);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(40), 0, Ui.dp(40));
            list.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        for (Comments.C c : cmts) list.addView(commentView(c, false), new LinearLayout.LayoutParams(-1, -2));
        if (next != null || loading) {
            ProgressBar pb = new ProgressBar(act);
            pb.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(26), Ui.dp(26));
            pp.gravity = Gravity.CENTER_HORIZONTAL;
            pp.topMargin = Ui.dp(12);
            list.addView(pb, pp);
        }
    }

    private View avatarView(String url, String name, int sizeDp) {
        FrameLayout f = new FrameLayout(act);
        String n = name == null ? "" : name.replace("@", "").trim();
        int hue = Math.abs(n.hashCode()) % 360;
        f.setBackground(Ui.oval(Color.HSVToColor(new float[]{hue, 0.45f, 0.55f})));
        TextView tv = Ui.text(act, n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase(), sizeDp / 2.3f, true, 0xFFFFFFFF);
        tv.setGravity(Gravity.CENTER);
        f.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        if (url != null && !url.isEmpty()) {
            if (url.startsWith("//")) url = "https:" + url;
            ImageView iv = new ImageView(act);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            Glide.with(act.getApplicationContext()).load(url).override(Ui.dp(sizeDp) * 2).circleCrop().into(iv);
        }
        return f;
    }

    private View commentView(final Comments.C c, boolean reply) {
        LinearLayout row = new LinearLayout(act);
        row.setPadding(0, Ui.dp(10), 0, Ui.dp(6));
        int sz = reply ? 24 : 36;
        View av = avatarView(c.avatar, c.author, sz);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(sz), Ui.dp(sz));
        ap.rightMargin = Ui.dp(12);
        row.addView(av, ap);

        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        if (c.pinned) col.addView(Ui.text(act, "Pinned", 11, true, Ui.muted));
        String head = c.author + (c.date.isEmpty() ? "" : "  ·  " + c.date);
        TextView h = Ui.text(act, head, 12, false, Ui.muted);
        h.setMaxLines(1);
        h.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(h);
        TextView body = Ui.text(act, "", 14, false, Ui.fg);
        body.setText(commentText(c));
        body.setTextIsSelectable(true);
        body.setPadding(0, Ui.dp(3), 0, 0);
        col.addView(body);

        LinearLayout act2 = new LinearLayout(act);
        act2.setGravity(Gravity.CENTER_VERTICAL);
        act2.setPadding(0, Ui.dp(6), 0, 0);
        ImageView lk = Ui.icon(act, R.drawable.ic_like, Ui.muted, 16);
        act2.addView(lk, new LinearLayout.LayoutParams(Ui.dp(16), Ui.dp(16)));
        if (!c.likes.isEmpty()) {
            TextView lt = Ui.text(act, c.likes, 12, false, Ui.muted);
            lt.setPadding(Ui.dp(6), 0, 0, 0);
            act2.addView(lt);
        }
        col.addView(act2);

        if (!reply && c.replyCount > 0 && c.replies != null) {
            final LinearLayout repliesBox = new LinearLayout(act);
            repliesBox.setOrientation(LinearLayout.VERTICAL);
            final TextView more = Ui.text(act, c.replyCount + (c.replyCount == 1 ? " reply" : " replies"), 13, true, Ui.link);
            more.setPadding(0, Ui.dp(6), 0, Ui.dp(2));
            final Page[] tok = {c.replies};
            more.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (tok[0] == null) return;
                    final Page pg = tok[0];
                    tok[0] = null;
                    more.setText("Loading…");
                    pool.execute(new Runnable() {
                        @Override public void run() {
                            Comments.Res r = null;
                            try { r = Comments.more(videoId, pg); } catch (Exception ignored) { }
                            final Comments.Res fr = r;
                            ui(new Runnable() {
                                @Override public void run() {
                                    if (fr == null) { tok[0] = pg; more.setText("Couldn't load replies · tap to retry"); return; }
                                    for (Comments.C rc : fr.items) repliesBox.addView(commentView(rc, true), new LinearLayout.LayoutParams(-1, -2));
                                    tok[0] = fr.next;
                                    if (fr.next != null) more.setText("Show more replies"); else more.setVisibility(View.GONE);
                                }
                            });
                        }
                    });
                }
            });
            col.addView(more);
            col.addView(repliesBox);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        return row;
    }
}
