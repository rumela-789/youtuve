package com.manik.youtubeweb;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.media3.common.C;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

/** Custom YouTube-style player overlay: big centre controls, thin red seek bar, double-tap to skip, speed, quality, fullscreen. */
final class PlayerControls extends FrameLayout {
    interface Host { void onBack(); void onFullscreen(); void onSettings(); }

    private static final long SKIP_MS = 10_000;
    private static final float[] SPEEDS = {0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f};

    private final Host host;
    private ExoPlayer p;
    private final FrameLayout group;
    private final ImageView playBtn, fsBtn;
    private final View playWrap;
    private final TextView time, speedTxt, feedback;
    private final Seek seek;
    private boolean shown = true, scrubbing = false;
    private float scrubFrac = 0f;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final GestureDetector gd;

    private final Runnable hideR = () -> { if (p != null && p.getPlayWhenReady() && !scrubbing) hide(); };
    private final Runnable fbHide = new Runnable() { @Override public void run() { feedback.setVisibility(View.GONE); } };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            if (p != null) h.postDelayed(this, shown ? 250 : 500);
        }
    };
    private final Player.Listener listener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int s) { refresh(); schedHide(); }
        @Override public void onPlayWhenReadyChanged(boolean pwr, int r) { refresh(); schedHide(); }
    };

    PlayerControls(Context c, Host host) {
        super(c);
        this.host = host;
        setClickable(true);

        group = new FrameLayout(c);
        addView(group, new LayoutParams(-1, -1));

        View st = new View(c);
        st.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xB3000000, 0x00000000}));
        group.addView(st, new LayoutParams(-1, Ui.dp(96), Gravity.TOP));
        View sb = new View(c);
        sb.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xCC000000, 0x00000000}));
        group.addView(sb, new LayoutParams(-1, Ui.dp(120), Gravity.BOTTOM));

        // top bar
        LinearLayout top = new LinearLayout(c);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), 0);
        ImageView back = Ui.icon(c, R.drawable.ic_chevron_down, 0xFFFFFFFF, 26);
        back.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        back.setContentDescription("Minimize");
        back.setOnClickListener(v -> host.onBack());
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(46)));
        top.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 1));
        speedTxt = Ui.text(c, "1x", 13, true, 0xFFFFFFFF);
        speedTxt.setGravity(Gravity.CENTER);
        speedTxt.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(6));
        speedTxt.setBackground(Ui.rect(0x55000000, 16));
        speedTxt.setOnClickListener(v -> pickSpeed());
        top.addView(speedTxt, new LinearLayout.LayoutParams(-2, -2));
        ImageView gear = Ui.icon(c, R.drawable.ic_settings, 0xFFFFFFFF, 24);
        gear.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        gear.setContentDescription("Quality");
        gear.setOnClickListener(v -> host.onSettings());
        top.addView(gear, new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(46)));
        group.addView(top, new LayoutParams(-1, -2, Gravity.TOP));

        // centre: -10 | play/pause | +10
        LinearLayout center = new LinearLayout(c);
        center.setGravity(Gravity.CENTER);
        center.addView(skipButton(c, false), new LinearLayout.LayoutParams(Ui.dp(54), Ui.dp(54)));
        FrameLayout pw = new FrameLayout(c);
        pw.setBackground(Ui.oval(0x66000000));
        playBtn = Ui.icon(c, R.drawable.ic_pause, 0xFFFFFFFF, 36);
        playBtn.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(14));
        pw.addView(playBtn, new LayoutParams(-1, -1));
        pw.setOnClickListener(v -> togglePlay());
        playWrap = pw;
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(66), Ui.dp(66));
        pp.leftMargin = Ui.dp(30);
        pp.rightMargin = Ui.dp(30);
        center.addView(pw, pp);
        center.addView(skipButton(c, true), new LinearLayout.LayoutParams(Ui.dp(54), Ui.dp(54)));
        group.addView(center, new LayoutParams(-2, -2, Gravity.CENTER));

        // bottom row: time + fullscreen
        time = Ui.text(c, "0:00 / 0:00", 12.5f, true, 0xFFFFFFFF);
        LayoutParams tp = new LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        tp.leftMargin = Ui.dp(14);
        tp.bottomMargin = Ui.dp(26);
        group.addView(time, tp);
        fsBtn = Ui.icon(c, R.drawable.ic_fullscreen, 0xFFFFFFFF, 22);
        fsBtn.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        fsBtn.setContentDescription("Fullscreen");
        fsBtn.setOnClickListener(v -> host.onFullscreen());
        LayoutParams fp = new LayoutParams(Ui.dp(44), Ui.dp(44), Gravity.BOTTOM | Gravity.END);
        fp.rightMargin = Ui.dp(6);
        fp.bottomMargin = Ui.dp(14);
        group.addView(fsBtn, fp);

        seek = new Seek(c);
        addView(seek, new LayoutParams(-1, Ui.dp(30), Gravity.BOTTOM));

        feedback = Ui.text(c, "", 13, true, 0xFFFFFFFF);
        feedback.setGravity(Gravity.CENTER);
        feedback.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        feedback.setBackground(Ui.rect(0x88000000, 20));
        feedback.setVisibility(View.GONE);
        addView(feedback, new LayoutParams(-2, -2, Gravity.CENTER));

        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { toggle(); return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                float x = e.getX();
                int w = getWidth();
                if (x < w * 0.38f) skip(-SKIP_MS, e.getX());
                else if (x > w * 0.62f) skip(SKIP_MS, e.getX());
                else togglePlay();
                return true;
            }
        });
    }

    private View skipButton(Context c, boolean fwd) {
        FrameLayout f = new FrameLayout(c);
        ImageView ic = Ui.icon(c, R.drawable.ic_replay, 0xFFFFFFFF, 34);
        ic.setScaleX(fwd ? -1f : 1f);
        ic.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        f.addView(ic, new LayoutParams(-1, -1));
        TextView t = Ui.text(c, "10", 10, true, 0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(3), 0, 0);
        f.addView(t, new LayoutParams(-1, -1));
        f.setContentDescription(fwd ? "Forward 10 seconds" : "Back 10 seconds");
        f.setOnClickListener(v -> { skipNoFb(fwd ? SKIP_MS : -SKIP_MS); schedHide(); });
        return f;
    }

    // ------------------------------------------------------------------ public API

    void setPlayer(ExoPlayer player) {
        detach();
        p = player;
        if (p != null) {
            p.addListener(listener);
            speedTxt.setText(fmtSpeed(p.getPlaybackParameters().speed));
            h.post(tick);
        }
        refresh();
        schedHide();
    }

    void detach() {
        h.removeCallbacksAndMessages(null);
        if (p != null) p.removeListener(listener);
        p = null;
    }

    void setFull(boolean full) {
        fsBtn.setImageResource(full ? R.drawable.ic_fullscreen_exit : R.drawable.ic_fullscreen);
    }

    // ------------------------------------------------------------------ behaviour

    @Override public boolean onTouchEvent(MotionEvent e) {
        gd.onTouchEvent(e);
        return true;
    }

    private void toggle() {
        if (shown) hide(); else { show(); schedHide(); }
    }

    private void show() {
        h.removeCallbacks(hideR);
        shown = true;
        group.setVisibility(View.VISIBLE);
        group.animate().cancel();
        group.animate().alpha(1f).setDuration(150).start();
        seek.setExpanded(true);
    }

    private void hide() {
        shown = false;
        seek.setExpanded(false);
        group.animate().cancel();
        group.animate().alpha(0f).setDuration(200).withEndAction(() -> { if (!shown) group.setVisibility(View.GONE); }).start();
    }

    private void schedHide() {
        h.removeCallbacks(hideR);
        if (p != null && p.getPlayWhenReady() && shown && !scrubbing) h.postDelayed(hideR, 3200);
    }

    private void togglePlay() {
        if (p == null) return;
        if (p.getPlaybackState() == Player.STATE_ENDED) { p.seekTo(0); p.play(); }
        else if (p.getPlayWhenReady()) p.pause();
        else p.play();
        schedHide();
    }

    private void skipNoFb(long delta) {
        if (p == null) return;
        long d = p.getDuration();
        long t = p.getCurrentPosition() + delta;
        if (d != C.TIME_UNSET && d > 0) t = Math.min(t, d);
        p.seekTo(Math.max(0, t));
        refresh();
    }

    private void skip(long delta, float x) {
        skipNoFb(delta);
        feedback.setText(delta < 0 ? "‹‹  10 sec" : "10 sec  ››");
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) feedback.getLayoutParams();
        lp.gravity = Gravity.CENTER_VERTICAL | (delta < 0 ? Gravity.START : Gravity.END);
        lp.leftMargin = delta < 0 ? Ui.dp(40) : 0;
        lp.rightMargin = delta > 0 ? Ui.dp(40) : 0;
        feedback.setLayoutParams(lp);
        feedback.setVisibility(View.VISIBLE);
        h.removeCallbacks(fbHide);
        h.postDelayed(fbHide, 650);
    }

    private void pickSpeed() {
        if (p == null) return;
        String[] names = new String[SPEEDS.length];
        int cur = 3;
        float now = p.getPlaybackParameters().speed;
        for (int i = 0; i < SPEEDS.length; i++) {
            names[i] = i == 3 ? "Normal" : fmtSpeed(SPEEDS[i]);
            if (Math.abs(SPEEDS[i] - now) < 0.01f) cur = i;
        }
        new AlertDialog.Builder(getContext(), Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Playback speed")
            .setSingleChoiceItems(names, cur, (d, w) -> {
                if (p != null) p.setPlaybackSpeed(SPEEDS[w]);
                speedTxt.setText(fmtSpeed(SPEEDS[w]));
                d.dismiss();
            }).show();
    }

    private static String fmtSpeed(float s) {
        return (s == (int) s ? String.valueOf((int) s) : String.valueOf(s)) + "x";
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms) / 1000;
        long hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return hh > 0 ? String.format("%d:%02d:%02d", hh, mm, ss) : String.format("%d:%02d", mm, ss);
    }

    private void refresh() {
        if (p == null) return;
        int st = p.getPlaybackState();
        boolean playing = p.getPlayWhenReady() && st != Player.STATE_ENDED && st != Player.STATE_IDLE;
        playBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        playWrap.setVisibility(st == Player.STATE_BUFFERING && p.getPlayWhenReady() ? View.INVISIBLE : View.VISIBLE);
        long d = p.getDuration();
        boolean live = d == C.TIME_UNSET || d <= 0 || p.isCurrentMediaItemLive();
        long pos = scrubbing && !live ? (long) (scrubFrac * d) : p.getCurrentPosition();
        if (live) {
            seek.set(0f, 0f);
            time.setText("LIVE");
        } else {
            seek.set(Math.min(1f, pos / (float) d), Math.min(1f, p.getBufferedPosition() / (float) d));
            time.setText(fmt(pos) + "  /  " + fmt(d));
        }
    }

    // ------------------------------------------------------------------ seek bar

    private final class Seek extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float pos = 0f, buf = 0f;
        private boolean expanded = true, drag = false;

        Seek(Context c) { super(c); }

        void set(float position, float buffered) {
            if (drag) return;
            pos = position;
            buf = buffered;
            invalidate();
        }

        void setExpanded(boolean e) { expanded = e; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float padL = expanded ? Ui.dp(14) : 0, padR = padL;
            float w = getWidth() - padL - padR;
            float cy = getHeight() - Ui.dp(expanded ? 12 : 1.5f);
            float th = Ui.dp(drag ? 5 : (expanded ? 3.5f : 3));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x55FFFFFF);
            cv.drawRect(padL, cy - th / 2, padL + w, cy + th / 2, paint);
            paint.setColor(0x88FFFFFF);
            cv.drawRect(padL, cy - th / 2, padL + w * buf, cy + th / 2, paint);
            paint.setColor(0xFFFF0000);
            cv.drawRect(padL, cy - th / 2, padL + w * pos, cy + th / 2, paint);
            if (expanded) cv.drawCircle(padL + w * pos, cy, Ui.dp(drag ? 9 : 6.5f), paint);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (!expanded && !drag) return false;      // let the overlay show the controls first
            float padL = Ui.dp(14);
            float w = getWidth() - padL * 2;
            float f = Math.max(0f, Math.min(1f, (e.getX() - padL) / w));
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    drag = true;
                    scrubbing = true;
                    h.removeCallbacks(hideR);
                    pos = f; scrubFrac = f;
                    invalidate();
                    refresh();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    pos = f; scrubFrac = f;
                    invalidate();
                    refresh();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    drag = false;
                    scrubbing = false;
                    if (p != null && e.getActionMasked() == MotionEvent.ACTION_UP) {
                        long d = p.getDuration();
                        if (d != C.TIME_UNSET && d > 0) p.seekTo((long) (f * d));
                    }
                    invalidate();
                    schedHide();
                    return true;
                default:
                    return true;
            }
        }
    }
}
