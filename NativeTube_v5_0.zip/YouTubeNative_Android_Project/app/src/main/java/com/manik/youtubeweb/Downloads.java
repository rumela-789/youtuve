package com.manik.youtubeweb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** "Download" button logic: reads the video's streams, lets the person pick a quality, then hands off to DownloadService. */
final class Downloads {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();

    private Downloads() {}

    private static final class Opt {
        String label, tag, ext, mime, u1, u2;
        int kind; // 0 = single file with sound, 1 = HD video + audio merged on the phone, 2 = audio only
    }

    static void start(final Activity a, final String id, final String fallbackTitle) {
        if (id == null || id.isEmpty()) {
            Toast.makeText(a, "Video unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        if (android.os.Build.VERSION.SDK_INT < 29
                && a.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 702);
            Toast.makeText(a, "Allow storage access, then tap Download again", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(a, "Preparing download…", Toast.LENGTH_SHORT).show();
        EX.execute(new Runnable() {
            @Override public void run() {
                Yt.Info info = null;
                String err = null;
                try { info = Yt.info(id); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
                final Yt.Info fi = info;
                final String fe = err;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (a.isFinishing() || a.isDestroyed()) return;
                        if (fi == null) {
                            Toast.makeText(a, "Couldn't prepare download: " + fe, Toast.LENGTH_LONG).show();
                            return;
                        }
                        show(a, fi, fallbackTitle);
                    }
                });
            }
        });
    }

    private static String suffixOf(String s, String def) { return s == null || s.isEmpty() ? def : s; }

    private static void show(final Activity a, Yt.Info info, String fallbackTitle) {
        if (info.live) {
            Toast.makeText(a, "Live streams can't be downloaded", Toast.LENGTH_SHORT).show();
            return;
        }
        final String title = info.title.isEmpty() ? (fallbackTitle == null ? "video" : fallbackTitle) : info.title;
        List<Opt> hd = new ArrayList<>(), direct = new ArrayList<>(), audio = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        int maxMuxed = 0;

        List<Yt.VS> muxed = new ArrayList<>(info.muxed);
        Collections.sort(muxed, new Comparator<Yt.VS>() {
            @Override public int compare(Yt.VS x, Yt.VS y) { return Integer.compare(y.height, x.height); }
        });
        for (Yt.VS v : muxed) {
            String ext = suffixOf(v.suffix, "mp4");
            if (!seen.add(v.height + ext)) continue;
            maxMuxed = Math.max(maxMuxed, v.height);
            Opt o = new Opt();
            o.kind = 0;
            o.tag = v.height > 0 ? v.height + "p" : "video";
            o.label = (v.height > 0 ? v.height + "p" : "Video") + " · " + ext.toUpperCase();
            o.ext = ext;
            o.mime = ext.equals("webm") ? "video/webm" : (ext.equals("3gp") ? "video/3gpp" : "video/mp4");
            o.u1 = v.url;
            direct.add(o);
        }

        Yt.AS bestM4a = null, bestAny = null;
        for (Yt.AS s : info.audio) {
            if (bestAny == null || s.bitrate > bestAny.bitrate) bestAny = s;
            boolean m4a = "m4a".equals(s.suffix) || "mp4".equals(s.suffix);
            if (m4a && (bestM4a == null || s.bitrate > bestM4a.bitrate)) bestM4a = s;
        }

        if (bestM4a != null) {
            List<Yt.VS> vo = new ArrayList<>(info.videoOnly);
            Collections.sort(vo, new Comparator<Yt.VS>() {
                @Override public int compare(Yt.VS x, Yt.VS y) { return Integer.compare(y.height, x.height); }
            });
            for (Yt.VS v : vo) {
                if (v.height <= maxMuxed || v.height <= 0) continue;
                if (!v.codec.startsWith("avc") || !"mp4".equals(v.suffix)) continue;
                if (!seen.add("hd" + v.height)) continue;
                Opt o = new Opt();
                o.kind = 1;
                o.tag = v.height + "p";
                o.label = v.height + "p · MP4 (HD)";
                o.ext = "mp4";
                o.mime = "video/mp4";
                o.u1 = v.url;
                o.u2 = bestM4a.url;
                hd.add(o);
            }
        }

        Yt.AS aud = bestM4a != null ? bestM4a : bestAny;
        if (aud != null) {
            Opt o = new Opt();
            o.kind = 2;
            o.tag = "audio";
            String ext = suffixOf(aud.suffix, "m4a");
            o.ext = ext;
            o.mime = (ext.equals("m4a") || ext.equals("mp4")) ? "audio/mp4" : "audio/webm";
            o.label = "Audio only · " + ext.toUpperCase();
            o.u1 = aud.url;
            audio.add(o);
        }

        final List<Opt> all = new ArrayList<>();
        all.addAll(hd);
        all.addAll(direct);
        all.addAll(audio);
        if (all.isEmpty()) {
            Toast.makeText(a, "No downloadable stream was found for this video", Toast.LENGTH_LONG).show();
            return;
        }
        String[] labels = new String[all.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = all.get(i).label;
        new AlertDialog.Builder(a, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Download (free)")
            .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface d, int which) { enqueue(a, title, all.get(which)); }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private static String clean(String s) {
        String c = s.replaceAll("[\\\\/:*?\"<>|\\r\\n\\t]", " ").replaceAll("\\s+", " ").trim();
        if (c.length() > 80) c = c.substring(0, 80).trim();
        return c.isEmpty() ? "video" : c;
    }

    private static void enqueue(Activity a, String title, Opt o) {
        Intent in = new Intent(a, DownloadService.class);
        in.putExtra("name", clean(title) + " (" + o.tag + ")." + o.ext);
        in.putExtra("kind", o.kind);
        in.putExtra("u1", o.u1);
        if (o.u2 != null) in.putExtra("u2", o.u2);
        in.putExtra("mime", o.mime);
        try {
            ContextCompat.startForegroundService(a, in);
            Toast.makeText(a, "Download started · see the notification", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(a, "Couldn't start the download: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
