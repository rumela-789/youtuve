package com.manik.youtubeweb;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class PlaybackService extends MediaSessionService {
    /** The player lives in this service (so audio keeps playing in background); the UI uses it directly. */
    static volatile ExoPlayer exo;

    // What is currently loaded (used by the in-app mini player) and whether this video may play in the background.
    static volatile String curId, curTitle, curUploader, curThumb, curAvatar;
    static volatile boolean curAudio, bgAllowed;

    private static int started = 0;
    private static final Handler H = new Handler(Looper.getMainLooper());

    static void activityStarted() { started++; }

    /** Called from each activity's onStop: pauses playback when the app really left the screen and background play is off. */
    static void activityStopped() {
        started = Math.max(0, started - 1);
        H.postDelayed(() -> {
            ExoPlayer e = exo;
            if (started == 0 && !bgAllowed && e != null && e.getPlayWhenReady()) e.pause();
        }, 500);
    }

    static void clearCurrent() {
        curId = null; curTitle = null; curUploader = null; curThumb = null; curAvatar = null;
        curAudio = false; bgAllowed = false;
    }

    private ExoPlayer player;
    private MediaSession mediaSession;

    @Override public void onCreate() {
        super.onCreate();
        DefaultLoadControl load = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 700, 2_000).build();
        player = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(Net.dataSourceFactory(this)))
            .setLoadControl(load)
            .setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build();
        exo = player;
        mediaSession = new MediaSession.Builder(this, player).build();
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }
    @Override public void onTaskRemoved(Intent rootIntent) {
        if (player != null && !player.getPlayWhenReady()) stopSelf();
    }
    @Override public void onDestroy() {
        exo = null;
        if (mediaSession != null) { mediaSession.release(); mediaSession = null; }
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
