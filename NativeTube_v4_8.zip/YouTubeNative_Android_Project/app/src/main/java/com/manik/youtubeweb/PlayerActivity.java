package com.manik.youtubeweb;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;
import java.util.Map;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MergingMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;
import com.bumptech.glide.Glide;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.schabi.newpipe.extractor.Page;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Video / audio player: on-device stream extraction, automatic fallbacks, like/dislike, subscribe, ad-block. */
public class PlayerActivity extends Activity implements VideoCardView.Listener {
    private static final int RC_LOGIN = 31;
    private static final int T_MERGED = 0, T_PROG = 1, T_HLS = 2, T_AUDIO = 3;

    private static final class Cand {
        final int type; final String v, a; final boolean post;
        Cand(int type, String v, String a) { this(type, v, a, false); }
        Cand(int type, String v, String a, boolean post) { this.type = type; this.v = v; this.a = a; this.post = post; }
    }

    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private MediaController controller;          // only used to start/bind the playback service
    private ListenableFuture<MediaController> controllerFuture;
    private ExoPlayer exo;
    private Player.Listener playerListener;
    private boolean pendingStart = false;
    private boolean bgPlay = false, resumeExisting = false;
    private LinearLayout bgChip;

    // comments
    private final List<Comments.C> cmts = new ArrayList<>();
    private Page cmtNext;
    private boolean cmtLoading = false, cmtFailed = false;
    private String cmtCount = "", commentsFor = "";
    private int cmtGen = 0;
    private LinearLayout cmtCard, cmtPreviewRow;
    private TextView cmtTitle, cmtPreviewText;
    private FrameLayout cmtPreviewAvatar;
    private Dialog cmtDialog;
    private LinearLayout cmtList;
    private TextView cmtDialogCount;
    private ScrollView cmtScroll;

    private LinearLayout root, relatedBox;
    private FrameLayout playerBox;
    private PlayerView playerView;
    private PlayerControls controls;
    private ProgressBar spinner;
    private TextView overlayMsg, titleV, metaV, channelV, subsV, descV, qualityChip, subBtn;
    private LinearLayout likeChip, dislikeChip;
    private ImageView avatarV;
    private ScrollView scroll;

    // compatibility player: YouTube's own web player inside a WebView (used when direct extraction is blocked)
    private WebView webPlayer;
    private boolean webMode = false, webAlt = false;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private static final String BG_JS = "(function(){if(window.__bgk)return;window.__bgk=1;"
        + "try{Object.defineProperty(document,'hidden',{get:function(){return false;}});"
        + "Object.defineProperty(document,'visibilityState',{get:function(){return 'visible';}});}catch(e){}"
        + "['visibilitychange','webkitvisibilitychange','pagehide','blur'].forEach(function(t){"
        + "window.addEventListener(t,function(e){e.stopImmediatePropagation();},true);"
        + "document.addEventListener(t,function(e){e.stopImmediatePropagation();},true);});})();";
    private static final String AD_JS = "(function(){if(window.__abk)return;window.__abk=1;setInterval(function(){"
        + "var p=document.querySelector('.html5-video-player');var v=document.querySelector('video');"
        + "if(p&&p.classList.contains('ad-showing')&&v&&isFinite(v.duration)&&v.duration>0){v.muted=true;v.currentTime=v.duration;}"
        + "var b=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern');if(b)b.click();"
        + "var o=document.querySelector('.ytp-ad-overlay-close-button');if(o)o.click();"
        + "},400);})();";

    private String videoId, title, uploader, thumb;
    private Yt.Info info;
    private int loadGen = 0, portraitH;
    private boolean audioMode, full = false, descExpanded = false;
    private String forcedQuality = null;
    private final List<Cand> cands = new ArrayList<>();
    private int candIdx = 0;
    private boolean reExtracted = false, startedOk = false;
    private long resumeMs = 0;

    // like / subscribe state
    private int rating = 0, rating0 = 0;
    private long likesBase = -1, dislikesBase = -1;
    private boolean subscribed = false;
    private String curChannelId = "", likesText = "";

    // ad-block (SponsorBlock)
    private List<double[]> segments = new ArrayList<>();
    private long lastSkipToast = 0;

    private final Runnable watchdog = () -> {
        if (exo != null && !startedOk) advance("timeout");
    };
    private final Runnable skipper = new Runnable() {
        @Override public void run() {
            if (exo != null && exo.isPlaying() && !segments.isEmpty() && prefs.getBoolean("adblock", true)) {
                double pos = exo.getCurrentPosition() / 1000.0;
                for (double[] s : segments) {
                    if (pos >= s[0] && pos < s[1] - 0.6) {
                        exo.seekTo((long) (s[1] * 1000));
                        long now = System.currentTimeMillis();
                        if (now - lastSkipToast > 4000) {
                            lastSkipToast = now;
                            Toast.makeText(PlayerActivity.this, "Ad / sponsor segment skipped", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    }
                }
            }
            handler.postDelayed(this, 500);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Ui.prefs(this);
        Ui.load(this);
        PoTokens.install(this);
        Yt.init(prefs.getString("region", "US"));
        Net.setCookie(Auth.cookie(this));
        videoId = getIntent().getStringExtra("video_id");
        title = getIntent().getStringExtra("title");
        uploader = getIntent().getStringExtra("uploader");
        thumb = getIntent().getStringExtra("thumbnail");
        String av0 = getIntent().getStringExtra("avatar");
        audioMode = getIntent().getBooleanExtra("start_audio", false);
        resumeExisting = getIntent().getBooleanExtra("resume", false);
        // Background play is chosen per video: off by default, on for "Play in background" / audio mode.
        bgPlay = resumeExisting ? PlaybackService.bgAllowed : audioMode;
        PlaybackService.bgAllowed = bgPlay;
        PlaybackService.curId = videoId;
        PlaybackService.curTitle = title;
        PlaybackService.curUploader = uploader;
        PlaybackService.curThumb = thumb;
        PlaybackService.curAvatar = av0;
        PlaybackService.curAudio = audioMode;
        rating = rating0 = Auth.ratingOf(this, videoId);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.bg);
        getWindow().setNavigationBarColor(Ui.bg);
        build();
        if (av0 != null && !av0.isEmpty()) Glide.with(avatarV).load(av0).override(96, 96).circleCrop().into(avatarV);
        connectController();
        loadStreams(false);
        handler.postDelayed(skipper, 500);
    }

    // ------------------------------------------------------------------ layout

    private TextView chip(String label, View.OnClickListener l) {
        TextView t = Ui.text(this, label, 12.5f, true, Ui.fg);
        t.setPadding(Ui.dp(16), Ui.dp(9), Ui.dp(16), Ui.dp(9));
        t.setBackground(Ui.rect(Ui.surface, 18));
        t.setOnClickListener(l);
        return t;
    }

    /** Pill with a small icon and a label (used for like / dislike / audio). */
    private LinearLayout iconChip(int iconRes, String label, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(Ui.dp(14), Ui.dp(9), Ui.dp(16), Ui.dp(9));
        box.setBackground(Ui.rect(Ui.surface, 18));
        ImageView ic = Ui.icon(this, iconRes, Ui.fg, 18);
        box.addView(ic, new LinearLayout.LayoutParams(Ui.dp(18), Ui.dp(18)));
        TextView t = Ui.text(this, label, 12.5f, true, Ui.fg);
        t.setPadding(Ui.dp(8), 0, 0, 0);
        box.addView(t);
        box.setOnClickListener(l);
        return box;
    }

    private void styleChip(LinearLayout box, boolean on, String label) {
        int fg = on ? Ui.invFg : Ui.fg;
        box.setBackground(Ui.rect(on ? Ui.invBg : Ui.surface, 18));
        ((ImageView) box.getChildAt(0)).setColorFilter(fg, PorterDuff.Mode.SRC_IN);
        TextView t = (TextView) box.getChildAt(1);
        t.setTextColor(fg);
        t.setText(label);
        t.setVisibility(label.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void build() {
        portraitH = Math.min(getResources().getDisplayMetrics().widthPixels,
            getResources().getDisplayMetrics().heightPixels) * 9 / 16;
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.bg);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            if (full) v.setPadding(0, 0, 0, 0);
            else v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });

        playerBox = new FrameLayout(this);
        playerBox.setBackgroundColor(0xFF000000);
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerBox.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        spinner = new ProgressBar(this);
        spinner.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
        playerBox.addView(spinner, new FrameLayout.LayoutParams(Ui.dp(40), Ui.dp(40), Gravity.CENTER));
        controls = new PlayerControls(this, new PlayerControls.Host() {
            @Override public void onBack() { onBackPressed(); }
            @Override public void onFullscreen() { setFull(!full); }
            @Override public void onSettings() { pickQuality(); }
        });
        playerBox.addView(controls, new FrameLayout.LayoutParams(-1, -1));
        overlayMsg = Ui.text(this, "", 13, false, 0xFFFFFFFF);
        overlayMsg.setGravity(Gravity.CENTER);
        overlayMsg.setPadding(Ui.dp(24), 0, Ui.dp(24), 0);
        overlayMsg.setVisibility(View.GONE);
        playerBox.addView(overlayMsg, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        root.addView(playerBox, new LinearLayout.LayoutParams(-1, portraitH));

        scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, Ui.dp(20));

        titleV = Ui.text(this, title == null ? "Video" : title, 18, true, Ui.fg);
        titleV.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(2));
        content.addView(titleV);
        metaV = Ui.text(this, "", 12, false, Ui.muted);
        metaV.setPadding(Ui.dp(16), Ui.dp(2), Ui.dp(16), Ui.dp(10));
        content.addView(metaV);

        // channel row: avatar, name + subscribers, Subscribe button
        LinearLayout ch = new LinearLayout(this);
        ch.setGravity(Gravity.CENTER_VERTICAL);
        ch.setPadding(Ui.dp(16), Ui.dp(4), Ui.dp(16), Ui.dp(12));
        avatarV = new ImageView(this);
        avatarV.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarV.setBackground(Ui.gradientOval());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(40), Ui.dp(40));
        ap.rightMargin = Ui.dp(12);
        ch.addView(avatarV, ap);
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        channelV = Ui.text(this, uploader == null ? "" : uploader, 15, true, Ui.fg);
        channelV.setMaxLines(1);
        channelV.setEllipsize(TextUtils.TruncateAt.END);
        names.addView(channelV);
        subsV = Ui.text(this, "", 11.5f, false, Ui.muted);
        subsV.setVisibility(View.GONE);
        names.addView(subsV);
        ch.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
        subBtn = Ui.text(this, "Subscribe", 13, true, Ui.invFg);
        subBtn.setPadding(Ui.dp(18), Ui.dp(9), Ui.dp(18), Ui.dp(9));
        subBtn.setOnClickListener(v -> toggleSubscribe());
        ch.addView(subBtn);
        content.addView(ch);
        updateSubUi();

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(Ui.dp(16), 0, Ui.dp(16), Ui.dp(12));
        likeChip = iconChip(R.drawable.ic_like, "Like", v -> rate(1));
        dislikeChip = iconChip(R.drawable.ic_dislike, "", v -> rate(-1));
        bgChip = iconChip(R.drawable.ic_headphones, "Background play", v -> toggleBg());
        qualityChip = chip("Quality: Auto", v -> pickQuality());
        TextView share = chip("Share", v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, (title == null ? "" : title) + "\nhttps://youtu.be/" + videoId);
            startActivity(Intent.createChooser(i, "Share"));
        });
        dislikeChip.setContentDescription("Dislike");
        TextView webChip = chip("Web player", v -> { webAlt = webMode && !webAlt; startWebFallback(); });
        View[] all = {likeChip, dislikeChip, bgChip, qualityChip, share, webChip};
        for (View c : all) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            p.rightMargin = Ui.dp(8);
            chips.addView(c, p);
        }
        hs.addView(chips);
        content.addView(hs);
        updateChips();
        updateRateUi();

        descV = Ui.text(this, "", 13, false, Ui.fg);
        descV.setMaxLines(3);
        descV.setEllipsize(TextUtils.TruncateAt.END);
        descV.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        descV.setBackground(Ui.rect(Ui.surface, 14));
        descV.setTextIsSelectable(true);           // long-press to select / copy
        descV.setVisibility(View.GONE);
        descV.setOnClickListener(v -> {
            descExpanded = !descExpanded;
            descV.setMaxLines(descExpanded ? 200 : 3);
        });
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(Ui.dp(16), 0, Ui.dp(16), Ui.dp(10));
        content.addView(descV, dp);

        buildCommentsCard();
        LinearLayout.LayoutParams ccp = new LinearLayout.LayoutParams(-1, -2);
        ccp.setMargins(Ui.dp(16), 0, Ui.dp(16), Ui.dp(8));
        content.addView(cmtCard, ccp);

        TextView up = Ui.text(this, "Up next", 16, true, Ui.fg);
        up.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(2));
        content.addView(up);
        relatedBox = new LinearLayout(this);
        relatedBox.setOrientation(LinearLayout.VERTICAL);
        content.addView(relatedBox, new LinearLayout.LayoutParams(-1, -2));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        applySystemUi(false);
    }

    private void updateChips() {
        styleChip(bgChip, bgPlay, bgPlay ? "Background: On" : "Background play");
        String q = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        String label;
        if (q.equals("auto")) label = "Auto";
        else label = q + "p";
        qualityChip.setText("Quality: " + label);
        qualityChip.setVisibility(audioMode ? View.GONE : View.VISIBLE);
    }

    private void updateRateUi() {
        long l = likesBase >= 0 ? likesBase + (rating == 1 ? 1 : 0) - (rating0 == 1 ? 1 : 0) : -1;
        long d = dislikesBase >= 0 ? dislikesBase + (rating == -1 ? 1 : 0) - (rating0 == -1 ? 1 : 0) : -1;
        styleChip(likeChip, rating == 1, l >= 0 ? Ui.count(l) : (!likesText.isEmpty() ? likesText : "Like"));
        styleChip(dislikeChip, rating == -1, d >= 0 ? Ui.count(d) : "");
    }

    private void updateSubUi() {
        subBtn.setText(subscribed ? "Subscribed" : "Subscribe");
        subBtn.setTextColor(subscribed ? Ui.fg : Ui.invFg);
        subBtn.setBackground(Ui.rect(subscribed ? Ui.surface : Ui.invBg, 20));
    }

    // ------------------------------------------------------------------ fullscreen

    private void applySystemUi(boolean f) {
        int flags = 0;
        if (f) {
            flags = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!Ui.dark) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private void applyFull(boolean f) {
        full = f;
        controls.setFull(f);
        scroll.setVisibility(f ? View.GONE : View.VISIBLE);
        ViewGroup.LayoutParams lp = playerBox.getLayoutParams();
        lp.height = f ? ViewGroup.LayoutParams.MATCH_PARENT : portraitH;
        playerBox.setLayoutParams(lp);
        if (f) root.setPadding(0, 0, 0, 0);
        else root.requestApplyInsets();
        applySystemUi(f);
    }

    private void setFull(boolean f) {
        setRequestedOrientation(f ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        applyFull(f);
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        boolean land = c.orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (land != full) applyFull(land);
    }

    @Override public void onBackPressed() {
        if (customView != null) { hideCustomView(); return; }
        if (full) { setFull(false); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ player connection

    private void connectController() {
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                controller = controllerFuture.get();
                exo = PlaybackService.exo;
                if (exo == null) { showMsg("Player service not ready.\nTap to retry"); overlayMsg.setOnClickListener(v -> { overlayMsg.setVisibility(View.GONE); connectController(); }); return; }
                playerView.setPlayer(exo);
                controls.setPlayer(exo);
                try { startService(new Intent(PlayerActivity.this, PlaybackService.class)); } catch (Exception ignored) { }
                if (resumeExisting && videoId != null && videoId.equals(PlaybackService.curId)
                        && exo.getMediaItemCount() > 0) {
                    int st0 = exo.getPlaybackState();
                    if (st0 == Player.STATE_READY || st0 == Player.STATE_BUFFERING) {
                        startedOk = true;
                        spinner.setVisibility(st0 == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                    }
                }
                playerListener = new Player.Listener() {
                    @Override public void onPlaybackStateChanged(int state) {
                        spinner.setVisibility(state == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                        if (state == Player.STATE_READY) {
                            startedOk = true;
                            handler.removeCallbacks(watchdog);
                            overlayMsg.setVisibility(View.GONE);
                        }
                        if (state == Player.STATE_ENDED) playNext();
                    }
                    @Override public void onPlayerError(PlaybackException error) { advance(error.getErrorCodeName()); }
                };
                exo.addListener(playerListener);
                if (pendingStart) { pendingStart = false; startPlayback(resumeMs); }
            } catch (Exception e) {
                showMsg("Player service connection failed: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void showMsg(String m) {
        spinner.setVisibility(View.GONE);
        overlayMsg.setText(m);
        overlayMsg.setVisibility(View.VISIBLE);
    }

    // ------------------------------------------------------------------ loading

    private void loadStreams(boolean fresh) {
        final int g = ++loadGen;
        final String vid = videoId;
        info = null;
        cands.clear();
        handler.removeCallbacks(watchdog);
        spinner.setVisibility(View.VISIBLE);
        overlayMsg.setVisibility(View.GONE);
        overlayMsg.setOnClickListener(null);
        pool.execute(() -> {
            try {
                final Yt.Info d = fresh ? Yt.infoFresh(vid) : Yt.info(vid);
                runOnUiThread(() -> { if (g == loadGen) onInfo(d); });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (g != loadGen) return;
                    String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    String hint = "";
                    if (m.contains("LOGIN_REQUIRED") || m.toLowerCase().contains("bot")) {
                        hint = Auth.signedIn(PlayerActivity.this)
                            ? "\n\nYouTube is checking this connection. Wait a moment and tap to retry; "
                              + "if it keeps happening, Sign out and sign in again from the You tab."
                            : "\n\nSign in from the You tab, then try again.";
                    }
                    if (!(e instanceof java.net.UnknownHostException)) { startWebFallback(); return; }
                    showMsg("Couldn't load this video.\n" + m + hint + "\n\nTap to retry");
                    overlayMsg.setOnClickListener(v -> { reExtracted = false; loadStreams(true); });
                });
            }
        });
    }

    private void onInfo(Yt.Info d) {
        info = d;
        if (!d.title.isEmpty()) { title = d.title; titleV.setText(d.title); }
        if (!d.uploader.isEmpty()) { uploader = d.uploader; channelV.setText(d.uploader); }
        if (!d.avatar.isEmpty()) Glide.with(avatarV).load(d.avatar).override(96, 96).circleCrop().into(avatarV);
        if (d.subs >= 0) { subsV.setText(Ui.count(d.subs) + " subscribers"); subsV.setVisibility(View.VISIBLE); }
        else subsV.setVisibility(View.GONE);
        if (!d.avatar.isEmpty()) PlaybackService.curAvatar = d.avatar;
        PlaybackService.curTitle = title;
        PlaybackService.curUploader = uploader;
        curChannelId = d.channelId;
        subscribed = Auth.isSubscribed(this, d.channelId);
        loadComments();
        updateSubUi();

        StringBuilder m = new StringBuilder();
        if (d.live) m.append("● LIVE");
        if (d.views >= 0) { if (m.length() > 0) m.append("  ·  "); m.append(Ui.count(d.views)).append(d.live ? " watching" : " views"); }
        if (!d.uploadDate.isEmpty()) { if (m.length() > 0) m.append("  ·  "); m.append(d.uploadDate); }
        metaV.setText(m.toString());

        likesBase = d.likes;
        dislikesBase = -1;
        updateRateUi();
        final String vid = d.id;

        String desc = d.desc;
        if (!desc.isEmpty()) {
            if (desc.length() > 4000) desc = desc.substring(0, 4000);
            CharSequence cs = d.descHtml ? (Build.VERSION.SDK_INT >= 24 ? Html.fromHtml(desc, 0) : Html.fromHtml(desc)) : desc;
            descV.setText(cs);
            descV.setVisibility(View.VISIBLE);
        } else {
            descV.setVisibility(View.GONE);
        }

        relatedBox.removeAllViews();
        for (int i = 0; i < d.related.size() && i < 30; i++) {
            VideoCardView c = new VideoCardView(this);
            c.bind(d.related.get(i), this);
            relatedBox.addView(c, new LinearLayout.LayoutParams(-1, -2));
        }

        // sponsor / ad segments
        segments = new ArrayList<>();
        if (!d.live && prefs.getBoolean("adblock", true)) {
            pool.execute(() -> {
                final List<double[]> s = Yt.sponsorSegments(vid);
                runOnUiThread(() -> { if (vid.equals(videoId)) segments = s; });
            });
        }

        // make sure the subscribe button is accurate (subscription list is fetched once after login)
        if (Auth.signedIn(this) && prefs.getLong("subs_time", 0) == 0) {
            pool.execute(() -> {
                try { Auth.refreshSubscriptions(this); } catch (Exception ignored) { }
                runOnUiThread(() -> { subscribed = Auth.isSubscribed(this, curChannelId); updateSubUi(); });
            });
        }

        updateChips();
        buildCandidates();
        startPlayback(resumeMs);
        resumeMs = 0;
    }

    // ------------------------------------------------------------------ stream selection

    private int targetHeight() {
        String q = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        if (q.equals("auto")) return 720;
        try { return Integer.parseInt(q); } catch (Exception e) { return 720; }
    }

    private static int codecRank(String codec) {
        if (codec.startsWith("avc")) return 0;
        if (codec.startsWith("av01")) return 2;
        return 1;
    }

    private Yt.VS pickVideo(List<Yt.VS> list, int target, boolean avc) {
        Yt.VS best = null, lowestAbove = null;
        for (Yt.VS v : list) {
            boolean isAvc = codecRank(v.codec) == 0;
            if (avc != isAvc) continue;
            if (!avc && codecRank(v.codec) == 2) continue;
            if (v.height <= target) {
                if (best == null || v.height > best.height) best = v;
            } else if (lowestAbove == null || v.height < lowestAbove.height) {
                lowestAbove = v;
            }
        }
        return best != null ? best : lowestAbove;
    }

    private Yt.AS pickAudio(boolean m4a) {
        Yt.AS best = null, any = null;
        for (Yt.AS a : info.audio) {
            if (any == null || a.bitrate > any.bitrate) any = a;
            boolean isM4a = a.suffix.equals("m4a") || a.suffix.equals("mp4");
            if (isM4a != m4a) continue;
            if (best == null || a.bitrate > best.bitrate) best = a;
        }
        return best != null ? best : any;
    }

    private void buildCandidates() {
        buildBaseCandidates();
        List<Cand> out = new ArrayList<>();
        for (Cand c : cands) {
            out.add(c);
            if (c.type != T_HLS) out.add(new Cand(c.type, c.v, c.a, true));
        }
        cands.clear();
        cands.addAll(out);
        candIdx = 0;
    }

    private void buildBaseCandidates() {
        cands.clear();
        candIdx = 0;
        if (info == null) return;
        Yt.Info d = info;
        if (audioMode) {
            List<Yt.AS> a = new ArrayList<>(d.audio);
            Collections.sort(a, new Comparator<Yt.AS>() {
                @Override public int compare(Yt.AS x, Yt.AS y) {
                    boolean xm = x.suffix.equals("m4a"), ym = y.suffix.equals("m4a");
                    if (xm != ym) return xm ? -1 : 1;
                    return Integer.compare(y.bitrate, x.bitrate);
                }
            });
            for (Yt.AS s : a) cands.add(new Cand(T_AUDIO, s.url, null));
            if (!d.hls.isEmpty()) cands.add(new Cand(T_HLS, d.hls, null));
            return;
        }
        if (d.live && !d.hls.isEmpty()) cands.add(new Cand(T_HLS, d.hls, null));
        int target = targetHeight();
        // 1) high quality: separate video + audio merged on the device
        Yt.AS a1 = pickAudio(true), a2 = pickAudio(false);
        Yt.VS v1 = pickVideo(d.videoOnly, target, true), v2 = pickVideo(d.videoOnly, target, false);
        if (v1 != null && a1 != null) cands.add(new Cand(T_MERGED, v1.url, a1.url));
        if (v2 != null && a2 != null) cands.add(new Cand(T_MERGED, v2.url, a2.url));
        // 2) single-file streams (most compatible)
        List<Yt.VS> prog = new ArrayList<>(d.muxed);
        final int tg = target;
        Collections.sort(prog, new Comparator<Yt.VS>() {
            @Override public int compare(Yt.VS x, Yt.VS y) {
                boolean xo = x.height <= tg, yo = y.height <= tg;
                if (xo != yo) return xo ? -1 : 1;
                return xo ? Integer.compare(y.height, x.height) : Integer.compare(x.height, y.height);
            }
        });
        for (Yt.VS s : prog) cands.add(new Cand(T_PROG, s.url, null));
        // 3) HLS as a last resort
        if (!d.live && !d.hls.isEmpty()) cands.add(new Cand(T_HLS, d.hls, null));
    }

    private MediaItem item(String url, String mime) {
        MediaMetadata.Builder md = new MediaMetadata.Builder().setTitle(title).setArtist(uploader);
        if (thumb != null && !thumb.isEmpty()) md.setArtworkUri(Uri.parse(thumb));
        MediaItem.Builder mb = new MediaItem.Builder().setUri(url).setMediaId(String.valueOf(videoId))
            .setMediaMetadata(md.build());
        if (mime != null) mb.setMimeType(mime);
        return mb.build();
    }

    private MediaSource source(Cand c) {
        DataSource.Factory f = Net.dataSourceFactory(this);
        if (c.type == T_HLS) return new HlsMediaSource.Factory(f).createMediaSource(item(c.v, MimeTypes.APPLICATION_M3U8));
        ProgressiveMediaSource.Factory pf = new ProgressiveMediaSource.Factory(f);
        if (c.type == T_MERGED)
            return new MergingMediaSource(pf.createMediaSource(item(c.v, null)), pf.createMediaSource(item(c.a, null)));
        return pf.createMediaSource(item(c.v, null));
    }

    private void startPlayback(long seekMs) {
        if (resumeExisting) {
            if (exo == null) { resumeMs = seekMs; pendingStart = true; return; }
            resumeExisting = false;
            int st = exo.getPlaybackState();
            if (videoId != null && videoId.equals(PlaybackService.curId) && exo.getMediaItemCount() > 0
                    && (st == Player.STATE_READY || st == Player.STATE_BUFFERING)) {
                startedOk = true;
                handler.removeCallbacks(watchdog);
                spinner.setVisibility(st == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                return;
            }
        }
        if (cands.isEmpty()) {
            if (info != null) showMsg("No playable stream was found for this video.");
            return;
        }
        if (exo == null) { resumeMs = seekMs; pendingStart = true; return; }
        if (candIdx >= cands.size()) candIdx = 0;
        Cand c = cands.get(candIdx);
        Net.postMode = c.post;
        startedOk = false;
        try {
            MediaSource ms = source(c);
            if (seekMs > 0 && !(info != null && info.live)) exo.setMediaSource(ms, seekMs);
            else exo.setMediaSource(ms);
            exo.prepare();
            exo.setPlayWhenReady(true);
        } catch (Exception e) {
            advance(String.valueOf(e.getMessage()));
            return;
        }
        handler.removeCallbacks(watchdog);
        handler.postDelayed(watchdog, 20000);
        if (audioMode) Toast.makeText(this, "Audio mode · keeps playing with the screen off", Toast.LENGTH_SHORT).show();
        PlaybackService.curAudio = audioMode;
    }

    /** Current stream failed: try the next one, then fetch fresh links once, then give up with a retry button. */
    private void advance(String why) {
        handler.removeCallbacks(watchdog);
        if (exo == null) return;
        long pos = Math.max(0, exo.getCurrentPosition());
        if (candIdx + 1 < cands.size()) {
            candIdx++;
            startPlayback(startedOk ? pos : 0);
            return;
        }
        if (!reExtracted) {
            reExtracted = true;
            resumeMs = startedOk ? pos : 0;
            loadStreams(true);
            return;
        }
        startWebFallback();
    }

    // ------------------------------------------------------------------ compatibility (web) player

    private void hideCustomView() {
        if (customView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        applySystemUi(false);
    }

    private void leaveWebMode() {
        if (!webMode) return;
        webMode = false;
        webAlt = false;
        hideCustomView();
        if (webPlayer != null) { webPlayer.loadUrl("about:blank"); webPlayer.setVisibility(View.GONE); }
        stopService(new Intent(this, KeepAliveService.class));
        playerView.setVisibility(View.VISIBLE);
        controls.setVisibility(View.VISIBLE);
    }

    /**
     * Direct stream extraction can be blocked for an IP ("confirm you're not a bot"). YouTube's own web player running in a
     * real WebView with the signed-in session is not blocked, so we fall back to it. Ads are auto-skipped by a small script.
     */
    private void startWebFallback() {
        handler.removeCallbacks(watchdog);
        if (exo != null) exo.stop();
        spinner.setVisibility(View.GONE);
        overlayMsg.setVisibility(View.GONE);
        playerView.setVisibility(View.GONE);
        controls.setVisibility(View.GONE);
        webMode = true;
        if (webPlayer == null) {
            webPlayer = new WebView(this);
            webPlayer.setBackgroundColor(0xFF000000);
            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(webPlayer, true);
            WebSettings ws = webPlayer.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setMediaPlaybackRequiresUserGesture(false);
            ws.setUserAgentString(Net.UA_WEB);
            webPlayer.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String url) {
                    if (url == null || !url.contains("youtube.com")) return;
                    if (prefs.getBoolean("adblock", true)) v.evaluateJavascript(AD_JS, null);
                    if (bgPlay) v.evaluateJavascript(BG_JS, null);
                }
            });
            webPlayer.setWebChromeClient(new WebChromeClient() {
                @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                    if (customView != null) { cb.onCustomViewHidden(); return; }
                    customView = v;
                    customCb = cb;
                    ((FrameLayout) getWindow().getDecorView()).addView(v, new FrameLayout.LayoutParams(-1, -1));
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                    applySystemUi(true);
                }
                @Override public void onHideCustomView() { hideCustomView(); }
            });
            playerBox.addView(webPlayer, new FrameLayout.LayoutParams(-1, -1));
        }
        webPlayer.setVisibility(View.VISIBLE);
        if (webAlt) {
            webPlayer.loadUrl("https://m.youtube.com/watch?v=" + videoId);
        } else {
            Map<String, String> h = new HashMap<>();
            h.put("Referer", "https://www.youtube.com/");
            webPlayer.loadUrl("https://www.youtube.com/embed/" + videoId
                + "?autoplay=1&playsinline=1&rel=0&fs=1&enablejsapi=1", h);
        }
        Toast.makeText(this, "Using compatibility player", Toast.LENGTH_SHORT).show();
        if (bgPlay) {
            try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); }
            catch (Exception ignored) { }
        }
        // channel / likes / subscribers / suggestions via YouTube's own page data (not blocked like stream extraction)
        final String vid = videoId;
        pool.execute(() -> {
            try {
                final Yt.Info w = Yt.webInfo(vid, Auth.nextInfo(this, vid));
                runOnUiThread(() -> onWebInfo(w));
            } catch (Exception ignored) { }
        });
    }

    private void onWebInfo(Yt.Info w) {
        if (!webMode || !w.id.equals(videoId)) return;
        if (!w.channelId.isEmpty()) curChannelId = w.channelId;
        if (!w.uploader.isEmpty()) { uploader = w.uploader; channelV.setText(w.uploader); }
        if (!w.title.isEmpty()) { title = w.title; titleV.setText(w.title); }
        if (!w.avatar.isEmpty()) Glide.with(avatarV).load(w.avatar).override(96, 96).circleCrop().into(avatarV);
        if (!w.subsText.isEmpty()) { subsV.setText(w.subsText); subsV.setVisibility(View.VISIBLE); }
        likesText = w.likesText;
        loadComments();
        subscribed = Auth.isSubscribed(this, curChannelId);
        updateSubUi();
        updateRateUi();
        relatedBox.removeAllViews();
        for (int i = 0; i < w.related.size() && i < 30; i++) {
            VideoCardView c = new VideoCardView(this);
            c.bind(w.related.get(i), this);
            relatedBox.addView(c, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    // ------------------------------------------------------------------ actions

    private void toggleAudio() {
        if (webMode) { Toast.makeText(this, "Audio-only isn't available in compatibility mode", Toast.LENGTH_SHORT).show(); return; }
        long pos = exo == null ? 0 : Math.max(0, exo.getCurrentPosition());
        audioMode = !audioMode;
        if (audioMode) { bgPlay = true; PlaybackService.bgAllowed = true; }
        PlaybackService.curAudio = audioMode;
        updateChips();
        buildCandidates();
        startPlayback(pos);
    }

    private void toggleBg() {
        bgPlay = !bgPlay;
        PlaybackService.bgAllowed = bgPlay;
        if (webMode) {
            if (bgPlay) {
                if (webPlayer != null) webPlayer.evaluateJavascript(BG_JS, null);
                try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); }
                catch (Exception ignored) { }
            } else {
                stopService(new Intent(this, KeepAliveService.class));
            }
        }
        updateChips();
        Toast.makeText(this, bgPlay ? "Background play on for this video" : "Background play off", Toast.LENGTH_SHORT).show();
    }

    private void pickQuality() {
        if (info == null) return;
        final List<String> labels = new ArrayList<>(), values = new ArrayList<>();
        labels.add("Auto (up to 720p)"); values.add("auto");
        List<Integer> hs = new ArrayList<>();
        for (Yt.VS s : info.videoOnly) if (s.height > 0 && !hs.contains(s.height)) hs.add(s.height);
        for (Yt.VS s : info.muxed) if (s.height > 0 && !hs.contains(s.height)) hs.add(s.height);
        Collections.sort(hs, Collections.reverseOrder());
        for (int h : hs) { labels.add(h + "p"); values.add(String.valueOf(h)); }
        String cur = forcedQuality == null ? prefs.getString("quality", "auto") : forcedQuality;
        int checked = Math.max(0, values.indexOf(cur));
        new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Video quality")
            .setSingleChoiceItems(labels.toArray(new String[0]), checked, (dlg, w) -> {
                forcedQuality = values.get(w);
                dlg.dismiss();
                long pos = exo == null ? 0 : Math.max(0, exo.getCurrentPosition());
                updateChips();
                buildCandidates();
                startPlayback(pos);
            }).show();
    }

    private void needLogin() {
        new AlertDialog.Builder(this, Ui.dark ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Sign in required")
            .setMessage("Sign in with your Google account to like videos and subscribe to channels.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Sign in", (d, w) -> startActivityForResult(new Intent(this, LoginActivity.class), RC_LOGIN))
            .show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOGIN && res == RESULT_OK) {
            rating = rating0 = Auth.ratingOf(this, videoId);
            subscribed = Auth.isSubscribed(this, curChannelId);
            updateRateUi();
            updateSubUi();
            Toast.makeText(this, "Signed in", Toast.LENGTH_SHORT).show();
        }
    }

    private void rate(int want) {
        if (!Auth.signedIn(this)) { needLogin(); return; }
        final int prev = rating;
        final int next = prev == want ? 0 : want;
        final String action = next == 0 ? "removelike" : (next == 1 ? "like" : "dislike");
        final String vid = videoId;
        rating = next;
        Auth.saveRating(this, vid, next);
        updateRateUi();
        pool.execute(() -> {
            try { Auth.rate(this, vid, action); }
            catch (final Exception e) {
                runOnUiThread(() -> {
                    Auth.saveRating(this, vid, prev);
                    if (vid.equals(videoId)) { rating = prev; updateRateUi(); }
                    Toast.makeText(this, "Couldn't update: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void toggleSubscribe() {
        if (curChannelId.isEmpty()) {
            Toast.makeText(this, "Channel not loaded yet", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Auth.signedIn(this)) { needLogin(); return; }
        final String cid = curChannelId;
        final boolean want = !subscribed;
        subscribed = want;
        updateSubUi();
        pool.execute(() -> {
            try { Auth.subscribe(this, cid, want); }
            catch (final Exception e) {
                runOnUiThread(() -> {
                    subscribed = !want;
                    updateSubUi();
                    Toast.makeText(this, "Couldn't update subscription: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void playNext() {
        if (!prefs.getBoolean("autoplay", true) || info == null || info.related.isEmpty()) return;
        JSONObject n = info.related.get(0);
        String id = Yt.videoId(n.optString("url", ""));
        if (id.isEmpty() || id.equals(videoId)) return;
        onOpen(id, n.optString("title", ""), n.optString("uploaderName", ""), n.optString("thumbnail", ""),
            n.optString("uploaderAvatar", ""), audioMode);
    }

    /** Called when a suggested video is tapped; reuses this screen instead of stacking new ones. */
    @Override public void onOpen(String id, String t, String author, String th, String av, boolean audio) {
        if (id == null || id.isEmpty()) return;
        Ui.saveHistory(this, id, t, author, th);
        resumeExisting = false;
        bgPlay = audio;
        PlaybackService.bgAllowed = audio;
        PlaybackService.curId = id;
        PlaybackService.curTitle = t;
        PlaybackService.curUploader = author;
        PlaybackService.curThumb = th;
        PlaybackService.curAvatar = av;
        PlaybackService.curAudio = audio;
        videoId = id;
        title = t;
        uploader = author;
        thumb = th;
        audioMode = audio;
        forcedQuality = null;
        leaveWebMode();
        reExtracted = false;
        resumeMs = 0;
        rating = rating0 = Auth.ratingOf(this, id);
        likesBase = dislikesBase = -1;
        likesText = "";
        curChannelId = "";
        relatedBox.removeAllViews();
        subscribed = false;
        segments = new ArrayList<>();
        titleV.setText(t == null ? "" : t);
        channelV.setText(author == null ? "" : author);
        subsV.setVisibility(View.GONE);
        metaV.setText("");
        descV.setVisibility(View.GONE);
        avatarV.setImageDrawable(null);
        if (av != null && !av.isEmpty()) Glide.with(avatarV).load(av).override(96, 96).circleCrop().into(avatarV);
        scroll.scrollTo(0, 0);
        updateChips();
        updateRateUi();
        updateSubUi();
        commentsFor = "";
        loadStreams(false);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override protected void onStart() {
        super.onStart();
        PlaybackService.activityStarted();
    }

    @Override protected void onPause() {
        boolean keep = webMode && bgPlay && !isFinishing();
        if (webPlayer != null && !keep) webPlayer.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webPlayer != null) webPlayer.onResume();
    }

    @Override protected void onStop() {
        PlaybackService.activityStopped();
        super.onStop();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (cmtDialog != null) { try { cmtDialog.dismiss(); } catch (Exception ignored) { } cmtDialog = null; }
        if (exo != null && playerListener != null) exo.removeListener(playerListener);
        if (controls != null) controls.detach();
        if (playerView != null) playerView.setPlayer(null);
        if (controllerFuture != null) MediaController.releaseFuture(controllerFuture);
        controller = null;
        exo = null;
        stopService(new Intent(this, KeepAliveService.class));
        if (webPlayer != null) { webPlayer.stopLoading(); webPlayer.destroy(); webPlayer = null; }
        pool.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ comments

    private void buildCommentsCard() {
        cmtCard = new LinearLayout(this);
        cmtCard.setOrientation(LinearLayout.VERTICAL);
        cmtCard.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        cmtCard.setBackground(Ui.rect(Ui.surface, 12));
        cmtTitle = Ui.text(this, "Comments", 14, true, Ui.fg);
        cmtCard.addView(cmtTitle);
        cmtPreviewRow = new LinearLayout(this);
        cmtPreviewRow.setGravity(Gravity.CENTER_VERTICAL);
        cmtPreviewRow.setPadding(0, Ui.dp(10), 0, 0);
        cmtPreviewAvatar = new FrameLayout(this);
        LinearLayout.LayoutParams pa = new LinearLayout.LayoutParams(Ui.dp(24), Ui.dp(24));
        pa.rightMargin = Ui.dp(10);
        cmtPreviewRow.addView(cmtPreviewAvatar, pa);
        cmtPreviewText = Ui.text(this, "Loading…", 13, false, Ui.fg);
        cmtPreviewText.setMaxLines(2);
        cmtPreviewText.setEllipsize(TextUtils.TruncateAt.END);
        cmtPreviewRow.addView(cmtPreviewText, new LinearLayout.LayoutParams(0, -2, 1));
        cmtCard.addView(cmtPreviewRow);
        cmtCard.setOnClickListener(v -> openComments());
    }

    private CharSequence commentText(Comments.C c) {
        if (c.html) return Build.VERSION.SDK_INT >= 24 ? Html.fromHtml(c.text, 0) : Html.fromHtml(c.text);
        return c.text;
    }

    private void updateCommentsCard() {
        cmtTitle.setText(cmtCount.isEmpty() ? "Comments" : "Comments  " + cmtCount);
        if (!cmts.isEmpty()) {
            Comments.C c = cmts.get(0);
            cmtPreviewText.setText(commentText(c));
            fillAvatar(cmtPreviewAvatar, c.avatar, c.author, 24);
        } else {
            cmtPreviewAvatar.removeAllViews();
            cmtPreviewText.setText(cmtLoading ? "Loading…" : (cmtFailed ? "Tap to add a comment or retry" : "Be the first to comment"));
        }
    }

    private void loadComments() {
        if (videoId == null || videoId.equals(commentsFor)) return;
        commentsFor = videoId;
        final String vid = videoId;
        final int g = ++cmtGen;
        cmts.clear();
        cmtNext = null;
        cmtFailed = false;
        cmtLoading = true;
        cmtCount = "";
        updateCommentsCard();
        pool.execute(() -> {
            Comments.Res r = null;
            String[] h = null;
            boolean failed = false;
            try { r = Comments.first(vid); } catch (Exception e) { failed = true; }
            try { h = Comments.header(this, vid); } catch (Exception ignored) { }
            final Comments.Res fr = r;
            final String[] fh = h;
            final boolean ff = failed;
            runOnUiThread(() -> {
                if (g != cmtGen) return;
                cmtLoading = false;
                cmtFailed = ff;
                if (fr != null) { cmts.addAll(fr.items); cmtNext = fr.next; }
                if (fh != null) cmtCount = fh[0];
                updateCommentsCard();
                if (cmtDialog != null) refreshCommentList();
            });
        });
    }

    private void loadMoreComments() {
        if (cmtLoading || cmtNext == null) return;
        cmtLoading = true;
        final String vid = videoId;
        final int g = cmtGen;
        final Page pg = cmtNext;
        pool.execute(() -> {
            Comments.Res r = null;
            try { r = Comments.more(vid, pg); } catch (Exception ignored) { }
            final Comments.Res fr = r;
            runOnUiThread(() -> {
                if (g != cmtGen) return;
                cmtLoading = false;
                if (fr != null) { cmts.addAll(fr.items); cmtNext = fr.next; }
                if (cmtDialog != null) refreshCommentList();
            });
        });
    }

    private void openComments() {
        if (cmtDialog != null) return;
        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(Ui.bg);
        float r = Ui.dp(16);
        bgd.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bgd);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Ui.dp(16), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        head.addView(Ui.text(this, "Comments", 17, true, Ui.fg));
        cmtDialogCount = Ui.text(this, "", 14, false, Ui.muted);
        cmtDialogCount.setPadding(Ui.dp(8), 0, 0, 0);
        head.addView(cmtDialogCount);
        head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        ImageView x = Ui.icon(this, R.drawable.ic_close, Ui.fg, 22);
        x.setPadding(Ui.dp(11), Ui.dp(11), Ui.dp(11), Ui.dp(11));
        x.setOnClickListener(v -> dlg.dismiss());
        head.addView(x, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        box.addView(head);
        View d1 = new View(this);
        d1.setBackgroundColor(Ui.line);
        box.addView(d1, new LinearLayout.LayoutParams(-1, 1));

        cmtScroll = new ScrollView(this);
        cmtList = new LinearLayout(this);
        cmtList.setOrientation(LinearLayout.VERTICAL);
        cmtList.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(16));
        cmtScroll.addView(cmtList);
        cmtScroll.setOnScrollChangeListener((v, sx, sy, ox, oy) -> {
            View c = cmtScroll.getChildAt(0);
            if (c != null && c.getBottom() - (cmtScroll.getHeight() + sy) < Ui.dp(240)) loadMoreComments();
        });
        box.addView(cmtScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        View d2 = new View(this);
        d2.setBackgroundColor(Ui.line);
        box.addView(d2, new LinearLayout.LayoutParams(-1, 1));
        LinearLayout in = new LinearLayout(this);
        in.setGravity(Gravity.CENTER_VERTICAL);
        in.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        View me = avatarView(Auth.signedIn(this) ? prefs.getString("acct_photo", "") : "",
            Auth.signedIn(this) ? prefs.getString("acct_name", "") : "", 34);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(34));
        mp.rightMargin = Ui.dp(10);
        in.addView(me, mp);
        final EditText field = new EditText(this);
        field.setHint(Auth.signedIn(this) ? "Add a comment…" : "Sign in to comment");
        field.setHintTextColor(Ui.muted);
        field.setTextColor(Ui.fg);
        field.setTextSize(14.5f);
        field.setMaxLines(4);
        field.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        field.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        field.setBackground(Ui.rect(Ui.surface, 20));
        if (!Auth.signedIn(this)) {
            field.setFocusable(false);
            field.setOnClickListener(v -> needLogin());
        }
        in.addView(field, new LinearLayout.LayoutParams(0, -2, 1));
        final ImageView send = Ui.icon(this, R.drawable.ic_send, Ui.link, 22);
        send.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        send.setContentDescription("Post comment");
        send.setOnClickListener(v -> {
            if (!Auth.signedIn(this)) { needLogin(); return; }
            final String text = field.getText().toString().trim();
            if (text.isEmpty()) return;
            send.setEnabled(false);
            send.setAlpha(0.4f);
            final String vid = videoId;
            pool.execute(() -> {
                String err = null;
                try { Comments.post(this, vid, text); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
                final String fe = err;
                runOnUiThread(() -> {
                    send.setEnabled(true);
                    send.setAlpha(1f);
                    if (fe != null) {
                        Toast.makeText(this, "Couldn't post comment: " + fe, Toast.LENGTH_LONG).show();
                        return;
                    }
                    field.setText("");
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
                    Comments.C c = new Comments.C();
                    c.author = prefs.getString("acct_name", "You");
                    c.avatar = prefs.getString("acct_photo", "");
                    c.text = text;
                    c.date = "just now";
                    c.mine = true;
                    if (vid.equals(videoId)) {
                        cmts.add(0, c);
                        updateCommentsCard();
                        refreshCommentList();
                        cmtScroll.post(() -> cmtScroll.scrollTo(0, 0));
                    }
                    Toast.makeText(this, "Comment posted", Toast.LENGTH_SHORT).show();
                });
            });
        });
        in.addView(send, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        box.addView(in);

        dlg.setContentView(box);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                (int) (getResources().getDisplayMetrics().heightPixels * 0.78f));
            w.setGravity(Gravity.BOTTOM);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            w.setDimAmount(0.55f);
        }
        dlg.setOnDismissListener(d -> { cmtDialog = null; cmtList = null; cmtScroll = null; });
        cmtDialog = dlg;
        refreshCommentList();
        dlg.show();
        if (cmts.isEmpty() && !cmtLoading && cmtFailed) { commentsFor = ""; loadComments(); }
    }

    private void refreshCommentList() {
        if (cmtList == null) return;
        cmtDialogCount.setText(cmtCount);
        cmtList.removeAllViews();
        if (cmts.isEmpty()) {
            String m = cmtLoading ? "Loading comments…"
                : (cmtFailed ? "Couldn't load comments (they may be turned off)." : "No comments yet. Be the first!");
            TextView t = Ui.text(this, m, 14, false, Ui.muted);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(40), 0, Ui.dp(40));
            cmtList.addView(t, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        for (Comments.C c : cmts) cmtList.addView(commentView(c, false), new LinearLayout.LayoutParams(-1, -2));
        if (cmtNext != null || cmtLoading) {
            ProgressBar pb = new ProgressBar(this);
            pb.getIndeterminateDrawable().setColorFilter(Ui.accent, PorterDuff.Mode.SRC_IN);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(26), Ui.dp(26));
            pp.gravity = Gravity.CENTER_HORIZONTAL;
            pp.topMargin = Ui.dp(12);
            cmtList.addView(pb, pp);
        }
    }

    /** Round avatar: photo when we have one, otherwise a coloured circle with the first letter. */
    private View avatarView(String url, String name, int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        fillAvatar(f, url, name, sizeDp);
        return f;
    }

    private void fillAvatar(FrameLayout f, String url, String name, int sizeDp) {
        f.removeAllViews();
        String n = name == null ? "" : name.replace("@", "").trim();
        int hue = Math.abs(n.hashCode()) % 360;
        f.setBackground(Ui.oval(android.graphics.Color.HSVToColor(new float[]{hue, 0.45f, 0.55f})));
        TextView tv = Ui.text(this, n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase(), sizeDp / 2.3f, true, 0xFFFFFFFF);
        tv.setGravity(Gravity.CENTER);
        f.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        if (url != null && !url.isEmpty()) {
            if (url.startsWith("//")) url = "https:" + url;
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            Glide.with(getApplicationContext()).load(url).override(Ui.dp(sizeDp) * 2).circleCrop().into(iv);
        }
    }

    private View commentView(final Comments.C c, boolean reply) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, Ui.dp(10), 0, Ui.dp(6));
        int sz = reply ? 24 : 36;
        View av = avatarView(c.avatar, c.author, sz);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(sz), Ui.dp(sz));
        ap.rightMargin = Ui.dp(12);
        row.addView(av, ap);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        if (c.pinned) {
            TextView pin = Ui.text(this, "Pinned", 11, true, Ui.muted);
            col.addView(pin);
        }
        String head = c.author + (c.date.isEmpty() ? "" : "  ·  " + c.date);
        TextView h = Ui.text(this, head, 12, false, Ui.muted);
        h.setMaxLines(1);
        h.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(h);
        TextView body = Ui.text(this, "", 14, false, Ui.fg);
        body.setText(commentText(c));
        body.setTextIsSelectable(true);
        body.setPadding(0, Ui.dp(3), 0, 0);
        col.addView(body);

        LinearLayout act = new LinearLayout(this);
        act.setGravity(Gravity.CENTER_VERTICAL);
        act.setPadding(0, Ui.dp(6), 0, 0);
        ImageView lk = Ui.icon(this, R.drawable.ic_like, Ui.muted, 16);
        act.addView(lk, new LinearLayout.LayoutParams(Ui.dp(16), Ui.dp(16)));
        if (!c.likes.isEmpty()) {
            TextView lt = Ui.text(this, c.likes, 12, false, Ui.muted);
            lt.setPadding(Ui.dp(6), 0, 0, 0);
            act.addView(lt);
        }
        col.addView(act);

        if (!reply && c.replyCount > 0 && c.replies != null) {
            final LinearLayout repliesBox = new LinearLayout(this);
            repliesBox.setOrientation(LinearLayout.VERTICAL);
            final TextView more = Ui.text(this, c.replyCount + (c.replyCount == 1 ? " reply" : " replies"), 13, true, Ui.link);
            more.setPadding(0, Ui.dp(6), 0, Ui.dp(2));
            final Page[] tok = {c.replies};
            more.setOnClickListener(v -> {
                if (tok[0] == null) return;
                final Page pg = tok[0];
                tok[0] = null;
                more.setText("Loading…");
                final String vid = videoId;
                pool.execute(() -> {
                    Comments.Res r = null;
                    try { r = Comments.more(vid, pg); } catch (Exception ignored) { }
                    final Comments.Res fr = r;
                    runOnUiThread(() -> {
                        if (fr == null) { tok[0] = pg; more.setText("Couldn't load replies · tap to retry"); return; }
                        for (Comments.C rc : fr.items) repliesBox.addView(commentView(rc, true), new LinearLayout.LayoutParams(-1, -2));
                        tok[0] = fr.next;
                        if (fr.next != null) more.setText("Show more replies"); else more.setVisibility(View.GONE);
                    });
                });
            });
            col.addView(more);
            col.addView(repliesBox);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        return row;
    }
}
